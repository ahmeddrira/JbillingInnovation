--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.validation_rule_attributes DROP CONSTRAINT validation_rule_fk_2;
ALTER TABLE ONLY public.meta_field_name DROP CONSTRAINT validation_rule_fk_1;
ALTER TABLE ONLY public.user_role_map DROP CONSTRAINT user_role_map_fk_2;
ALTER TABLE ONLY public.user_role_map DROP CONSTRAINT user_role_map_fk_1;
ALTER TABLE ONLY public.tab_configuration_tab DROP CONSTRAINT tab_configuration_tab_fk_2;
ALTER TABLE ONLY public.tab_configuration_tab DROP CONSTRAINT tab_configuration_tab_fk_1;
ALTER TABLE ONLY public.tab_configuration DROP CONSTRAINT tab_configuration_fk_1;
ALTER TABLE ONLY public.role DROP CONSTRAINT role_entity_id_fk;
ALTER TABLE ONLY public.reseller_entityid_map DROP CONSTRAINT reseller_entityid_map_fk_2;
ALTER TABLE ONLY public.reseller_entityid_map DROP CONSTRAINT reseller_entityid_map_fk_1;
ALTER TABLE ONLY public.entity_report_map DROP CONSTRAINT report_map_report_id_fk;
ALTER TABLE ONLY public.entity_report_map DROP CONSTRAINT report_map_entity_id_fk;
ALTER TABLE ONLY public.rating_unit DROP CONSTRAINT "rating_unit_entity_id_FK";
ALTER TABLE ONLY public.purchase_order DROP CONSTRAINT "purchase_order_statusId_fk";
ALTER TABLE ONLY public.purchase_order DROP CONSTRAINT purchase_order_parent__order_id_fk;
ALTER TABLE ONLY public.purchase_order DROP CONSTRAINT purchase_order_fk_5;
ALTER TABLE ONLY public.purchase_order DROP CONSTRAINT purchase_order_fk_4;
ALTER TABLE ONLY public.purchase_order DROP CONSTRAINT purchase_order_fk_3;
ALTER TABLE ONLY public.purchase_order DROP CONSTRAINT purchase_order_fk_2;
ALTER TABLE ONLY public.purchase_order DROP CONSTRAINT purchase_order_fk_1;
ALTER TABLE ONLY public.promotion_user_map DROP CONSTRAINT promotion_user_map_fk_2;
ALTER TABLE ONLY public.promotion_user_map DROP CONSTRAINT promotion_user_map_fk_1;
ALTER TABLE ONLY public.promotion DROP CONSTRAINT promotion_fk_1;
ALTER TABLE ONLY public.process_run_user DROP CONSTRAINT process_run_user_fk_2;
ALTER TABLE ONLY public.process_run_user DROP CONSTRAINT process_run_user_fk_1;
ALTER TABLE ONLY public.process_run_total_pm DROP CONSTRAINT process_run_total_pm_fk_1;
ALTER TABLE ONLY public.process_run_total DROP CONSTRAINT process_run_total_fk_2;
ALTER TABLE ONLY public.process_run_total DROP CONSTRAINT process_run_total_fk_1;
ALTER TABLE ONLY public.process_run DROP CONSTRAINT process_run_fk_2;
ALTER TABLE ONLY public.process_run DROP CONSTRAINT process_run_fk_1;
ALTER TABLE ONLY public.preference_type DROP CONSTRAINT preference_type_vr_fk_1;
ALTER TABLE ONLY public.preference DROP CONSTRAINT preference_fk_2;
ALTER TABLE ONLY public.preference DROP CONSTRAINT preference_fk_1;
ALTER TABLE ONLY public.pluggable_task_type DROP CONSTRAINT pluggable_task_type_fk_1;
ALTER TABLE ONLY public.pluggable_task_parameter DROP CONSTRAINT pluggable_task_parameter_fk_1;
ALTER TABLE ONLY public.pluggable_task DROP CONSTRAINT pluggable_task_fk_2;
ALTER TABLE ONLY public.payment_method_type DROP CONSTRAINT "payment_method_type_FK2";
ALTER TABLE ONLY public.payment_method_type DROP CONSTRAINT "payment_method_type_FK1";
ALTER TABLE ONLY public.payment_method_template_meta_fields_map DROP CONSTRAINT "payment_method_template_meta_fields_map_FK2";
ALTER TABLE ONLY public.payment_method_template_meta_fields_map DROP CONSTRAINT "payment_method_template_meta_fields_map_FK1";
ALTER TABLE ONLY public.payment_method_meta_fields_map DROP CONSTRAINT "payment_method_meta_fields_map_FK2";
ALTER TABLE ONLY public.payment_method_meta_fields_map DROP CONSTRAINT "payment_method_meta_fields_map_FK1";
ALTER TABLE ONLY public.payment_method_account_type_map DROP CONSTRAINT "payment_method_account_type_map_FK2";
ALTER TABLE ONLY public.payment_method_account_type_map DROP CONSTRAINT "payment_method_account_type_map_FK1";
ALTER TABLE ONLY public.payment_meta_field_map DROP CONSTRAINT payment_meta_field_map_fk_2;
ALTER TABLE ONLY public.payment_meta_field_map DROP CONSTRAINT payment_meta_field_map_fk_1;
ALTER TABLE ONLY public.payment_invoice DROP CONSTRAINT payment_invoice_fk_2;
ALTER TABLE ONLY public.payment_invoice DROP CONSTRAINT payment_invoice_fk_1;
ALTER TABLE ONLY public.payment_instrument_info DROP CONSTRAINT "payment_instrument_info_FK4";
ALTER TABLE ONLY public.payment_instrument_info DROP CONSTRAINT "payment_instrument_info_FK3";
ALTER TABLE ONLY public.payment_instrument_info DROP CONSTRAINT "payment_instrument_info_FK2";
ALTER TABLE ONLY public.payment_instrument_info DROP CONSTRAINT "payment_instrument_info_FK1";
ALTER TABLE ONLY public.payment_information_meta_fields_map DROP CONSTRAINT "payment_information_meta_fields_map_FK2";
ALTER TABLE ONLY public.payment_information_meta_fields_map DROP CONSTRAINT "payment_information_meta_fields_map_FK1";
ALTER TABLE ONLY public.payment_information DROP CONSTRAINT "payment_information_FK2";
ALTER TABLE ONLY public.payment_information DROP CONSTRAINT "payment_information_FK1";
ALTER TABLE ONLY public.payment DROP CONSTRAINT payment_fk_7;
ALTER TABLE ONLY public.payment DROP CONSTRAINT payment_fk_6;
ALTER TABLE ONLY public.payment DROP CONSTRAINT payment_fk_5;
ALTER TABLE ONLY public.payment DROP CONSTRAINT payment_fk_3;
ALTER TABLE ONLY public.payment DROP CONSTRAINT payment_fk_2;
ALTER TABLE ONLY public.payment_authorization DROP CONSTRAINT payment_authorization_fk_1;
ALTER TABLE ONLY public.partner_payout DROP CONSTRAINT partner_payout_fk_1;
ALTER TABLE ONLY public.partner_meta_field_map DROP CONSTRAINT partner_meta_field_map_fk_2;
ALTER TABLE ONLY public.partner_meta_field_map DROP CONSTRAINT partner_meta_field_map_fk_1;
ALTER TABLE ONLY public.partner DROP CONSTRAINT partner_fk_4;
ALTER TABLE ONLY public.partner_commission DROP CONSTRAINT "partner_commission_currency_id_FK";
ALTER TABLE ONLY public.item_type DROP CONSTRAINT parent_id_fk;
ALTER TABLE ONLY public.order_process DROP CONSTRAINT order_process_fk_1;
ALTER TABLE ONLY public.purchase_order DROP CONSTRAINT order_primary_order_fk_1;
ALTER TABLE ONLY public.order_period DROP CONSTRAINT order_period_fk_2;
ALTER TABLE ONLY public.order_period DROP CONSTRAINT order_period_fk_1;
ALTER TABLE ONLY public.order_meta_field_map DROP CONSTRAINT order_meta_field_map_fk_2;
ALTER TABLE ONLY public.order_meta_field_map DROP CONSTRAINT order_meta_field_map_fk_1;
ALTER TABLE ONLY public.order_line DROP CONSTRAINT order_line_parent_line_id_fk;
ALTER TABLE ONLY public.order_line DROP CONSTRAINT order_line_fk_3;
ALTER TABLE ONLY public.order_line DROP CONSTRAINT order_line_fk_2;
ALTER TABLE ONLY public.order_line DROP CONSTRAINT order_line_fk_1;
ALTER TABLE ONLY public.order_change DROP CONSTRAINT order_change_user_status_id_fk;
ALTER TABLE ONLY public.order_change DROP CONSTRAINT order_change_user_id_fk;
ALTER TABLE ONLY public.order_change_type_meta_field_map DROP CONSTRAINT order_change_type_meta_field_map_meta_field_id_fk;
ALTER TABLE ONLY public.order_change_type_meta_field_map DROP CONSTRAINT order_change_type_meta_field_map_change_type_id_fk;
ALTER TABLE ONLY public.order_change_type_item_type_map DROP CONSTRAINT order_change_type_item_type_map_item_type_id_fk;
ALTER TABLE ONLY public.order_change_type_item_type_map DROP CONSTRAINT order_change_type_item_type_map_change_type_id_fk;
ALTER TABLE ONLY public.order_change_type DROP CONSTRAINT order_change_type_entity_id_fk;
ALTER TABLE ONLY public.order_change DROP CONSTRAINT order_change_status_id_fk;
ALTER TABLE ONLY public.order_change DROP CONSTRAINT order_change_parent_order_line_id_fk;
ALTER TABLE ONLY public.order_change DROP CONSTRAINT order_change_parent_order_change_fk;
ALTER TABLE ONLY public.order_change DROP CONSTRAINT order_change_order_status_id_fk;
ALTER TABLE ONLY public.order_change DROP CONSTRAINT order_change_order_line_id_fk;
ALTER TABLE ONLY public.order_change DROP CONSTRAINT order_change_order_id_fk;
ALTER TABLE ONLY public.order_change DROP CONSTRAINT order_change_order_change_type_id_fk;
ALTER TABLE ONLY public.order_change_meta_field_map DROP CONSTRAINT order_change_meta_field_map_fk_2;
ALTER TABLE ONLY public.order_change_meta_field_map DROP CONSTRAINT order_change_meta_field_map_fk_1;
ALTER TABLE ONLY public.order_change DROP CONSTRAINT order_change_item_id_fk;
ALTER TABLE ONLY public.order_change_asset_map DROP CONSTRAINT order_change_asset_map_change_id_fk;
ALTER TABLE ONLY public.order_change_asset_map DROP CONSTRAINT order_change_asset_map_asset_id_fk;
ALTER TABLE ONLY public.order_line_meta_fields_map DROP CONSTRAINT ol_meta_fields_map_fk_2;
ALTER TABLE ONLY public.order_line_meta_fields_map DROP CONSTRAINT ol_meta_fields_map_fk_1;
ALTER TABLE ONLY public.order_line_meta_field_map DROP CONSTRAINT ol_meta_field_map_fk_2;
ALTER TABLE ONLY public.order_line_meta_field_map DROP CONSTRAINT ol_meta_field_map_fk_1;
ALTER TABLE ONLY public.notification_message_section DROP CONSTRAINT notification_msg_section_fk_1;
ALTER TABLE ONLY public.notification_message_line DROP CONSTRAINT notification_message_line_fk_1;
ALTER TABLE ONLY public.notification_message DROP CONSTRAINT notification_message_fk_3;
ALTER TABLE ONLY public.notification_message DROP CONSTRAINT notification_message_fk_2;
ALTER TABLE ONLY public.notification_message DROP CONSTRAINT notification_message_fk_1;
ALTER TABLE ONLY public.notification_message_arch_line DROP CONSTRAINT notif_mess_arch_line_fk_1;
ALTER TABLE ONLY public.meta_field_value DROP CONSTRAINT meta_field_value_fk_1;
ALTER TABLE ONLY public.meta_field_name DROP CONSTRAINT meta_field_name_fk_1;
ALTER TABLE ONLY public.meta_field_group DROP CONSTRAINT "meta_field_group_entity_FK1";
ALTER TABLE ONLY public.meta_field_group DROP CONSTRAINT "meta_field_group_account_type_FK2";
ALTER TABLE ONLY public.meta_field_name DROP CONSTRAINT meta_field_entity_id_fk;
ALTER TABLE ONLY public.matching_field DROP CONSTRAINT "matching_field_route_id_FK";
ALTER TABLE ONLY public.item_type_meta_field_map DROP CONSTRAINT item_type_meta_field_value_fk;
ALTER TABLE ONLY public.item_type_meta_field_map DROP CONSTRAINT item_type_meta_field_type_fk;
ALTER TABLE ONLY public.item_type_meta_field_def_map DROP CONSTRAINT item_type_meta_field_def_map_fk_2;
ALTER TABLE ONLY public.item_type_meta_field_def_map DROP CONSTRAINT item_type_meta_field_def_map_fk_1;
ALTER TABLE ONLY public.item_type_map DROP CONSTRAINT item_type_map_fk_2;
ALTER TABLE ONLY public.item_type_map DROP CONSTRAINT item_type_map_fk_1;
ALTER TABLE ONLY public.item_type DROP CONSTRAINT item_type_fk_1;
ALTER TABLE ONLY public.item_type_exclude_map DROP CONSTRAINT item_type_exclude_type_id_fk;
ALTER TABLE ONLY public.item_type_exclude_map DROP CONSTRAINT item_type_exclude_item_id_fk;
ALTER TABLE ONLY public.item_type_entity_map DROP CONSTRAINT item_type_entity_map_fk2;
ALTER TABLE ONLY public.item_type_entity_map DROP CONSTRAINT item_type_entity_map_fk1;
ALTER TABLE ONLY public.item_price DROP CONSTRAINT item_price_fk_2;
ALTER TABLE ONLY public.item_price DROP CONSTRAINT item_price_fk_1;
ALTER TABLE ONLY public.item_meta_field_map DROP CONSTRAINT item_meta_field_map_fk_2;
ALTER TABLE ONLY public.item_meta_field_map DROP CONSTRAINT item_meta_field_map_fk_1;
ALTER TABLE ONLY public.item DROP CONSTRAINT item_fk_1;
ALTER TABLE ONLY public.item_entity_map DROP CONSTRAINT item_entity_map_fk2;
ALTER TABLE ONLY public.item_entity_map DROP CONSTRAINT item_entity_map_fk1;
ALTER TABLE ONLY public.item_dependency DROP CONSTRAINT item_dependency_fk3;
ALTER TABLE ONLY public.item_dependency DROP CONSTRAINT item_dependency_fk2;
ALTER TABLE ONLY public.item_dependency DROP CONSTRAINT item_dependency_fk1;
ALTER TABLE ONLY public.invoice_meta_field_map DROP CONSTRAINT invoice_meta_field_map_fk_2;
ALTER TABLE ONLY public.invoice_meta_field_map DROP CONSTRAINT invoice_meta_field_map_fk_1;
ALTER TABLE ONLY public.invoice_line DROP CONSTRAINT invoice_line_fk_4;
ALTER TABLE ONLY public.invoice_line DROP CONSTRAINT invoice_line_fk_3;
ALTER TABLE ONLY public.invoice_line DROP CONSTRAINT invoice_line_fk_2;
ALTER TABLE ONLY public.invoice_line DROP CONSTRAINT invoice_line_fk_1;
ALTER TABLE ONLY public.invoice DROP CONSTRAINT invoice_fk_4;
ALTER TABLE ONLY public.invoice DROP CONSTRAINT invoice_fk_3;
ALTER TABLE ONLY public.invoice DROP CONSTRAINT invoice_fk_2;
ALTER TABLE ONLY public.invoice DROP CONSTRAINT invoice_fk_1;
ALTER TABLE ONLY public.account_type DROP CONSTRAINT "invoice_delivery_method_id_FK";
ALTER TABLE ONLY public.international_description DROP CONSTRAINT international_description_fk_1;
ALTER TABLE ONLY public.generic_status DROP CONSTRAINT generic_status_fk_1;
ALTER TABLE ONLY public.generic_status DROP CONSTRAINT generic_status_entity_id_fk;
ALTER TABLE ONLY public.charge_sessions DROP CONSTRAINT fk_sessions_user;
ALTER TABLE ONLY public.reserved_amounts DROP CONSTRAINT fk_reservations_session;
ALTER TABLE ONLY public.event_log DROP CONSTRAINT event_log_fk_6;
ALTER TABLE ONLY public.event_log DROP CONSTRAINT event_log_fk_5;
ALTER TABLE ONLY public.event_log DROP CONSTRAINT event_log_fk_4;
ALTER TABLE ONLY public.event_log DROP CONSTRAINT event_log_fk_3;
ALTER TABLE ONLY public.event_log DROP CONSTRAINT event_log_fk_2;
ALTER TABLE ONLY public.event_log DROP CONSTRAINT event_log_fk_1;
ALTER TABLE ONLY public.enumeration_values DROP CONSTRAINT enumeration_values_fk_1;
ALTER TABLE ONLY public.entity_payment_method_map DROP CONSTRAINT entity_payment_method_map_fk_2;
ALTER TABLE ONLY public.entity_payment_method_map DROP CONSTRAINT entity_payment_method_map_fk_1;
ALTER TABLE ONLY public.entity DROP CONSTRAINT entity_fk_3;
ALTER TABLE ONLY public.entity DROP CONSTRAINT entity_fk_2;
ALTER TABLE ONLY public.entity DROP CONSTRAINT entity_fk_1;
ALTER TABLE ONLY public.entity_delivery_method_map DROP CONSTRAINT entity_delivry_methd_map_fk2;
ALTER TABLE ONLY public.entity_delivery_method_map DROP CONSTRAINT entity_delivry_methd_map_fk1;
ALTER TABLE ONLY public.discount_line DROP CONSTRAINT discount_line_order_line_id_fk;
ALTER TABLE ONLY public.discount_line DROP CONSTRAINT discount_line_order_id_fk;
ALTER TABLE ONLY public.discount_line DROP CONSTRAINT discount_line_item_id_fk;
ALTER TABLE ONLY public.discount_line DROP CONSTRAINT discount_line_discount_id_fk;
ALTER TABLE ONLY public.discount DROP CONSTRAINT discount_entity_id_fk;
ALTER TABLE ONLY public.discount_attribute DROP CONSTRAINT discount_attr_id_fk;
ALTER TABLE ONLY public.data_table_query DROP CONSTRAINT "data_table_query_next_FK";
ALTER TABLE ONLY public.data_table_query_entry DROP CONSTRAINT "data_table_query_entry_next_FK";
ALTER TABLE ONLY public.customer_notes DROP CONSTRAINT "customer_notes_user_id_FK";
ALTER TABLE ONLY public.customer_notes DROP CONSTRAINT "customer_notes_entity_id_FK";
ALTER TABLE ONLY public.customer_notes DROP CONSTRAINT "customer_notes_customer_id_FK";
ALTER TABLE ONLY public.customer_meta_field_map DROP CONSTRAINT customer_meta_field_map_fk_2;
ALTER TABLE ONLY public.customer_meta_field_map DROP CONSTRAINT customer_meta_field_map_fk_1;
ALTER TABLE ONLY public.customer DROP CONSTRAINT "customer_main_subscription_period_FK";
ALTER TABLE ONLY public.customer DROP CONSTRAINT customer_fk_3;
ALTER TABLE ONLY public.customer DROP CONSTRAINT customer_fk_2;
ALTER TABLE ONLY public.customer DROP CONSTRAINT customer_fk_1;
ALTER TABLE ONLY public.customer DROP CONSTRAINT customer_account_type_fk;
ALTER TABLE ONLY public.customer_account_info_type_timeline DROP CONSTRAINT customer_account_info_type_timeline_meta_field_value_id_fk;
ALTER TABLE ONLY public.customer_account_info_type_timeline DROP CONSTRAINT customer_account_info_type_timeline_customer_id_fk;
ALTER TABLE ONLY public.customer_account_info_type_timeline DROP CONSTRAINT customer_account_info_type_timeline_account_info_type_id_fk;
ALTER TABLE ONLY public.currency_exchange DROP CONSTRAINT currency_exchange_fk_1;
ALTER TABLE ONLY public.currency_entity_map DROP CONSTRAINT currency_entity_map_fk_2;
ALTER TABLE ONLY public.currency_entity_map DROP CONSTRAINT currency_entity_map_fk_1;
ALTER TABLE ONLY public.contact_map DROP CONSTRAINT contact_map_fk_3;
ALTER TABLE ONLY public.contact_map DROP CONSTRAINT contact_map_fk_1;
ALTER TABLE ONLY public.notification_message_type DROP CONSTRAINT category_id_fk_1;
ALTER TABLE ONLY public.blacklist DROP CONSTRAINT blacklist_fk_4;
ALTER TABLE ONLY public.blacklist DROP CONSTRAINT blacklist_fk_2;
ALTER TABLE ONLY public.blacklist DROP CONSTRAINT blacklist_fk_1;
ALTER TABLE ONLY public.billing_process DROP CONSTRAINT billing_process_fk_3;
ALTER TABLE ONLY public.billing_process DROP CONSTRAINT billing_process_fk_2;
ALTER TABLE ONLY public.billing_process DROP CONSTRAINT billing_process_fk_1;
ALTER TABLE ONLY public.billing_process_configuration DROP CONSTRAINT billing_proc_configtn_fk_2;
ALTER TABLE ONLY public.billing_process_configuration DROP CONSTRAINT billing_proc_configtn_fk_1;
ALTER TABLE ONLY public.base_user DROP CONSTRAINT base_user_fk_6;
ALTER TABLE ONLY public.base_user DROP CONSTRAINT base_user_fk_5;
ALTER TABLE ONLY public.base_user DROP CONSTRAINT base_user_fk_4;
ALTER TABLE ONLY public.base_user DROP CONSTRAINT base_user_fk_3;
ALTER TABLE ONLY public.asset_transition DROP CONSTRAINT asset_transition_fk_5;
ALTER TABLE ONLY public.asset_transition DROP CONSTRAINT asset_transition_fk_4;
ALTER TABLE ONLY public.asset_transition DROP CONSTRAINT asset_transition_fk_3;
ALTER TABLE ONLY public.asset_transition DROP CONSTRAINT asset_transition_fk_2;
ALTER TABLE ONLY public.asset_transition DROP CONSTRAINT asset_transition_fk_1;
ALTER TABLE ONLY public.asset_status DROP CONSTRAINT asset_status_fk_1;
ALTER TABLE ONLY public.asset_reservation DROP CONSTRAINT asset_reservation_fk_3;
ALTER TABLE ONLY public.asset_reservation DROP CONSTRAINT asset_reservation_fk_2;
ALTER TABLE ONLY public.asset_reservation DROP CONSTRAINT asset_reservation_fk_1;
ALTER TABLE ONLY public.asset_meta_field_map DROP CONSTRAINT asset_meta_field_map_fk_2;
ALTER TABLE ONLY public.asset_meta_field_map DROP CONSTRAINT asset_meta_field_map_fk_1;
ALTER TABLE ONLY public.asset DROP CONSTRAINT asset_fk_4;
ALTER TABLE ONLY public.asset DROP CONSTRAINT asset_fk_3;
ALTER TABLE ONLY public.asset DROP CONSTRAINT asset_fk_2;
ALTER TABLE ONLY public.asset DROP CONSTRAINT asset_fk_1;
ALTER TABLE ONLY public.asset_entity_map DROP CONSTRAINT asset_entity_map_fk2;
ALTER TABLE ONLY public.asset_entity_map DROP CONSTRAINT asset_entity_map_fk1;
ALTER TABLE ONLY public.asset_assignment DROP CONSTRAINT asset_assignment_fk_2;
ALTER TABLE ONLY public.asset_assignment DROP CONSTRAINT asset_assignment_fk_1;
ALTER TABLE ONLY public.ageing_entity_step DROP CONSTRAINT ageing_entity_step_fk_2;
ALTER TABLE ONLY public.account_type DROP CONSTRAINT "account_type_main_subscription_period_FK";
ALTER TABLE ONLY public.account_type DROP CONSTRAINT "account_type_language_id_FK";
ALTER TABLE ONLY public.account_type DROP CONSTRAINT "account_type_entity_id_FK";
ALTER TABLE ONLY public.account_type DROP CONSTRAINT "account_type_currency_id_FK";
DROP INDEX public.user_role_map_i_2;
DROP INDEX public.user_credit_card_map_i_2;
DROP INDEX public.transaction_id;
DROP INDEX public.purchase_order_i_user;
DROP INDEX public.purchase_order_i_notif;
DROP INDEX public.promotion_user_map_i_2;
DROP INDEX public.payment_i_3;
DROP INDEX public.payment_i_2;
DROP INDEX public.order_change_idx_order_line;
DROP INDEX public.ix_uq_payment_inv_map_pa_in;
DROP INDEX public.ix_uq_order_process_or_in;
DROP INDEX public.ix_uq_order_process_or_bp;
DROP INDEX public.ix_purchase_order_date;
DROP INDEX public.ix_promotion_code;
DROP INDEX public.ix_parent_customer_id;
DROP INDEX public.ix_order_process_in;
DROP INDEX public.ix_item_ent;
DROP INDEX public.ix_invoice_user_id;
DROP INDEX public.ix_invoice_ts;
DROP INDEX public.ix_invoice_number;
DROP INDEX public.ix_invoice_due_date;
DROP INDEX public.ix_invoice_date;
DROP INDEX public.ix_el_main;
DROP INDEX public.ix_contact_phone;
DROP INDEX public.ix_contact_orgname;
DROP INDEX public.ix_contact_lname;
DROP INDEX public.ix_contact_fname_lname;
DROP INDEX public.ix_contact_fname;
DROP INDEX public.ix_contact_address;
DROP INDEX public.ix_blacklist_user_type;
DROP INDEX public.ix_blacklist_entity_type;
DROP INDEX public.ix_base_user_un;
DROP INDEX public.international_description_i_2;
DROP INDEX public.currency_entity_map_i_2;
DROP INDEX public.create_datetime;
DROP INDEX public.contact_map_i_2;
DROP INDEX public.contact_i_del;
DROP INDEX public.bp_pm_index_total;
DROP INDEX public.asset_reservation_end_date_index;
ALTER TABLE ONLY public.validation_rule DROP CONSTRAINT validation_rule_pkey;
ALTER TABLE ONLY public.user_status DROP CONSTRAINT user_status_pkey;
ALTER TABLE ONLY public.user_role_map DROP CONSTRAINT user_role_map_compositekey;
ALTER TABLE ONLY public.user_password_map DROP CONSTRAINT user_password_map_pkey;
ALTER TABLE ONLY public.user_code DROP CONSTRAINT user_code_pkey;
ALTER TABLE ONLY public.user_code_link DROP CONSTRAINT user_code_link_pkey;
ALTER TABLE ONLY public.tab DROP CONSTRAINT tab_pkey;
ALTER TABLE ONLY public.tab_configuration_tab DROP CONSTRAINT tab_configuration_tab_pkey;
ALTER TABLE ONLY public.tab_configuration DROP CONSTRAINT tab_configuration_pkey;
ALTER TABLE ONLY public.sure_tax_txn_log DROP CONSTRAINT sure_tax_txn_log_pkey;
ALTER TABLE ONLY public.shortcut DROP CONSTRAINT shortcut_pkey;
ALTER TABLE ONLY public.route DROP CONSTRAINT route_pkey;
ALTER TABLE ONLY public.role DROP CONSTRAINT role_pkey;
ALTER TABLE ONLY public.reset_password_code DROP CONSTRAINT reset_password_code_base_user_id_key;
ALTER TABLE ONLY public.reserved_amounts DROP CONSTRAINT reserved_amounts_pkey;
ALTER TABLE ONLY public.report_type DROP CONSTRAINT report_type_pkey;
ALTER TABLE ONLY public.report DROP CONSTRAINT report_pkey;
ALTER TABLE ONLY public.report_parameter DROP CONSTRAINT report_parameter_pkey;
ALTER TABLE ONLY public.recent_item DROP CONSTRAINT recent_item_pkey;
ALTER TABLE ONLY public.purchase_order DROP CONSTRAINT purchase_order_pkey;
ALTER TABLE ONLY public.promotion_user_map DROP CONSTRAINT promotion_user_map_compositekey;
ALTER TABLE ONLY public.promotion DROP CONSTRAINT promotion_pkey;
ALTER TABLE ONLY public.process_run_user DROP CONSTRAINT process_run_user_pkey;
ALTER TABLE ONLY public.process_run_total_pm DROP CONSTRAINT process_run_total_pm_pkey;
ALTER TABLE ONLY public.process_run_total DROP CONSTRAINT process_run_total_pkey;
ALTER TABLE ONLY public.process_run DROP CONSTRAINT process_run_pkey;
ALTER TABLE ONLY public.preference_type DROP CONSTRAINT preference_type_pkey;
ALTER TABLE ONLY public.preference DROP CONSTRAINT preference_pkey;
ALTER TABLE ONLY public.pluggable_task_type DROP CONSTRAINT pluggable_task_type_pkey;
ALTER TABLE ONLY public.pluggable_task_type_category DROP CONSTRAINT pluggable_task_type_cat_pkey;
ALTER TABLE ONLY public.pluggable_task DROP CONSTRAINT pluggable_task_pkey;
ALTER TABLE ONLY public.pluggable_task_parameter DROP CONSTRAINT pluggable_task_parameter_pkey;
ALTER TABLE ONLY public.reset_password_code DROP CONSTRAINT pk_reset_password_code;
ALTER TABLE ONLY public.rating_unit DROP CONSTRAINT pk_rating_unit;
ALTER TABLE ONLY public.notification_medium_type DROP CONSTRAINT pk_notification_medium_type;
ALTER TABLE ONLY public.databasechangeloglock DROP CONSTRAINT pk_databasechangeloglock;
ALTER TABLE ONLY public.data_table_query_entry DROP CONSTRAINT pk_data_table_query_entry;
ALTER TABLE ONLY public.data_table_query DROP CONSTRAINT pk_data_table_query;
ALTER TABLE ONLY public.customer_notes DROP CONSTRAINT pk_customer_notes;
ALTER TABLE ONLY public.period_unit DROP CONSTRAINT period_unit_pkey;
ALTER TABLE ONLY public.payment_result DROP CONSTRAINT payment_result_pkey;
ALTER TABLE ONLY public.payment DROP CONSTRAINT payment_pkey;
ALTER TABLE ONLY public.payment_method_type DROP CONSTRAINT payment_method_type_pkey;
ALTER TABLE ONLY public.payment_method_template DROP CONSTRAINT payment_method_template_template_name_key;
ALTER TABLE ONLY public.payment_method_template DROP CONSTRAINT payment_method_template_pkey;
ALTER TABLE ONLY public.payment_method DROP CONSTRAINT payment_method_pkey;
ALTER TABLE ONLY public.payment_meta_field_map DROP CONSTRAINT payment_meta_field_map_compositekey;
ALTER TABLE ONLY public.payment_invoice DROP CONSTRAINT payment_invoice_pkey;
ALTER TABLE ONLY public.payment_instrument_info DROP CONSTRAINT payment_instrument_info_pkey;
ALTER TABLE ONLY public.payment_information DROP CONSTRAINT payment_information_pkey;
ALTER TABLE ONLY public.payment_authorization DROP CONSTRAINT payment_authorization_pkey;
ALTER TABLE ONLY public.partner DROP CONSTRAINT partner_pkey;
ALTER TABLE ONLY public.partner_payout DROP CONSTRAINT partner_payout_pkey;
ALTER TABLE ONLY public.partner_meta_field_map DROP CONSTRAINT partner_meta_field_map_compositekey;
ALTER TABLE ONLY public.paper_invoice_batch DROP CONSTRAINT paper_invoice_batch_pkey;
ALTER TABLE ONLY public.order_status DROP CONSTRAINT order_status_pkey;
ALTER TABLE ONLY public.order_process DROP CONSTRAINT order_process_pkey;
ALTER TABLE ONLY public.order_period DROP CONSTRAINT order_period_pkey;
ALTER TABLE ONLY public.order_meta_field_map DROP CONSTRAINT order_meta_field_map_compositekey;
ALTER TABLE ONLY public.order_line_type DROP CONSTRAINT order_line_type_pkey;
ALTER TABLE ONLY public.order_line DROP CONSTRAINT order_line_pkey;
ALTER TABLE ONLY public.order_change_type DROP CONSTRAINT order_change_type_pkey;
ALTER TABLE ONLY public.order_change DROP CONSTRAINT order_change_pkey;
ALTER TABLE ONLY public.order_billing_type DROP CONSTRAINT order_billing_type_pkey;
ALTER TABLE ONLY public.notification_message_type DROP CONSTRAINT notifictn_msg_type_pkey;
ALTER TABLE ONLY public.notification_message_section DROP CONSTRAINT notifictn_msg_section_pkey;
ALTER TABLE ONLY public.notification_message DROP CONSTRAINT notifictn_msg_pkey;
ALTER TABLE ONLY public.notification_message_line DROP CONSTRAINT notifictn_msg_line_pkey;
ALTER TABLE ONLY public.notification_message_arch DROP CONSTRAINT notifictn_msg_arch_pkey;
ALTER TABLE ONLY public.notification_message_arch_line DROP CONSTRAINT notifictn_msg_arch_line_pkey;
ALTER TABLE ONLY public.notification_category DROP CONSTRAINT notification_category_pk;
ALTER TABLE ONLY public.meta_field_group DROP CONSTRAINT metafield_group_pkey;
ALTER TABLE ONLY public.meta_field_value DROP CONSTRAINT meta_field_value_id_key;
ALTER TABLE ONLY public.meta_field_name DROP CONSTRAINT meta_field_name_pkey;
ALTER TABLE ONLY public.matching_field DROP CONSTRAINT matching_field_pkey;
ALTER TABLE ONLY public.language DROP CONSTRAINT language_pkey;
ALTER TABLE ONLY public.jbilling_table DROP CONSTRAINT jbilling_table_pkey;
ALTER TABLE ONLY public.jbilling_seqs DROP CONSTRAINT jbilling_seqs_pk;
ALTER TABLE ONLY public.item_type DROP CONSTRAINT item_type_pkey;
ALTER TABLE ONLY public.item_type_map DROP CONSTRAINT item_type_map_compositekey;
ALTER TABLE ONLY public.item_type_exclude_map DROP CONSTRAINT item_type_exclude_map_pkey;
ALTER TABLE ONLY public.item_price DROP CONSTRAINT item_price_pkey;
ALTER TABLE ONLY public.item DROP CONSTRAINT item_pkey;
ALTER TABLE ONLY public.item_meta_field_map DROP CONSTRAINT item_meta_field_map_compositekey;
ALTER TABLE ONLY public.item_entity_map DROP CONSTRAINT item_entity_map_uc_1;
ALTER TABLE ONLY public.item_dependency DROP CONSTRAINT item_dependency_pk;
ALTER TABLE ONLY public.invoice DROP CONSTRAINT invoice_pkey;
ALTER TABLE ONLY public.invoice_meta_field_map DROP CONSTRAINT invoice_meta_field_map_compositekey;
ALTER TABLE ONLY public.invoice_line_type DROP CONSTRAINT invoice_line_type_pkey;
ALTER TABLE ONLY public.invoice_line DROP CONSTRAINT invoice_line_pkey;
ALTER TABLE ONLY public.invoice_delivery_method DROP CONSTRAINT invoice_delivery_method_pkey;
ALTER TABLE ONLY public.international_description DROP CONSTRAINT international_description_pkey;
ALTER TABLE ONLY public.generic_status_type DROP CONSTRAINT generic_status_type_pkey;
ALTER TABLE ONLY public.generic_status DROP CONSTRAINT generic_status_pkey;
ALTER TABLE ONLY public.filter_set DROP CONSTRAINT filter_set_pkey;
ALTER TABLE ONLY public.filter DROP CONSTRAINT filter_pkey;
ALTER TABLE ONLY public.event_log DROP CONSTRAINT event_log_pkey;
ALTER TABLE ONLY public.event_log_module DROP CONSTRAINT event_log_module_pkey;
ALTER TABLE ONLY public.event_log_message DROP CONSTRAINT event_log_message_pkey;
ALTER TABLE ONLY public.enumeration_values DROP CONSTRAINT enumeration_values_pkey;
ALTER TABLE ONLY public.enumeration DROP CONSTRAINT enumeration_pkey;
ALTER TABLE ONLY public.ageing_entity_step DROP CONSTRAINT entity_step_days;
ALTER TABLE ONLY public.entity_report_map DROP CONSTRAINT entity_report_map_compositekey;
ALTER TABLE ONLY public.entity DROP CONSTRAINT entity_pkey;
ALTER TABLE ONLY public.entity_payment_method_map DROP CONSTRAINT entity_payment_method_map_compositekey;
ALTER TABLE ONLY public.entity_delivery_method_map DROP CONSTRAINT entity_delivery_method_map_compositekey;
ALTER TABLE ONLY public.discount DROP CONSTRAINT discount_pkey;
ALTER TABLE ONLY public.discount_line DROP CONSTRAINT discount_line_pkey;
ALTER TABLE ONLY public.discount_attribute DROP CONSTRAINT discount_attribute_pkey;
ALTER TABLE ONLY public.customer DROP CONSTRAINT customer_pkey;
ALTER TABLE ONLY public.customer_meta_field_map DROP CONSTRAINT customer_meta_field_map_compositekey;
ALTER TABLE ONLY public.customer_account_info_type_timeline DROP CONSTRAINT customer_account_info_type_timeline_uk;
ALTER TABLE ONLY public.customer_account_info_type_timeline DROP CONSTRAINT customer_account_info_type_timeline_pkey;
ALTER TABLE ONLY public.currency DROP CONSTRAINT currency_pkey;
ALTER TABLE ONLY public.currency_exchange DROP CONSTRAINT currency_exchange_pkey;
ALTER TABLE ONLY public.currency_entity_map DROP CONSTRAINT currency_entity_map_compositekey;
ALTER TABLE ONLY public.country DROP CONSTRAINT country_pkey;
ALTER TABLE ONLY public.contact DROP CONSTRAINT contact_pkey;
ALTER TABLE ONLY public.contact_map DROP CONSTRAINT contact_map_pkey;
ALTER TABLE ONLY public.charge_sessions DROP CONSTRAINT charge_sessions_pkey;
ALTER TABLE ONLY public.cdrentries DROP CONSTRAINT cdrentries_pkey;
ALTER TABLE ONLY public.breadcrumb DROP CONSTRAINT breadcrumb_pkey;
ALTER TABLE ONLY public.blacklist DROP CONSTRAINT blacklist_pkey;
ALTER TABLE ONLY public.billing_process DROP CONSTRAINT billing_process_pkey;
ALTER TABLE ONLY public.batch_process_info DROP CONSTRAINT billing_process_info_pkey;
ALTER TABLE ONLY public.billing_process_failed_user DROP CONSTRAINT billing_process_failed_user_pkey;
ALTER TABLE ONLY public.billing_process_configuration DROP CONSTRAINT billing_process_config_pkey;
ALTER TABLE ONLY public.batch_step_execution DROP CONSTRAINT batch_step_execution_pkey;
ALTER TABLE ONLY public.batch_step_execution_context DROP CONSTRAINT batch_step_execution_context_pkey;
ALTER TABLE ONLY public.batch_job_instance DROP CONSTRAINT batch_job_instance_pkey;
ALTER TABLE ONLY public.batch_job_execution DROP CONSTRAINT batch_job_execution_pkey;
ALTER TABLE ONLY public.batch_job_execution_context DROP CONSTRAINT batch_job_execution_context_pkey;
ALTER TABLE ONLY public.base_user DROP CONSTRAINT base_user_pkey;
ALTER TABLE ONLY public.asset_transition DROP CONSTRAINT asset_transition_pkey;
ALTER TABLE ONLY public.asset_status DROP CONSTRAINT asset_status_pkey;
ALTER TABLE ONLY public.asset_reservation DROP CONSTRAINT asset_reservation_pkey;
ALTER TABLE ONLY public.asset DROP CONSTRAINT asset_pkey;
ALTER TABLE ONLY public.asset_entity_map DROP CONSTRAINT asset_entity_map_uc_1;
ALTER TABLE ONLY public.asset_assignment DROP CONSTRAINT asset_assignment_pkey;
ALTER TABLE ONLY public.ageing_entity_step DROP CONSTRAINT ageing_entity_step_pkey;
ALTER TABLE ONLY public.account_type DROP CONSTRAINT account_type_pkey;
DROP TABLE public.validation_rule_attributes;
DROP TABLE public.validation_rule;
DROP TABLE public.user_status;
DROP TABLE public.user_role_map;
DROP TABLE public.user_password_map;
DROP TABLE public.user_credit_card_map;
DROP SEQUENCE public.user_credit_card_map_id_seq;
DROP TABLE public.user_code_link;
DROP TABLE public.user_code;
DROP TABLE public.tab_configuration_tab;
DROP TABLE public.tab_configuration;
DROP TABLE public.tab;
DROP TABLE public.sure_tax_txn_log;
DROP TABLE public.shortcut;
DROP TABLE public.route;
DROP TABLE public.role;
DROP TABLE public.reset_password_code;
DROP TABLE public.reserved_amounts;
DROP TABLE public.reseller_entityid_map;
DROP TABLE public.report_type;
DROP TABLE public.report_parameter;
DROP TABLE public.report;
DROP TABLE public.recent_item;
DROP TABLE public.rating_unit;
DROP TABLE public.purchase_order;
DROP TABLE public.promotion_user_map;
DROP TABLE public.promotion;
DROP TABLE public.process_run_user;
DROP TABLE public.process_run_total_pm;
DROP TABLE public.process_run_total;
DROP TABLE public.process_run;
DROP TABLE public.preference_type;
DROP TABLE public.preference;
DROP TABLE public.pluggable_task_type_category;
DROP TABLE public.pluggable_task_type;
DROP TABLE public.pluggable_task_parameter;
DROP TABLE public.pluggable_task;
DROP TABLE public.period_unit;
DROP TABLE public.payment_result;
DROP TABLE public.payment_method_type;
DROP TABLE public.payment_method_template_meta_fields_map;
DROP TABLE public.payment_method_template;
DROP TABLE public.payment_method_meta_fields_map;
DROP TABLE public.payment_method_account_type_map;
DROP TABLE public.payment_method;
DROP TABLE public.payment_meta_field_map;
DROP TABLE public.payment_invoice;
DROP TABLE public.payment_instrument_info;
DROP TABLE public.payment_information_meta_fields_map;
DROP TABLE public.payment_information;
DROP TABLE public.payment_commission;
DROP TABLE public.payment_authorization;
DROP TABLE public.payment;
DROP TABLE public.partner_referral_commission;
DROP TABLE public.partner_payout;
DROP TABLE public.partner_meta_field_map;
DROP TABLE public.partner_commission_process_run;
DROP TABLE public.partner_commission_proc_config;
DROP TABLE public.partner_commission_exception;
DROP TABLE public.partner_commission;
DROP TABLE public.partner;
DROP TABLE public.paper_invoice_batch;
DROP TABLE public.order_status;
DROP TABLE public.order_process;
DROP TABLE public.order_period;
DROP TABLE public.order_meta_field_map;
DROP TABLE public.order_line_type;
DROP TABLE public.order_line_meta_fields_map;
DROP TABLE public.order_line_meta_field_map;
DROP TABLE public.order_line;
DROP TABLE public.order_change_type_meta_field_map;
DROP TABLE public.order_change_type_item_type_map;
DROP TABLE public.order_change_type;
DROP TABLE public.order_change_meta_field_map;
DROP TABLE public.order_change_asset_map;
DROP TABLE public.order_change;
DROP TABLE public.order_billing_type;
DROP TABLE public.notification_message_type;
DROP TABLE public.notification_message_section;
DROP TABLE public.notification_message_line;
DROP TABLE public.notification_message_arch_line;
DROP TABLE public.notification_message_arch;
DROP TABLE public.notification_message;
DROP TABLE public.notification_medium_type;
DROP TABLE public.notification_category;
DROP TABLE public.metafield_group_meta_field_map;
DROP TABLE public.meta_field_value;
DROP TABLE public.meta_field_name;
DROP TABLE public.meta_field_group;
DROP TABLE public.matching_field;
DROP TABLE public.list_meta_field_values;
DROP SEQUENCE public.list_meta_field_values_id_seq;
DROP TABLE public.language;
DROP TABLE public.jbilling_table;
DROP TABLE public.jbilling_seqs;
DROP TABLE public.item_type_meta_field_map;
DROP TABLE public.item_type_meta_field_def_map;
DROP TABLE public.item_type_map;
DROP TABLE public.item_type_exclude_map;
DROP TABLE public.item_type_entity_map;
DROP TABLE public.item_type;
DROP TABLE public.item_price;
DROP TABLE public.item_meta_field_map;
DROP TABLE public.item_entity_map;
DROP TABLE public.item_dependency;
DROP TABLE public.item_account_type_availability;
DROP TABLE public.item;
DROP TABLE public.invoice_meta_field_map;
DROP TABLE public.invoice_line_type;
DROP TABLE public.invoice_line;
DROP TABLE public.invoice_delivery_method;
DROP TABLE public.invoice_commission;
DROP TABLE public.invoice;
DROP TABLE public.international_description;
DROP TABLE public.generic_status_type;
DROP TABLE public.generic_status;
DROP TABLE public.filter_set_filter;
DROP SEQUENCE public.filter_set_filter_id_seq;
DROP TABLE public.filter_set;
DROP TABLE public.filter;
DROP TABLE public.event_log_module;
DROP TABLE public.event_log_message;
DROP TABLE public.event_log;
DROP TABLE public.enumeration_values;
DROP TABLE public.enumeration;
DROP TABLE public.entity_report_map;
DROP TABLE public.entity_payment_method_map;
DROP TABLE public.entity_delivery_method_map;
DROP TABLE public.entity;
DROP TABLE public.discount_line;
DROP TABLE public.discount_attribute;
DROP TABLE public.discount;
DROP TABLE public.databasechangeloglock;
DROP TABLE public.databasechangelog;
DROP TABLE public.data_table_query_entry;
DROP TABLE public.data_table_query;
DROP TABLE public.customer_notes;
DROP TABLE public.customer_meta_field_map;
DROP TABLE public.customer_account_info_type_timeline;
DROP TABLE public.customer;
DROP TABLE public.currency_exchange;
DROP TABLE public.currency_entity_map;
DROP TABLE public.currency;
DROP TABLE public.country;
DROP TABLE public.contact_map;
DROP TABLE public.contact;
DROP TABLE public.charge_sessions;
DROP TABLE public.cdrentries;
DROP TABLE public.breadcrumb;
DROP TABLE public.blacklist;
DROP TABLE public.billing_process_failed_user;
DROP TABLE public.billing_process_configuration;
DROP TABLE public.billing_process;
DROP SEQUENCE public.batch_step_execution_seq;
DROP TABLE public.batch_step_execution_context;
DROP TABLE public.batch_step_execution;
DROP TABLE public.batch_process_info;
DROP SEQUENCE public.batch_job_seq;
DROP TABLE public.batch_job_instance;
DROP SEQUENCE public.batch_job_execution_seq;
DROP TABLE public.batch_job_execution_params;
DROP TABLE public.batch_job_execution_context;
DROP TABLE public.batch_job_execution;
DROP TABLE public.base_user;
DROP TABLE public.asset_transition;
DROP TABLE public.asset_status;
DROP TABLE public.asset_reservation;
DROP TABLE public.asset_meta_field_map;
DROP TABLE public.asset_entity_map;
DROP TABLE public.asset_assignment;
DROP TABLE public.asset;
DROP TABLE public.ageing_entity_step;
DROP TABLE public.account_type_price;
DROP TABLE public.account_type;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE account_type (
    id integer NOT NULL,
    credit_limit numeric(22,10),
    invoice_design character varying(100),
    invoice_delivery_method_id integer,
    date_created timestamp without time zone,
    credit_notification_limit1 numeric(22,10),
    credit_notification_limit2 numeric(22,10),
    language_id integer,
    entity_id integer,
    currency_id integer,
    optlock integer NOT NULL,
    main_subscript_order_period_id integer NOT NULL,
    next_invoice_day_of_period integer NOT NULL,
    notification_ait_id integer
);


ALTER TABLE account_type OWNER TO jbilling;

--
-- Name: account_type_price; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE account_type_price (
    account_type_id integer NOT NULL,
    create_datetime timestamp without time zone NOT NULL,
    price_expiry_date date
);


ALTER TABLE account_type_price OWNER TO jbilling;

--
-- Name: ageing_entity_step; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE ageing_entity_step (
    id integer NOT NULL,
    entity_id integer,
    status_id integer,
    days integer NOT NULL,
    optlock integer NOT NULL,
    retry_payment smallint DEFAULT 0 NOT NULL,
    suspend smallint DEFAULT 0 NOT NULL,
    send_notification smallint DEFAULT 0 NOT NULL
);


ALTER TABLE ageing_entity_step OWNER TO jbilling;

--
-- Name: asset; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE asset (
    id integer NOT NULL,
    identifier character varying(200) NOT NULL,
    create_datetime timestamp without time zone NOT NULL,
    status_id integer NOT NULL,
    entity_id integer,
    deleted integer NOT NULL,
    item_id integer NOT NULL,
    notes character varying(1000),
    optlock integer NOT NULL,
    group_id integer,
    order_line_id integer,
    global boolean DEFAULT false NOT NULL
);


ALTER TABLE asset OWNER TO jbilling;

--
-- Name: asset_assignment; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE asset_assignment (
    id integer NOT NULL,
    asset_id integer NOT NULL,
    order_line_id integer NOT NULL,
    start_datetime timestamp without time zone NOT NULL,
    end_datetime timestamp without time zone
);


ALTER TABLE asset_assignment OWNER TO jbilling;

--
-- Name: asset_entity_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE asset_entity_map (
    asset_id integer NOT NULL,
    entity_id integer NOT NULL
);


ALTER TABLE asset_entity_map OWNER TO jbilling;

--
-- Name: asset_meta_field_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE asset_meta_field_map (
    asset_id integer NOT NULL,
    meta_field_value_id integer NOT NULL
);


ALTER TABLE asset_meta_field_map OWNER TO jbilling;

--
-- Name: asset_reservation; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE asset_reservation (
    id integer NOT NULL,
    user_id integer NOT NULL,
    creator_user_id integer NOT NULL,
    asset_id integer NOT NULL,
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE asset_reservation OWNER TO jbilling;

--
-- Name: asset_status; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE asset_status (
    id integer NOT NULL,
    item_type_id integer,
    is_default integer NOT NULL,
    is_order_saved integer NOT NULL,
    is_available integer NOT NULL,
    deleted integer NOT NULL,
    optlock integer NOT NULL,
    is_internal integer DEFAULT 0 NOT NULL
);


ALTER TABLE asset_status OWNER TO jbilling;

--
-- Name: asset_transition; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE asset_transition (
    id integer NOT NULL,
    create_datetime timestamp without time zone NOT NULL,
    previous_status_id integer,
    new_status_id integer NOT NULL,
    asset_id integer NOT NULL,
    user_id integer,
    assigned_to_id integer
);


ALTER TABLE asset_transition OWNER TO jbilling;

--
-- Name: base_user; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE base_user (
    id integer NOT NULL,
    entity_id integer,
    password character varying(1024),
    deleted integer DEFAULT 0 NOT NULL,
    language_id integer,
    status_id integer,
    subscriber_status integer DEFAULT 1,
    currency_id integer,
    create_datetime timestamp without time zone NOT NULL,
    last_status_change timestamp without time zone,
    last_login timestamp without time zone,
    user_name character varying(50),
    failed_attempts integer DEFAULT 0 NOT NULL,
    optlock integer NOT NULL,
    change_password_date date,
    encryption_scheme integer NOT NULL,
    account_locked_time timestamp without time zone,
    account_disabled_date date
);


ALTER TABLE base_user OWNER TO jbilling;

--
-- Name: batch_job_execution; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE batch_job_execution (
    job_execution_id integer NOT NULL,
    version integer,
    job_instance_id integer NOT NULL,
    create_time timestamp without time zone NOT NULL,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    status character varying(10),
    exit_code character varying(100),
    exit_message character varying(2500),
    last_updated timestamp without time zone,
    job_configuration_location character varying(2500)
);


ALTER TABLE batch_job_execution OWNER TO jbilling;

--
-- Name: batch_job_execution_context; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE batch_job_execution_context (
    job_execution_id bigint NOT NULL,
    short_context character varying(2500) NOT NULL,
    serialized_context text
);


ALTER TABLE batch_job_execution_context OWNER TO jbilling;

--
-- Name: batch_job_execution_params; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE batch_job_execution_params (
    job_execution_id integer NOT NULL,
    type_cd character varying(6) NOT NULL,
    key_name character varying(100) NOT NULL,
    string_val character varying(250),
    date_val timestamp without time zone,
    long_val integer,
    double_val numeric(17,0),
    identifying character(1)
);


ALTER TABLE batch_job_execution_params OWNER TO jbilling;

--
-- Name: batch_job_execution_seq; Type: SEQUENCE; Schema: public; Owner: jbilling
--

CREATE SEQUENCE batch_job_execution_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE batch_job_execution_seq OWNER TO jbilling;

--
-- Name: batch_job_instance; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE batch_job_instance (
    job_instance_id integer NOT NULL,
    version integer,
    job_name character varying(100) NOT NULL,
    job_key character varying(32) NOT NULL
);


ALTER TABLE batch_job_instance OWNER TO jbilling;

--
-- Name: batch_job_seq; Type: SEQUENCE; Schema: public; Owner: jbilling
--

CREATE SEQUENCE batch_job_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE batch_job_seq OWNER TO jbilling;

--
-- Name: batch_process_info; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE batch_process_info (
    id integer NOT NULL,
    process_id integer NOT NULL,
    job_execution_id integer NOT NULL,
    total_failed_users integer NOT NULL,
    total_successful_users integer NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE batch_process_info OWNER TO jbilling;

--
-- Name: batch_step_execution; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE batch_step_execution (
    step_execution_id integer NOT NULL,
    version integer NOT NULL,
    step_name character varying(100) NOT NULL,
    job_execution_id integer NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone,
    status character varying(10),
    commit_count integer,
    read_count integer,
    filter_count integer,
    write_count integer,
    read_skip_count integer,
    write_skip_count integer,
    process_skip_count integer,
    rollback_count integer,
    exit_code character varying(100),
    exit_message character varying(2500),
    last_updated timestamp without time zone
);


ALTER TABLE batch_step_execution OWNER TO jbilling;

--
-- Name: batch_step_execution_context; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE batch_step_execution_context (
    step_execution_id integer NOT NULL,
    short_context character varying(2500) NOT NULL,
    serialized_context text
);


ALTER TABLE batch_step_execution_context OWNER TO jbilling;

--
-- Name: batch_step_execution_seq; Type: SEQUENCE; Schema: public; Owner: jbilling
--

CREATE SEQUENCE batch_step_execution_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE batch_step_execution_seq OWNER TO jbilling;

--
-- Name: billing_process; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE billing_process (
    id integer NOT NULL,
    entity_id integer NOT NULL,
    billing_date date NOT NULL,
    period_unit_id integer NOT NULL,
    period_value integer NOT NULL,
    is_review integer NOT NULL,
    paper_invoice_batch_id integer,
    retries_to_do integer DEFAULT 0 NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE billing_process OWNER TO jbilling;

--
-- Name: billing_process_configuration; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE billing_process_configuration (
    id integer NOT NULL,
    entity_id integer,
    next_run_date date NOT NULL,
    generate_report integer NOT NULL,
    retries integer,
    days_for_retry integer,
    days_for_report integer,
    review_status integer NOT NULL,
    due_date_unit_id integer NOT NULL,
    due_date_value integer NOT NULL,
    df_fm integer,
    only_recurring integer DEFAULT 1 NOT NULL,
    invoice_date_process integer NOT NULL,
    optlock integer NOT NULL,
    maximum_periods integer DEFAULT 1 NOT NULL,
    auto_payment_application integer DEFAULT 0 NOT NULL,
    period_unit_id integer DEFAULT 1 NOT NULL,
    last_day_of_month boolean DEFAULT false NOT NULL,
    prorating_type character varying(50) DEFAULT 'PRORATING_AUTO_OFF'::character varying
);


ALTER TABLE billing_process_configuration OWNER TO jbilling;

--
-- Name: billing_process_failed_user; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE billing_process_failed_user (
    id integer NOT NULL,
    batch_process_id integer NOT NULL,
    user_id integer NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE billing_process_failed_user OWNER TO jbilling;

--
-- Name: blacklist; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE blacklist (
    id integer NOT NULL,
    entity_id integer NOT NULL,
    create_datetime timestamp without time zone NOT NULL,
    type integer NOT NULL,
    source integer NOT NULL,
    credit_card integer,
    credit_card_id integer,
    contact_id integer,
    user_id integer,
    optlock integer NOT NULL,
    meta_field_value_id integer
);


ALTER TABLE blacklist OWNER TO jbilling;

--
-- Name: breadcrumb; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE breadcrumb (
    id integer NOT NULL,
    user_id integer NOT NULL,
    controller character varying(255) NOT NULL,
    action character varying(255),
    name character varying(255),
    object_id integer,
    version integer NOT NULL,
    description character varying(255)
);


ALTER TABLE breadcrumb OWNER TO jbilling;

--
-- Name: cdrentries; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE cdrentries (
    id integer NOT NULL,
    accountcode character varying(20),
    src character varying(20),
    dst character varying(20),
    dcontext character varying(20),
    clid character varying(20),
    channel character varying(20),
    dstchannel character varying(20),
    lastapp character varying(20),
    lastdatat character varying(20),
    start_time timestamp without time zone,
    answer timestamp without time zone,
    end_time timestamp without time zone,
    duration integer,
    billsec integer,
    disposition character varying(20),
    amaflags character varying(20),
    userfield character varying(100),
    ts timestamp without time zone
);


ALTER TABLE cdrentries OWNER TO jbilling;

--
-- Name: charge_sessions; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE charge_sessions (
    id integer NOT NULL,
    user_id integer,
    session_token character varying(150),
    ts_started timestamp without time zone,
    ts_last_access timestamp without time zone,
    carried_units numeric(22,10)
);


ALTER TABLE charge_sessions OWNER TO jbilling;

--
-- Name: contact; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE contact (
    id integer NOT NULL,
    organization_name character varying(200),
    street_addres1 character varying(100),
    street_addres2 character varying(100),
    city character varying(50),
    state_province character varying(30),
    postal_code character varying(15),
    country_code character varying(2),
    last_name character varying(30),
    first_name character varying(30),
    person_initial character varying(5),
    person_title character varying(40),
    phone_country_code integer,
    phone_area_code integer,
    phone_phone_number character varying(20),
    fax_country_code integer,
    fax_area_code integer,
    fax_phone_number character varying(20),
    email character varying(200),
    create_datetime timestamp without time zone NOT NULL,
    deleted integer DEFAULT 0 NOT NULL,
    notification_include integer DEFAULT 1,
    user_id integer,
    optlock integer NOT NULL
);


ALTER TABLE contact OWNER TO jbilling;

--
-- Name: contact_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE contact_map (
    id integer NOT NULL,
    contact_id integer,
    table_id integer NOT NULL,
    foreign_id integer NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE contact_map OWNER TO jbilling;

--
-- Name: country; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE country (
    id integer NOT NULL,
    code character varying(2) NOT NULL
);


ALTER TABLE country OWNER TO jbilling;

--
-- Name: currency; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE currency (
    id integer NOT NULL,
    symbol character varying(10) NOT NULL,
    code character varying(3) NOT NULL,
    country_code character varying(2) NOT NULL,
    optlock integer
);


ALTER TABLE currency OWNER TO jbilling;

--
-- Name: currency_entity_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE currency_entity_map (
    currency_id integer NOT NULL,
    entity_id integer NOT NULL
);


ALTER TABLE currency_entity_map OWNER TO jbilling;

--
-- Name: currency_exchange; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE currency_exchange (
    id integer NOT NULL,
    entity_id integer,
    currency_id integer,
    rate numeric(22,10) NOT NULL,
    create_datetime timestamp without time zone NOT NULL,
    optlock integer NOT NULL,
    valid_since date DEFAULT '1970-01-01'::date NOT NULL
);


ALTER TABLE currency_exchange OWNER TO jbilling;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE customer (
    id integer NOT NULL,
    user_id integer,
    partner_id integer,
    referral_fee_paid integer,
    invoice_delivery_method_id integer NOT NULL,
    auto_payment_type integer,
    due_date_unit_id integer,
    due_date_value integer,
    df_fm integer,
    parent_id integer,
    is_parent integer,
    exclude_aging integer DEFAULT 0 NOT NULL,
    invoice_child integer,
    optlock integer NOT NULL,
    dynamic_balance numeric(22,10),
    credit_limit numeric(22,10),
    auto_recharge numeric(22,10),
    use_parent_pricing boolean NOT NULL,
    main_subscript_order_period_id integer,
    next_invoice_day_of_period integer,
    next_inovice_date date,
    account_type_id integer,
    invoice_design character varying(100),
    credit_notification_limit1 numeric(22,10),
    credit_notification_limit2 numeric(22,10),
    recharge_threshold numeric(22,10),
    monthly_limit numeric(22,10),
    current_monthly_amount numeric(22,10),
    current_month timestamp without time zone
);


ALTER TABLE customer OWNER TO jbilling;

--
-- Name: customer_account_info_type_timeline; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE customer_account_info_type_timeline (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    account_info_type_id integer NOT NULL,
    meta_field_value_id integer NOT NULL,
    effective_date date NOT NULL
);


ALTER TABLE customer_account_info_type_timeline OWNER TO jbilling;

--
-- Name: customer_meta_field_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE customer_meta_field_map (
    customer_id integer NOT NULL,
    meta_field_value_id integer NOT NULL
);


ALTER TABLE customer_meta_field_map OWNER TO jbilling;

--
-- Name: customer_notes; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE customer_notes (
    id integer NOT NULL,
    note_title character varying(50),
    note_content character varying(1000),
    creation_time timestamp without time zone,
    entity_id integer,
    user_id integer,
    customer_id integer
);


ALTER TABLE customer_notes OWNER TO jbilling;

--
-- Name: data_table_query; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE data_table_query (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    route_id integer NOT NULL,
    global integer NOT NULL,
    root_entry_id integer NOT NULL,
    user_id integer NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE data_table_query OWNER TO jbilling;

--
-- Name: data_table_query_entry; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE data_table_query_entry (
    id integer NOT NULL,
    route_id integer NOT NULL,
    columns character varying(250) NOT NULL,
    next_entry_id integer,
    optlock integer NOT NULL
);


ALTER TABLE data_table_query_entry OWNER TO jbilling;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20)
);


ALTER TABLE databasechangelog OWNER TO jbilling;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE databasechangeloglock OWNER TO jbilling;

--
-- Name: discount; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE discount (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    discount_type character varying(25) NOT NULL,
    rate numeric(22,10),
    start_date date,
    end_date date,
    entity_id integer,
    last_update_datetime timestamp without time zone
);


ALTER TABLE discount OWNER TO jbilling;

--
-- Name: discount_attribute; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE discount_attribute (
    discount_id integer NOT NULL,
    attribute_name character varying(255) NOT NULL,
    attribute_value character varying(255)
);


ALTER TABLE discount_attribute OWNER TO jbilling;

--
-- Name: discount_line; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE discount_line (
    id integer NOT NULL,
    discount_id integer NOT NULL,
    item_id integer,
    order_id integer NOT NULL,
    discount_order_line_id integer,
    order_line_amount numeric(22,10),
    description character varying(1000) NOT NULL
);


ALTER TABLE discount_line OWNER TO jbilling;

--
-- Name: entity; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE entity (
    id integer NOT NULL,
    external_id character varying(20),
    description character varying(100) NOT NULL,
    create_datetime timestamp without time zone NOT NULL,
    language_id integer NOT NULL,
    currency_id integer NOT NULL,
    optlock integer NOT NULL,
    deleted integer DEFAULT 0 NOT NULL,
    invoice_as_reseller boolean DEFAULT false NOT NULL,
    parent_id integer
);


ALTER TABLE entity OWNER TO jbilling;

--
-- Name: entity_delivery_method_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE entity_delivery_method_map (
    method_id integer NOT NULL,
    entity_id integer NOT NULL
);


ALTER TABLE entity_delivery_method_map OWNER TO jbilling;

--
-- Name: entity_payment_method_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE entity_payment_method_map (
    entity_id integer NOT NULL,
    payment_method_id integer NOT NULL
);


ALTER TABLE entity_payment_method_map OWNER TO jbilling;

--
-- Name: entity_report_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE entity_report_map (
    report_id integer NOT NULL,
    entity_id integer NOT NULL
);


ALTER TABLE entity_report_map OWNER TO jbilling;

--
-- Name: enumeration; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE enumeration (
    id integer NOT NULL,
    entity_id integer NOT NULL,
    name character varying(50) NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE enumeration OWNER TO jbilling;

--
-- Name: enumeration_values; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE enumeration_values (
    id integer NOT NULL,
    enumeration_id integer NOT NULL,
    value character varying(50) NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE enumeration_values OWNER TO jbilling;

--
-- Name: event_log; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE event_log (
    id integer NOT NULL,
    entity_id integer,
    user_id integer,
    table_id integer,
    foreign_id integer NOT NULL,
    create_datetime timestamp without time zone NOT NULL,
    level_field integer NOT NULL,
    module_id integer NOT NULL,
    message_id integer NOT NULL,
    old_num integer,
    old_str character varying(1000),
    old_date timestamp without time zone,
    optlock integer NOT NULL,
    affected_user_id integer
);


ALTER TABLE event_log OWNER TO jbilling;

--
-- Name: event_log_message; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE event_log_message (
    id integer NOT NULL
);


ALTER TABLE event_log_message OWNER TO jbilling;

--
-- Name: event_log_module; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE event_log_module (
    id integer NOT NULL
);


ALTER TABLE event_log_module OWNER TO jbilling;

--
-- Name: filter; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE filter (
    id integer NOT NULL,
    filter_set_id integer NOT NULL,
    type character varying(255) NOT NULL,
    constraint_type character varying(255) NOT NULL,
    field character varying(255) NOT NULL,
    template character varying(255) NOT NULL,
    visible boolean NOT NULL,
    integer_value integer,
    string_value character varying(255),
    start_date_value timestamp without time zone,
    end_date_value timestamp without time zone,
    version integer NOT NULL,
    boolean_value boolean,
    decimal_value numeric(22,10),
    decimal_high_value numeric(22,10),
    field_key_data character varying(255)
);


ALTER TABLE filter OWNER TO jbilling;

--
-- Name: filter_set; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE filter_set (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    user_id integer NOT NULL,
    version integer NOT NULL
);


ALTER TABLE filter_set OWNER TO jbilling;

--
-- Name: filter_set_filter_id_seq; Type: SEQUENCE; Schema: public; Owner: jbilling
--

CREATE SEQUENCE filter_set_filter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE filter_set_filter_id_seq OWNER TO jbilling;

--
-- Name: filter_set_filter; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE filter_set_filter (
    filter_set_filters_id integer,
    filter_id integer,
    id integer DEFAULT nextval('filter_set_filter_id_seq'::regclass)
);


ALTER TABLE filter_set_filter OWNER TO jbilling;

--
-- Name: generic_status; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE generic_status (
    id integer NOT NULL,
    dtype character varying(50) NOT NULL,
    status_value integer NOT NULL,
    can_login integer,
    ordr integer,
    attribute1 character varying(20),
    entity_id integer,
    deleted integer
);


ALTER TABLE generic_status OWNER TO jbilling;

--
-- Name: generic_status_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE generic_status_type (
    id character varying(50) NOT NULL
);


ALTER TABLE generic_status_type OWNER TO jbilling;

--
-- Name: international_description; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE international_description (
    table_id integer NOT NULL,
    foreign_id integer NOT NULL,
    psudo_column character varying(20) NOT NULL,
    language_id integer NOT NULL,
    content character varying(4000) NOT NULL
);


ALTER TABLE international_description OWNER TO jbilling;

--
-- Name: invoice; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE invoice (
    id integer NOT NULL,
    create_datetime timestamp without time zone NOT NULL,
    billing_process_id integer,
    user_id integer,
    delegated_invoice_id integer,
    due_date date NOT NULL,
    total numeric(22,10) NOT NULL,
    payment_attempts integer DEFAULT 0 NOT NULL,
    status_id integer DEFAULT 1 NOT NULL,
    balance numeric(22,10),
    carried_balance numeric(22,10) NOT NULL,
    in_process_payment integer DEFAULT 1 NOT NULL,
    is_review integer NOT NULL,
    currency_id integer NOT NULL,
    deleted integer DEFAULT 0 NOT NULL,
    paper_invoice_batch_id integer,
    customer_notes character varying(1000),
    public_number character varying(40),
    last_reminder date,
    overdue_step integer,
    create_timestamp timestamp without time zone NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE invoice OWNER TO jbilling;

--
-- Name: invoice_commission; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE invoice_commission (
    id integer NOT NULL,
    partner_id integer,
    referral_partner_id integer,
    commission_process_run_id integer,
    invoice_id integer,
    standard_amount numeric(22,10),
    master_amount numeric(22,10),
    exception_amount numeric(22,10),
    referral_amount numeric(22,10),
    commission_id integer
);


ALTER TABLE invoice_commission OWNER TO jbilling;

--
-- Name: invoice_delivery_method; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE invoice_delivery_method (
    id integer NOT NULL
);


ALTER TABLE invoice_delivery_method OWNER TO jbilling;

--
-- Name: invoice_line; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE invoice_line (
    id integer NOT NULL,
    invoice_id integer,
    type_id integer,
    amount numeric(22,10) NOT NULL,
    quantity numeric(22,10),
    price numeric(22,10),
    deleted integer DEFAULT 0 NOT NULL,
    item_id integer,
    description character varying(1000),
    source_user_id integer,
    is_percentage integer DEFAULT 0 NOT NULL,
    optlock integer NOT NULL,
    order_id integer
);


ALTER TABLE invoice_line OWNER TO jbilling;

--
-- Name: invoice_line_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE invoice_line_type (
    id integer NOT NULL,
    description character varying(50) NOT NULL,
    order_position integer NOT NULL
);


ALTER TABLE invoice_line_type OWNER TO jbilling;

--
-- Name: invoice_meta_field_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE invoice_meta_field_map (
    invoice_id integer NOT NULL,
    meta_field_value_id integer NOT NULL
);


ALTER TABLE invoice_meta_field_map OWNER TO jbilling;

--
-- Name: item; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE item (
    id integer NOT NULL,
    internal_number character varying(50),
    entity_id integer,
    deleted integer DEFAULT 0 NOT NULL,
    has_decimals integer DEFAULT 0 NOT NULL,
    optlock integer NOT NULL,
    gl_code character varying(50),
    price_manual integer,
    asset_management_enabled integer DEFAULT 0 NOT NULL,
    standard_availability boolean DEFAULT true NOT NULL,
    global boolean DEFAULT false NOT NULL,
    standard_partner_percentage numeric(22,10),
    master_partner_percentage numeric(22,10),
    active_since date,
    active_until date,
    reservation_duration integer DEFAULT 0 NOT NULL
);


ALTER TABLE item OWNER TO jbilling;

--
-- Name: item_account_type_availability; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE item_account_type_availability (
    item_id integer,
    account_type_id integer
);


ALTER TABLE item_account_type_availability OWNER TO jbilling;

--
-- Name: item_dependency; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE item_dependency (
    id integer NOT NULL,
    dtype character varying(10) NOT NULL,
    item_id integer NOT NULL,
    min integer NOT NULL,
    max integer,
    dependent_item_id integer,
    dependent_item_type_id integer
);


ALTER TABLE item_dependency OWNER TO jbilling;

--
-- Name: item_entity_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE item_entity_map (
    item_id integer NOT NULL,
    entity_id integer NOT NULL
);


ALTER TABLE item_entity_map OWNER TO jbilling;

--
-- Name: item_meta_field_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE item_meta_field_map (
    item_id integer NOT NULL,
    meta_field_value_id integer NOT NULL
);


ALTER TABLE item_meta_field_map OWNER TO jbilling;

--
-- Name: item_price; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE item_price (
    id integer NOT NULL,
    item_id integer,
    currency_id integer,
    price numeric(22,10) NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE item_price OWNER TO jbilling;

--
-- Name: item_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE item_type (
    id integer NOT NULL,
    entity_id integer NOT NULL,
    description character varying(100),
    order_line_type_id integer NOT NULL,
    optlock integer NOT NULL,
    internal boolean NOT NULL,
    parent_id integer,
    allow_asset_management integer DEFAULT 0 NOT NULL,
    asset_identifier_label character varying(50),
    global boolean DEFAULT false NOT NULL,
    one_per_order boolean DEFAULT false NOT NULL,
    one_per_customer boolean DEFAULT false NOT NULL
);


ALTER TABLE item_type OWNER TO jbilling;

--
-- Name: item_type_entity_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE item_type_entity_map (
    item_type_id integer NOT NULL,
    entity_id integer NOT NULL
);


ALTER TABLE item_type_entity_map OWNER TO jbilling;

--
-- Name: item_type_exclude_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE item_type_exclude_map (
    item_id integer NOT NULL,
    type_id integer NOT NULL
);


ALTER TABLE item_type_exclude_map OWNER TO jbilling;

--
-- Name: item_type_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE item_type_map (
    item_id integer NOT NULL,
    type_id integer NOT NULL
);


ALTER TABLE item_type_map OWNER TO jbilling;

--
-- Name: item_type_meta_field_def_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE item_type_meta_field_def_map (
    item_type_id integer NOT NULL,
    meta_field_id integer NOT NULL
);


ALTER TABLE item_type_meta_field_def_map OWNER TO jbilling;

--
-- Name: item_type_meta_field_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE item_type_meta_field_map (
    item_type_id integer NOT NULL,
    meta_field_value_id integer NOT NULL
);


ALTER TABLE item_type_meta_field_map OWNER TO jbilling;

--
-- Name: jbilling_seqs; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE jbilling_seqs (
    name character varying(255) NOT NULL,
    next_id integer
);


ALTER TABLE jbilling_seqs OWNER TO jbilling;

--
-- Name: jbilling_table; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE jbilling_table (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE jbilling_table OWNER TO jbilling;

--
-- Name: language; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE language (
    id integer NOT NULL,
    code character varying(2) NOT NULL,
    description character varying(50) NOT NULL
);


ALTER TABLE language OWNER TO jbilling;

--
-- Name: list_meta_field_values_id_seq; Type: SEQUENCE; Schema: public; Owner: jbilling
--

CREATE SEQUENCE list_meta_field_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE list_meta_field_values_id_seq OWNER TO jbilling;

--
-- Name: list_meta_field_values; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE list_meta_field_values (
    meta_field_value_id integer NOT NULL,
    list_value character varying(255),
    id integer DEFAULT nextval('list_meta_field_values_id_seq'::regclass)
);


ALTER TABLE list_meta_field_values OWNER TO jbilling;

--
-- Name: matching_field; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE matching_field (
    id integer NOT NULL,
    description character varying(255) NOT NULL,
    required boolean NOT NULL,
    route_id integer,
    matching_field character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    order_sequence integer NOT NULL,
    optlock integer NOT NULL,
    longest_value integer NOT NULL,
    smallest_value integer NOT NULL,
    mandatory_fields_query character varying(1000) NOT NULL
);


ALTER TABLE matching_field OWNER TO jbilling;

--
-- Name: meta_field_group; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE meta_field_group (
    id integer NOT NULL,
    date_created date,
    date_updated date,
    entity_id integer NOT NULL,
    display_order integer,
    optlock integer,
    entity_type character varying(32) NOT NULL,
    discriminator character varying(30) NOT NULL,
    name character varying(32),
    account_type_id integer
);


ALTER TABLE meta_field_group OWNER TO jbilling;

--
-- Name: meta_field_name; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE meta_field_name (
    id integer NOT NULL,
    name character varying(100),
    entity_type character varying(25) NOT NULL,
    data_type character varying(25) NOT NULL,
    is_disabled boolean,
    is_mandatory boolean,
    display_order integer,
    default_value_id integer,
    optlock integer NOT NULL,
    entity_id integer DEFAULT 1,
    error_message character varying(256),
    is_primary boolean DEFAULT true,
    validation_rule_id integer,
    filename character varying(100),
    field_usage character varying(50)
);


ALTER TABLE meta_field_name OWNER TO jbilling;

--
-- Name: meta_field_value; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE meta_field_value (
    id integer NOT NULL,
    meta_field_name_id integer NOT NULL,
    dtype character varying(10) NOT NULL,
    boolean_value boolean,
    date_value timestamp without time zone,
    decimal_value numeric(22,10),
    integer_value integer,
    string_value character varying(1000)
);


ALTER TABLE meta_field_value OWNER TO jbilling;

--
-- Name: metafield_group_meta_field_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE metafield_group_meta_field_map (
    metafield_group_id integer NOT NULL,
    meta_field_value_id integer NOT NULL
);


ALTER TABLE metafield_group_meta_field_map OWNER TO jbilling;

--
-- Name: notification_category; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE notification_category (
    id integer NOT NULL
);


ALTER TABLE notification_category OWNER TO jbilling;

--
-- Name: notification_medium_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE notification_medium_type (
    notification_id integer NOT NULL,
    medium_type character varying(255) NOT NULL
);


ALTER TABLE notification_medium_type OWNER TO jbilling;

--
-- Name: notification_message; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE notification_message (
    id integer NOT NULL,
    type_id integer,
    entity_id integer NOT NULL,
    language_id integer NOT NULL,
    use_flag integer DEFAULT 1 NOT NULL,
    optlock integer NOT NULL,
    attachment_type character varying(20),
    include_attachment integer,
    attachment_design character varying(100),
    notify_admin integer,
    notify_partner integer,
    notify_parent integer,
    notify_all_parents integer
);


ALTER TABLE notification_message OWNER TO jbilling;

--
-- Name: notification_message_arch; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE notification_message_arch (
    id integer NOT NULL,
    type_id integer,
    create_datetime timestamp without time zone NOT NULL,
    user_id integer,
    result_message character varying(200),
    optlock integer NOT NULL
);


ALTER TABLE notification_message_arch OWNER TO jbilling;

--
-- Name: notification_message_arch_line; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE notification_message_arch_line (
    id integer NOT NULL,
    message_archive_id integer,
    section integer NOT NULL,
    content character varying(1000) NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE notification_message_arch_line OWNER TO jbilling;

--
-- Name: notification_message_line; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE notification_message_line (
    id integer NOT NULL,
    message_section_id integer,
    content character varying(1000) NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE notification_message_line OWNER TO jbilling;

--
-- Name: notification_message_section; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE notification_message_section (
    id integer NOT NULL,
    message_id integer,
    section integer,
    optlock integer NOT NULL
);


ALTER TABLE notification_message_section OWNER TO jbilling;

--
-- Name: notification_message_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE notification_message_type (
    id integer NOT NULL,
    optlock integer NOT NULL,
    category_id integer
);


ALTER TABLE notification_message_type OWNER TO jbilling;

--
-- Name: order_billing_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_billing_type (
    id integer NOT NULL
);


ALTER TABLE order_billing_type OWNER TO jbilling;

--
-- Name: order_change; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_change (
    id integer NOT NULL,
    parent_order_change_id integer,
    parent_order_line_id integer,
    order_id integer NOT NULL,
    item_id integer NOT NULL,
    quantity numeric(22,10),
    price numeric(22,10),
    description character varying(1000),
    use_item integer,
    user_id integer NOT NULL,
    create_datetime timestamp without time zone NOT NULL,
    start_date date NOT NULL,
    application_date timestamp without time zone,
    status_id integer NOT NULL,
    user_assigned_status_id integer NOT NULL,
    order_line_id integer,
    optlock integer NOT NULL,
    error_message character varying(500),
    error_codes character varying(200),
    applied_manually integer,
    removal integer,
    next_billable_date date,
    end_date date,
    order_change_type_id integer NOT NULL,
    order_status_id integer,
    is_percentage boolean DEFAULT false NOT NULL
);


ALTER TABLE order_change OWNER TO jbilling;

--
-- Name: order_change_asset_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_change_asset_map (
    order_change_id integer NOT NULL,
    asset_id integer NOT NULL
);


ALTER TABLE order_change_asset_map OWNER TO jbilling;

--
-- Name: order_change_meta_field_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_change_meta_field_map (
    order_change_id integer NOT NULL,
    meta_field_value_id integer NOT NULL
);


ALTER TABLE order_change_meta_field_map OWNER TO jbilling;

--
-- Name: order_change_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_change_type (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    entity_id integer,
    default_type boolean DEFAULT false NOT NULL,
    allow_order_status_change boolean DEFAULT false NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE order_change_type OWNER TO jbilling;

--
-- Name: order_change_type_item_type_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_change_type_item_type_map (
    order_change_type_id integer NOT NULL,
    item_type_id integer NOT NULL
);


ALTER TABLE order_change_type_item_type_map OWNER TO jbilling;

--
-- Name: order_change_type_meta_field_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_change_type_meta_field_map (
    order_change_type_id integer NOT NULL,
    meta_field_id integer NOT NULL
);


ALTER TABLE order_change_type_meta_field_map OWNER TO jbilling;

--
-- Name: order_line; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_line (
    id integer NOT NULL,
    order_id integer,
    item_id integer,
    type_id integer,
    amount numeric(22,10) NOT NULL,
    quantity numeric(22,10),
    price numeric(22,10),
    item_price integer,
    create_datetime timestamp without time zone NOT NULL,
    deleted integer DEFAULT 0 NOT NULL,
    description character varying(1000),
    optlock integer NOT NULL,
    use_item boolean NOT NULL,
    parent_line_id integer,
    start_date date,
    end_date date,
    sip_uri character varying(255),
    is_percentage boolean DEFAULT false NOT NULL
);


ALTER TABLE order_line OWNER TO jbilling;

--
-- Name: order_line_meta_field_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_line_meta_field_map (
    order_line_id integer NOT NULL,
    meta_field_value_id integer NOT NULL
);


ALTER TABLE order_line_meta_field_map OWNER TO jbilling;

--
-- Name: order_line_meta_fields_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_line_meta_fields_map (
    item_id integer NOT NULL,
    meta_field_id integer NOT NULL
);


ALTER TABLE order_line_meta_fields_map OWNER TO jbilling;

--
-- Name: order_line_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_line_type (
    id integer NOT NULL,
    editable integer NOT NULL
);


ALTER TABLE order_line_type OWNER TO jbilling;

--
-- Name: order_meta_field_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_meta_field_map (
    order_id integer NOT NULL,
    meta_field_value_id integer NOT NULL
);


ALTER TABLE order_meta_field_map OWNER TO jbilling;

--
-- Name: order_period; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_period (
    id integer NOT NULL,
    entity_id integer,
    value integer,
    unit_id integer,
    optlock integer NOT NULL
);


ALTER TABLE order_period OWNER TO jbilling;

--
-- Name: order_process; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_process (
    id integer NOT NULL,
    order_id integer,
    invoice_id integer,
    billing_process_id integer,
    periods_included integer,
    period_start date,
    period_end date,
    is_review integer NOT NULL,
    origin integer,
    optlock integer NOT NULL
);


ALTER TABLE order_process OWNER TO jbilling;

--
-- Name: order_status; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE order_status (
    id integer NOT NULL,
    order_status_flag integer,
    entity_id integer
);


ALTER TABLE order_status OWNER TO jbilling;

--
-- Name: paper_invoice_batch; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE paper_invoice_batch (
    id integer NOT NULL,
    total_invoices integer NOT NULL,
    delivery_date date,
    is_self_managed integer NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE paper_invoice_batch OWNER TO jbilling;

--
-- Name: partner; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE partner (
    id integer NOT NULL,
    user_id integer,
    total_payments numeric(22,10) NOT NULL,
    total_refunds numeric(22,10) NOT NULL,
    total_payouts numeric(22,10) NOT NULL,
    due_payout numeric(22,10),
    optlock integer NOT NULL,
    type character varying(250),
    parent_id integer,
    commission_type character varying(255)
);


ALTER TABLE partner OWNER TO jbilling;

--
-- Name: partner_commission; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE partner_commission (
    id integer NOT NULL,
    amount numeric(22,10),
    type character varying(255),
    partner_id integer,
    commission_process_run_id integer,
    currency_id integer
);


ALTER TABLE partner_commission OWNER TO jbilling;

--
-- Name: partner_commission_exception; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE partner_commission_exception (
    id integer NOT NULL,
    partner_id integer,
    start_date date,
    end_date date,
    percentage numeric(22,10),
    item_id integer
);


ALTER TABLE partner_commission_exception OWNER TO jbilling;

--
-- Name: partner_commission_proc_config; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE partner_commission_proc_config (
    id integer NOT NULL,
    entity_id integer,
    next_run_date date,
    period_unit_id integer,
    period_value integer
);


ALTER TABLE partner_commission_proc_config OWNER TO jbilling;

--
-- Name: partner_commission_process_run; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE partner_commission_process_run (
    id integer NOT NULL,
    run_date date,
    period_start date,
    period_end date,
    entity_id integer
);


ALTER TABLE partner_commission_process_run OWNER TO jbilling;

--
-- Name: partner_meta_field_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE partner_meta_field_map (
    partner_id integer NOT NULL,
    meta_field_value_id integer NOT NULL
);


ALTER TABLE partner_meta_field_map OWNER TO jbilling;

--
-- Name: partner_payout; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE partner_payout (
    id integer NOT NULL,
    starting_date date NOT NULL,
    ending_date date NOT NULL,
    payments_amount numeric(22,10) NOT NULL,
    refunds_amount numeric(22,10) NOT NULL,
    balance_left numeric(22,10) NOT NULL,
    payment_id integer,
    partner_id integer,
    optlock integer NOT NULL
);


ALTER TABLE partner_payout OWNER TO jbilling;

--
-- Name: partner_referral_commission; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE partner_referral_commission (
    id integer NOT NULL,
    referral_id integer,
    referrer_id integer,
    start_date date,
    end_date date,
    percentage numeric(22,10)
);


ALTER TABLE partner_referral_commission OWNER TO jbilling;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment (
    id integer NOT NULL,
    user_id integer,
    attempt integer,
    result_id integer,
    amount numeric(22,10) NOT NULL,
    create_datetime timestamp without time zone NOT NULL,
    update_datetime timestamp without time zone,
    payment_date date,
    method_id integer,
    credit_card_id integer,
    deleted integer DEFAULT 0 NOT NULL,
    is_refund integer DEFAULT 0 NOT NULL,
    is_preauth integer DEFAULT 0 NOT NULL,
    payment_id integer,
    currency_id integer NOT NULL,
    payout_id integer,
    balance numeric(22,10),
    optlock integer NOT NULL,
    payment_period integer,
    payment_notes character varying(500)
);


ALTER TABLE payment OWNER TO jbilling;

--
-- Name: payment_authorization; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_authorization (
    id integer NOT NULL,
    payment_id integer,
    processor character varying(40) NOT NULL,
    code1 character varying(40) NOT NULL,
    code2 character varying(40),
    code3 character varying(40),
    approval_code character varying(20),
    avs character varying(20),
    transaction_id character varying(40),
    md5 character varying(100),
    card_code character varying(100),
    create_datetime date NOT NULL,
    response_message character varying(200),
    optlock integer NOT NULL
);


ALTER TABLE payment_authorization OWNER TO jbilling;

--
-- Name: payment_commission; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_commission (
    id integer NOT NULL,
    invoice_id integer,
    payment_amount numeric(22,10)
);


ALTER TABLE payment_commission OWNER TO jbilling;

--
-- Name: payment_information; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_information (
    id integer NOT NULL,
    user_id integer,
    payment_method_id integer NOT NULL,
    processing_order integer,
    deleted integer NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE payment_information OWNER TO jbilling;

--
-- Name: payment_information_meta_fields_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_information_meta_fields_map (
    payment_information_id integer NOT NULL,
    meta_field_value_id integer NOT NULL
);


ALTER TABLE payment_information_meta_fields_map OWNER TO jbilling;

--
-- Name: payment_instrument_info; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_instrument_info (
    id integer NOT NULL,
    result_id integer NOT NULL,
    method_id integer NOT NULL,
    instrument_id integer NOT NULL,
    payment_id integer NOT NULL
);


ALTER TABLE payment_instrument_info OWNER TO jbilling;

--
-- Name: payment_invoice; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_invoice (
    id integer NOT NULL,
    payment_id integer,
    invoice_id integer,
    amount numeric(22,10),
    create_datetime timestamp without time zone NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE payment_invoice OWNER TO jbilling;

--
-- Name: payment_meta_field_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_meta_field_map (
    payment_id integer NOT NULL,
    meta_field_value_id integer NOT NULL
);


ALTER TABLE payment_meta_field_map OWNER TO jbilling;

--
-- Name: payment_method; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_method (
    id integer NOT NULL
);


ALTER TABLE payment_method OWNER TO jbilling;

--
-- Name: payment_method_account_type_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_method_account_type_map (
    payment_method_id integer NOT NULL,
    account_type_id integer NOT NULL
);


ALTER TABLE payment_method_account_type_map OWNER TO jbilling;

--
-- Name: payment_method_meta_fields_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_method_meta_fields_map (
    payment_method_id integer NOT NULL,
    meta_field_id integer NOT NULL
);


ALTER TABLE payment_method_meta_fields_map OWNER TO jbilling;

--
-- Name: payment_method_template; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_method_template (
    id integer NOT NULL,
    template_name character varying(20) NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE payment_method_template OWNER TO jbilling;

--
-- Name: payment_method_template_meta_fields_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_method_template_meta_fields_map (
    method_template_id integer NOT NULL,
    meta_field_id integer NOT NULL
);


ALTER TABLE payment_method_template_meta_fields_map OWNER TO jbilling;

--
-- Name: payment_method_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_method_type (
    id integer NOT NULL,
    method_name character varying(20) NOT NULL,
    is_recurring boolean DEFAULT false NOT NULL,
    entity_id integer NOT NULL,
    template_id integer NOT NULL,
    optlock integer NOT NULL,
    all_account_type boolean DEFAULT false NOT NULL
);


ALTER TABLE payment_method_type OWNER TO jbilling;

--
-- Name: payment_result; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE payment_result (
    id integer NOT NULL
);


ALTER TABLE payment_result OWNER TO jbilling;

--
-- Name: period_unit; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE period_unit (
    id integer NOT NULL
);


ALTER TABLE period_unit OWNER TO jbilling;

--
-- Name: pluggable_task; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE pluggable_task (
    id integer NOT NULL,
    entity_id integer NOT NULL,
    type_id integer,
    processing_order integer NOT NULL,
    optlock integer NOT NULL,
    notes character varying(1000)
);


ALTER TABLE pluggable_task OWNER TO jbilling;

--
-- Name: pluggable_task_parameter; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE pluggable_task_parameter (
    id integer NOT NULL,
    task_id integer,
    name character varying(50) NOT NULL,
    int_value integer,
    str_value character varying(500),
    float_value numeric(22,10),
    optlock integer NOT NULL
);


ALTER TABLE pluggable_task_parameter OWNER TO jbilling;

--
-- Name: pluggable_task_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE pluggable_task_type (
    id integer NOT NULL,
    category_id integer NOT NULL,
    class_name character varying(200) NOT NULL,
    min_parameters integer NOT NULL
);


ALTER TABLE pluggable_task_type OWNER TO jbilling;

--
-- Name: pluggable_task_type_category; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE pluggable_task_type_category (
    id integer NOT NULL,
    interface_name character varying(200) NOT NULL
);


ALTER TABLE pluggable_task_type_category OWNER TO jbilling;

--
-- Name: preference; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE preference (
    id integer NOT NULL,
    type_id integer,
    table_id integer NOT NULL,
    foreign_id integer NOT NULL,
    value character varying(200)
);


ALTER TABLE preference OWNER TO jbilling;

--
-- Name: preference_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE preference_type (
    id integer NOT NULL,
    def_value character varying(200),
    validation_rule_id integer
);


ALTER TABLE preference_type OWNER TO jbilling;

--
-- Name: process_run; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE process_run (
    id integer NOT NULL,
    process_id integer,
    run_date date NOT NULL,
    started timestamp without time zone NOT NULL,
    finished timestamp without time zone,
    payment_finished timestamp without time zone,
    invoices_generated integer,
    optlock integer NOT NULL,
    status_id integer NOT NULL
);


ALTER TABLE process_run OWNER TO jbilling;

--
-- Name: process_run_total; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE process_run_total (
    id integer NOT NULL,
    process_run_id integer,
    currency_id integer NOT NULL,
    total_invoiced numeric(22,10),
    total_paid numeric(22,10),
    total_not_paid numeric(22,10),
    optlock integer NOT NULL
);


ALTER TABLE process_run_total OWNER TO jbilling;

--
-- Name: process_run_total_pm; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE process_run_total_pm (
    id integer NOT NULL,
    process_run_total_id integer,
    payment_method_id integer,
    total numeric(22,10) NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE process_run_total_pm OWNER TO jbilling;

--
-- Name: process_run_user; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE process_run_user (
    id integer NOT NULL,
    process_run_id integer NOT NULL,
    user_id integer NOT NULL,
    status integer NOT NULL,
    created timestamp without time zone NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE process_run_user OWNER TO jbilling;

--
-- Name: promotion; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE promotion (
    id integer NOT NULL,
    item_id integer,
    code character varying(50) NOT NULL,
    notes character varying(200),
    once integer NOT NULL,
    since date,
    until date
);


ALTER TABLE promotion OWNER TO jbilling;

--
-- Name: promotion_user_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE promotion_user_map (
    user_id integer NOT NULL,
    promotion_id integer NOT NULL
);


ALTER TABLE promotion_user_map OWNER TO jbilling;

--
-- Name: purchase_order; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE purchase_order (
    id integer NOT NULL,
    user_id integer,
    period_id integer,
    billing_type_id integer NOT NULL,
    active_since date,
    active_until date,
    cycle_start date,
    create_datetime timestamp without time zone NOT NULL,
    next_billable_day date,
    created_by integer,
    status_id integer NOT NULL,
    currency_id integer NOT NULL,
    deleted integer DEFAULT 0 NOT NULL,
    notify integer,
    last_notified timestamp without time zone,
    notification_step integer,
    due_date_unit_id integer,
    due_date_value integer,
    df_fm integer,
    anticipate_periods integer,
    own_invoice integer,
    notes character varying(200),
    notes_in_invoice integer,
    optlock integer NOT NULL,
    primary_order_id integer,
    prorate_flag boolean DEFAULT false NOT NULL,
    parent_order_id integer,
    cancellation_fee_type character varying(50),
    cancellation_fee integer,
    cancellation_fee_percentage integer,
    cancellation_maximum_fee integer,
    cancellation_minimum_period integer,
    reseller_order integer,
    free_usage_quantity numeric(22,10),
    deleted_date date
);


ALTER TABLE purchase_order OWNER TO jbilling;

--
-- Name: rating_unit; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE rating_unit (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    entity_id integer NOT NULL,
    price_unit_name character varying(50),
    increment_unit_name character varying(50),
    increment_unit_quantity numeric(22,10),
    can_be_deleted boolean DEFAULT true,
    optlock integer NOT NULL
);


ALTER TABLE rating_unit OWNER TO jbilling;

--
-- Name: recent_item; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE recent_item (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    object_id integer NOT NULL,
    user_id integer NOT NULL,
    version integer NOT NULL
);


ALTER TABLE recent_item OWNER TO jbilling;

--
-- Name: report; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE report (
    id integer NOT NULL,
    type_id integer NOT NULL,
    name character varying(255) NOT NULL,
    file_name character varying(500) NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE report OWNER TO jbilling;

--
-- Name: report_parameter; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE report_parameter (
    id integer NOT NULL,
    report_id integer NOT NULL,
    dtype character varying(10) NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE report_parameter OWNER TO jbilling;

--
-- Name: report_type; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE report_type (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    optlock integer NOT NULL
);


ALTER TABLE report_type OWNER TO jbilling;

--
-- Name: reseller_entityid_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE reseller_entityid_map (
    entity_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE reseller_entityid_map OWNER TO jbilling;

--
-- Name: reserved_amounts; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE reserved_amounts (
    id integer NOT NULL,
    session_id integer,
    ts_created timestamp without time zone,
    currency_id integer,
    reserved_amount numeric(22,10),
    item_id integer,
    data text,
    quantity numeric(22,10)
);


ALTER TABLE reserved_amounts OWNER TO jbilling;

--
-- Name: reset_password_code; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE reset_password_code (
    base_user_id integer NOT NULL,
    date_created timestamp without time zone,
    token character varying(32) NOT NULL,
    new_password character varying(40)
);


ALTER TABLE reset_password_code OWNER TO jbilling;

--
-- Name: role; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE role (
    id integer NOT NULL,
    entity_id integer,
    role_type_id integer
);


ALTER TABLE role OWNER TO jbilling;

--
-- Name: route; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE route (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    table_name character varying(50) NOT NULL,
    entity_id integer NOT NULL,
    optlock integer NOT NULL,
    root_table boolean DEFAULT false,
    output_field_name character varying(150),
    default_route character varying(255),
    route_table boolean DEFAULT false
);


ALTER TABLE route OWNER TO jbilling;

--
-- Name: shortcut; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE shortcut (
    id integer NOT NULL,
    user_id integer NOT NULL,
    controller character varying(255) NOT NULL,
    action character varying(255),
    name character varying(255),
    object_id integer,
    version integer NOT NULL
);


ALTER TABLE shortcut OWNER TO jbilling;

--
-- Name: sure_tax_txn_log; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE sure_tax_txn_log (
    id integer NOT NULL,
    txn_id character varying(20) NOT NULL,
    txn_type character varying(10) NOT NULL,
    txn_data text NOT NULL,
    txn_date timestamp without time zone NOT NULL,
    resp_trans_id integer,
    request_type character varying(10)
);


ALTER TABLE sure_tax_txn_log OWNER TO jbilling;

--
-- Name: tab; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE tab (
    id integer NOT NULL,
    message_code character varying(50),
    controller_name character varying(50),
    access_url character varying(50),
    required_role character varying(50),
    version integer NOT NULL,
    default_order integer
);


ALTER TABLE tab OWNER TO jbilling;

--
-- Name: tab_configuration; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE tab_configuration (
    id integer NOT NULL,
    user_id integer,
    version integer NOT NULL
);


ALTER TABLE tab_configuration OWNER TO jbilling;

--
-- Name: tab_configuration_tab; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE tab_configuration_tab (
    id integer NOT NULL,
    tab_id integer,
    tab_configuration_id integer,
    display_order integer,
    visible boolean,
    version integer NOT NULL
);


ALTER TABLE tab_configuration_tab OWNER TO jbilling;

--
-- Name: user_code; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE user_code (
    id integer NOT NULL,
    user_id integer NOT NULL,
    identifier character varying(55) NOT NULL,
    external_ref character varying(50),
    type character varying(50),
    type_desc character varying(250),
    valid_from date,
    valid_to date
);


ALTER TABLE user_code OWNER TO jbilling;

--
-- Name: user_code_link; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE user_code_link (
    id integer NOT NULL,
    user_code_id integer NOT NULL,
    object_type character varying(50) NOT NULL,
    object_id integer
);


ALTER TABLE user_code_link OWNER TO jbilling;

--
-- Name: user_credit_card_map_id_seq; Type: SEQUENCE; Schema: public; Owner: jbilling
--

CREATE SEQUENCE user_credit_card_map_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE user_credit_card_map_id_seq OWNER TO jbilling;

--
-- Name: user_credit_card_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE user_credit_card_map (
    user_id integer,
    credit_card_id integer,
    id integer DEFAULT nextval('user_credit_card_map_id_seq'::regclass)
);


ALTER TABLE user_credit_card_map OWNER TO jbilling;

--
-- Name: user_password_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE user_password_map (
    id integer NOT NULL,
    base_user_id integer NOT NULL,
    date_created timestamp without time zone NOT NULL,
    new_password character varying(1024) NOT NULL
);


ALTER TABLE user_password_map OWNER TO jbilling;

--
-- Name: user_role_map; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE user_role_map (
    user_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE user_role_map OWNER TO jbilling;

--
-- Name: user_status; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE user_status (
    id integer NOT NULL,
    can_login smallint
);


ALTER TABLE user_status OWNER TO jbilling;

--
-- Name: validation_rule; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE validation_rule (
    id integer NOT NULL,
    rule_type character varying(25) NOT NULL,
    enabled boolean,
    optlock integer NOT NULL
);


ALTER TABLE validation_rule OWNER TO jbilling;

--
-- Name: validation_rule_attributes; Type: TABLE; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE TABLE validation_rule_attributes (
    validation_rule_id integer NOT NULL,
    attribute_name character varying(255) NOT NULL,
    attribute_value character varying(255)
);


ALTER TABLE validation_rule_attributes OWNER TO jbilling;

--
-- Data for Name: account_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY account_type (id, credit_limit, invoice_design, invoice_delivery_method_id, date_created, credit_notification_limit1, credit_notification_limit2, language_id, entity_id, currency_id, optlock, main_subscript_order_period_id, next_invoice_day_of_period, notification_ait_id) FROM stdin;
\.
COPY account_type (id, credit_limit, invoice_design, invoice_delivery_method_id, date_created, credit_notification_limit1, credit_notification_limit2, language_id, entity_id, currency_id, optlock, main_subscript_order_period_id, next_invoice_day_of_period, notification_ait_id) FROM '$$PATH$$/3435.dat';

--
-- Data for Name: account_type_price; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY account_type_price (account_type_id, create_datetime, price_expiry_date) FROM stdin;
\.
COPY account_type_price (account_type_id, create_datetime, price_expiry_date) FROM '$$PATH$$/3436.dat';

--
-- Data for Name: ageing_entity_step; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY ageing_entity_step (id, entity_id, status_id, days, optlock, retry_payment, suspend, send_notification) FROM stdin;
\.
COPY ageing_entity_step (id, entity_id, status_id, days, optlock, retry_payment, suspend, send_notification) FROM '$$PATH$$/3317.dat';

--
-- Data for Name: asset; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY asset (id, identifier, create_datetime, status_id, entity_id, deleted, item_id, notes, optlock, group_id, order_line_id, global) FROM stdin;
\.
COPY asset (id, identifier, create_datetime, status_id, entity_id, deleted, item_id, notes, optlock, group_id, order_line_id, global) FROM '$$PATH$$/3423.dat';

--
-- Data for Name: asset_assignment; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY asset_assignment (id, asset_id, order_line_id, start_datetime, end_datetime) FROM stdin;
\.
COPY asset_assignment (id, asset_id, order_line_id, start_datetime, end_datetime) FROM '$$PATH$$/3487.dat';

--
-- Data for Name: asset_entity_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY asset_entity_map (asset_id, entity_id) FROM stdin;
\.
COPY asset_entity_map (asset_id, entity_id) FROM '$$PATH$$/3484.dat';

--
-- Data for Name: asset_meta_field_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY asset_meta_field_map (asset_id, meta_field_value_id) FROM stdin;
\.
COPY asset_meta_field_map (asset_id, meta_field_value_id) FROM '$$PATH$$/3424.dat';

--
-- Data for Name: asset_reservation; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY asset_reservation (id, user_id, creator_user_id, asset_id, start_date, end_date, optlock) FROM stdin;
\.
COPY asset_reservation (id, user_id, creator_user_id, asset_id, start_date, end_date, optlock) FROM '$$PATH$$/3486.dat';

--
-- Data for Name: asset_status; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY asset_status (id, item_type_id, is_default, is_order_saved, is_available, deleted, optlock, is_internal) FROM stdin;
\.
COPY asset_status (id, item_type_id, is_default, is_order_saved, is_available, deleted, optlock, is_internal) FROM '$$PATH$$/3421.dat';

--
-- Data for Name: asset_transition; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY asset_transition (id, create_datetime, previous_status_id, new_status_id, asset_id, user_id, assigned_to_id) FROM stdin;
\.
COPY asset_transition (id, create_datetime, previous_status_id, new_status_id, asset_id, user_id, assigned_to_id) FROM '$$PATH$$/3425.dat';

--
-- Data for Name: base_user; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY base_user (id, entity_id, password, deleted, language_id, status_id, subscriber_status, currency_id, create_datetime, last_status_change, last_login, user_name, failed_attempts, optlock, change_password_date, encryption_scheme, account_locked_time, account_disabled_date) FROM stdin;
\.
COPY base_user (id, entity_id, password, deleted, language_id, status_id, subscriber_status, currency_id, create_datetime, last_status_change, last_login, user_name, failed_attempts, optlock, change_password_date, encryption_scheme, account_locked_time, account_disabled_date) FROM '$$PATH$$/3318.dat';

--
-- Data for Name: batch_job_execution; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY batch_job_execution (job_execution_id, version, job_instance_id, create_time, start_time, end_time, status, exit_code, exit_message, last_updated, job_configuration_location) FROM stdin;
\.
COPY batch_job_execution (job_execution_id, version, job_instance_id, create_time, start_time, end_time, status, exit_code, exit_message, last_updated, job_configuration_location) FROM '$$PATH$$/3426.dat';

--
-- Data for Name: batch_job_execution_context; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY batch_job_execution_context (job_execution_id, short_context, serialized_context) FROM stdin;
\.
COPY batch_job_execution_context (job_execution_id, short_context, serialized_context) FROM '$$PATH$$/3427.dat';

--
-- Data for Name: batch_job_execution_params; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY batch_job_execution_params (job_execution_id, type_cd, key_name, string_val, date_val, long_val, double_val, identifying) FROM stdin;
\.
COPY batch_job_execution_params (job_execution_id, type_cd, key_name, string_val, date_val, long_val, double_val, identifying) FROM '$$PATH$$/3429.dat';

--
-- Name: batch_job_execution_seq; Type: SEQUENCE SET; Schema: public; Owner: jbilling
--

SELECT pg_catalog.setval('batch_job_execution_seq', 1, true);


--
-- Data for Name: batch_job_instance; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY batch_job_instance (job_instance_id, version, job_name, job_key) FROM stdin;
\.
COPY batch_job_instance (job_instance_id, version, job_name, job_key) FROM '$$PATH$$/3428.dat';

--
-- Name: batch_job_seq; Type: SEQUENCE SET; Schema: public; Owner: jbilling
--

SELECT pg_catalog.setval('batch_job_seq', 1, true);


--
-- Data for Name: batch_process_info; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY batch_process_info (id, process_id, job_execution_id, total_failed_users, total_successful_users, optlock) FROM stdin;
\.
COPY batch_process_info (id, process_id, job_execution_id, total_failed_users, total_successful_users, optlock) FROM '$$PATH$$/3451.dat';

--
-- Data for Name: batch_step_execution; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY batch_step_execution (step_execution_id, version, step_name, job_execution_id, start_time, end_time, status, commit_count, read_count, filter_count, write_count, read_skip_count, write_skip_count, process_skip_count, rollback_count, exit_code, exit_message, last_updated) FROM stdin;
\.
COPY batch_step_execution (step_execution_id, version, step_name, job_execution_id, start_time, end_time, status, commit_count, read_count, filter_count, write_count, read_skip_count, write_skip_count, process_skip_count, rollback_count, exit_code, exit_message, last_updated) FROM '$$PATH$$/3430.dat';

--
-- Data for Name: batch_step_execution_context; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY batch_step_execution_context (step_execution_id, short_context, serialized_context) FROM stdin;
\.
COPY batch_step_execution_context (step_execution_id, short_context, serialized_context) FROM '$$PATH$$/3431.dat';

--
-- Name: batch_step_execution_seq; Type: SEQUENCE SET; Schema: public; Owner: jbilling
--

SELECT pg_catalog.setval('batch_step_execution_seq', 5, true);


--
-- Data for Name: billing_process; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY billing_process (id, entity_id, billing_date, period_unit_id, period_value, is_review, paper_invoice_batch_id, retries_to_do, optlock) FROM stdin;
\.
COPY billing_process (id, entity_id, billing_date, period_unit_id, period_value, is_review, paper_invoice_batch_id, retries_to_do, optlock) FROM '$$PATH$$/3319.dat';

--
-- Data for Name: billing_process_configuration; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY billing_process_configuration (id, entity_id, next_run_date, generate_report, retries, days_for_retry, days_for_report, review_status, due_date_unit_id, due_date_value, df_fm, only_recurring, invoice_date_process, optlock, maximum_periods, auto_payment_application, period_unit_id, last_day_of_month, prorating_type) FROM stdin;
\.
COPY billing_process_configuration (id, entity_id, next_run_date, generate_report, retries, days_for_retry, days_for_report, review_status, due_date_unit_id, due_date_value, df_fm, only_recurring, invoice_date_process, optlock, maximum_periods, auto_payment_application, period_unit_id, last_day_of_month, prorating_type) FROM '$$PATH$$/3320.dat';

--
-- Data for Name: billing_process_failed_user; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY billing_process_failed_user (id, batch_process_id, user_id, optlock) FROM stdin;
\.
COPY billing_process_failed_user (id, batch_process_id, user_id, optlock) FROM '$$PATH$$/3452.dat';

--
-- Data for Name: blacklist; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY blacklist (id, entity_id, create_datetime, type, source, credit_card, credit_card_id, contact_id, user_id, optlock, meta_field_value_id) FROM stdin;
\.
COPY blacklist (id, entity_id, create_datetime, type, source, credit_card, credit_card_id, contact_id, user_id, optlock, meta_field_value_id) FROM '$$PATH$$/3321.dat';

--
-- Data for Name: breadcrumb; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY breadcrumb (id, user_id, controller, action, name, object_id, version, description) FROM stdin;
\.
COPY breadcrumb (id, user_id, controller, action, name, object_id, version, description) FROM '$$PATH$$/3322.dat';

--
-- Data for Name: cdrentries; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY cdrentries (id, accountcode, src, dst, dcontext, clid, channel, dstchannel, lastapp, lastdatat, start_time, answer, end_time, duration, billsec, disposition, amaflags, userfield, ts) FROM stdin;
\.
COPY cdrentries (id, accountcode, src, dst, dcontext, clid, channel, dstchannel, lastapp, lastdatat, start_time, answer, end_time, duration, billsec, disposition, amaflags, userfield, ts) FROM '$$PATH$$/3323.dat';

--
-- Data for Name: charge_sessions; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY charge_sessions (id, user_id, session_token, ts_started, ts_last_access, carried_units) FROM stdin;
\.
COPY charge_sessions (id, user_id, session_token, ts_started, ts_last_access, carried_units) FROM '$$PATH$$/3475.dat';

--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY contact (id, organization_name, street_addres1, street_addres2, city, state_province, postal_code, country_code, last_name, first_name, person_initial, person_title, phone_country_code, phone_area_code, phone_phone_number, fax_country_code, fax_area_code, fax_phone_number, email, create_datetime, deleted, notification_include, user_id, optlock) FROM stdin;
\.
COPY contact (id, organization_name, street_addres1, street_addres2, city, state_province, postal_code, country_code, last_name, first_name, person_initial, person_title, phone_country_code, phone_area_code, phone_phone_number, fax_country_code, fax_area_code, fax_phone_number, email, create_datetime, deleted, notification_include, user_id, optlock) FROM '$$PATH$$/3324.dat';

--
-- Data for Name: contact_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY contact_map (id, contact_id, table_id, foreign_id, optlock) FROM stdin;
\.
COPY contact_map (id, contact_id, table_id, foreign_id, optlock) FROM '$$PATH$$/3325.dat';

--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY country (id, code) FROM stdin;
\.
COPY country (id, code) FROM '$$PATH$$/3326.dat';

--
-- Data for Name: currency; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY currency (id, symbol, code, country_code, optlock) FROM stdin;
\.
COPY currency (id, symbol, code, country_code, optlock) FROM '$$PATH$$/3327.dat';

--
-- Data for Name: currency_entity_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY currency_entity_map (currency_id, entity_id) FROM stdin;
\.
COPY currency_entity_map (currency_id, entity_id) FROM '$$PATH$$/3328.dat';

--
-- Data for Name: currency_exchange; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY currency_exchange (id, entity_id, currency_id, rate, create_datetime, optlock, valid_since) FROM stdin;
\.
COPY currency_exchange (id, entity_id, currency_id, rate, create_datetime, optlock, valid_since) FROM '$$PATH$$/3329.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY customer (id, user_id, partner_id, referral_fee_paid, invoice_delivery_method_id, auto_payment_type, due_date_unit_id, due_date_value, df_fm, parent_id, is_parent, exclude_aging, invoice_child, optlock, dynamic_balance, credit_limit, auto_recharge, use_parent_pricing, main_subscript_order_period_id, next_invoice_day_of_period, next_inovice_date, account_type_id, invoice_design, credit_notification_limit1, credit_notification_limit2, recharge_threshold, monthly_limit, current_monthly_amount, current_month) FROM stdin;
\.
COPY customer (id, user_id, partner_id, referral_fee_paid, invoice_delivery_method_id, auto_payment_type, due_date_unit_id, due_date_value, df_fm, parent_id, is_parent, exclude_aging, invoice_child, optlock, dynamic_balance, credit_limit, auto_recharge, use_parent_pricing, main_subscript_order_period_id, next_invoice_day_of_period, next_inovice_date, account_type_id, invoice_design, credit_notification_limit1, credit_notification_limit2, recharge_threshold, monthly_limit, current_monthly_amount, current_month) FROM '$$PATH$$/3330.dat';

--
-- Data for Name: customer_account_info_type_timeline; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY customer_account_info_type_timeline (id, customer_id, account_info_type_id, meta_field_value_id, effective_date) FROM stdin;
\.
COPY customer_account_info_type_timeline (id, customer_id, account_info_type_id, meta_field_value_id, effective_date) FROM '$$PATH$$/3449.dat';

--
-- Data for Name: customer_meta_field_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY customer_meta_field_map (customer_id, meta_field_value_id) FROM stdin;
\.
COPY customer_meta_field_map (customer_id, meta_field_value_id) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: customer_notes; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY customer_notes (id, note_title, note_content, creation_time, entity_id, user_id, customer_id) FROM stdin;
\.
COPY customer_notes (id, note_title, note_content, creation_time, entity_id, user_id, customer_id) FROM '$$PATH$$/3477.dat';

--
-- Data for Name: data_table_query; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY data_table_query (id, name, route_id, global, root_entry_id, user_id, optlock) FROM stdin;
\.
COPY data_table_query (id, name, route_id, global, root_entry_id, user_id, optlock) FROM '$$PATH$$/3483.dat';

--
-- Data for Name: data_table_query_entry; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY data_table_query_entry (id, route_id, columns, next_entry_id, optlock) FROM stdin;
\.
COPY data_table_query_entry (id, route_id, columns, next_entry_id, optlock) FROM '$$PATH$$/3482.dat';

--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase) FROM stdin;
\.
COPY databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase) FROM '$$PATH$$/3316.dat';

--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
\.
COPY databasechangeloglock (id, locked, lockgranted, lockedby) FROM '$$PATH$$/3315.dat';

--
-- Data for Name: discount; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY discount (id, code, discount_type, rate, start_date, end_date, entity_id, last_update_datetime) FROM stdin;
\.
COPY discount (id, code, discount_type, rate, start_date, end_date, entity_id, last_update_datetime) FROM '$$PATH$$/3410.dat';

--
-- Data for Name: discount_attribute; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY discount_attribute (discount_id, attribute_name, attribute_value) FROM stdin;
\.
COPY discount_attribute (discount_id, attribute_name, attribute_value) FROM '$$PATH$$/3411.dat';

--
-- Data for Name: discount_line; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY discount_line (id, discount_id, item_id, order_id, discount_order_line_id, order_line_amount, description) FROM stdin;
\.
COPY discount_line (id, discount_id, item_id, order_id, discount_order_line_id, order_line_amount, description) FROM '$$PATH$$/3412.dat';

--
-- Data for Name: entity; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY entity (id, external_id, description, create_datetime, language_id, currency_id, optlock, deleted, invoice_as_reseller, parent_id) FROM stdin;
\.
COPY entity (id, external_id, description, create_datetime, language_id, currency_id, optlock, deleted, invoice_as_reseller, parent_id) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: entity_delivery_method_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY entity_delivery_method_map (method_id, entity_id) FROM stdin;
\.
COPY entity_delivery_method_map (method_id, entity_id) FROM '$$PATH$$/3333.dat';

--
-- Data for Name: entity_payment_method_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY entity_payment_method_map (entity_id, payment_method_id) FROM stdin;
\.
COPY entity_payment_method_map (entity_id, payment_method_id) FROM '$$PATH$$/3334.dat';

--
-- Data for Name: entity_report_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY entity_report_map (report_id, entity_id) FROM stdin;
\.
COPY entity_report_map (report_id, entity_id) FROM '$$PATH$$/3335.dat';

--
-- Data for Name: enumeration; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY enumeration (id, entity_id, name, optlock) FROM stdin;
\.
COPY enumeration (id, entity_id, name, optlock) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: enumeration_values; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY enumeration_values (id, enumeration_id, value, optlock) FROM stdin;
\.
COPY enumeration_values (id, enumeration_id, value, optlock) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: event_log; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY event_log (id, entity_id, user_id, table_id, foreign_id, create_datetime, level_field, module_id, message_id, old_num, old_str, old_date, optlock, affected_user_id) FROM stdin;
\.
COPY event_log (id, entity_id, user_id, table_id, foreign_id, create_datetime, level_field, module_id, message_id, old_num, old_str, old_date, optlock, affected_user_id) FROM '$$PATH$$/3338.dat';

--
-- Data for Name: event_log_message; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY event_log_message (id) FROM stdin;
\.
COPY event_log_message (id) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: event_log_module; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY event_log_module (id) FROM stdin;
\.
COPY event_log_module (id) FROM '$$PATH$$/3340.dat';

--
-- Data for Name: filter; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY filter (id, filter_set_id, type, constraint_type, field, template, visible, integer_value, string_value, start_date_value, end_date_value, version, boolean_value, decimal_value, decimal_high_value, field_key_data) FROM stdin;
\.
COPY filter (id, filter_set_id, type, constraint_type, field, template, visible, integer_value, string_value, start_date_value, end_date_value, version, boolean_value, decimal_value, decimal_high_value, field_key_data) FROM '$$PATH$$/3341.dat';

--
-- Data for Name: filter_set; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY filter_set (id, name, user_id, version) FROM stdin;
\.
COPY filter_set (id, name, user_id, version) FROM '$$PATH$$/3342.dat';

--
-- Data for Name: filter_set_filter; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY filter_set_filter (filter_set_filters_id, filter_id, id) FROM stdin;
\.
COPY filter_set_filter (filter_set_filters_id, filter_id, id) FROM '$$PATH$$/3343.dat';

--
-- Name: filter_set_filter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jbilling
--

SELECT pg_catalog.setval('filter_set_filter_id_seq', 1, false);


--
-- Data for Name: generic_status; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY generic_status (id, dtype, status_value, can_login, ordr, attribute1, entity_id, deleted) FROM stdin;
\.
COPY generic_status (id, dtype, status_value, can_login, ordr, attribute1, entity_id, deleted) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: generic_status_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY generic_status_type (id) FROM stdin;
\.
COPY generic_status_type (id) FROM '$$PATH$$/3345.dat';

--
-- Data for Name: international_description; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY international_description (table_id, foreign_id, psudo_column, language_id, content) FROM stdin;
\.
COPY international_description (table_id, foreign_id, psudo_column, language_id, content) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY invoice (id, create_datetime, billing_process_id, user_id, delegated_invoice_id, due_date, total, payment_attempts, status_id, balance, carried_balance, in_process_payment, is_review, currency_id, deleted, paper_invoice_batch_id, customer_notes, public_number, last_reminder, overdue_step, create_timestamp, optlock) FROM stdin;
\.
COPY invoice (id, create_datetime, billing_process_id, user_id, delegated_invoice_id, due_date, total, payment_attempts, status_id, balance, carried_balance, in_process_payment, is_review, currency_id, deleted, paper_invoice_batch_id, customer_notes, public_number, last_reminder, overdue_step, create_timestamp, optlock) FROM '$$PATH$$/3347.dat';

--
-- Data for Name: invoice_commission; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY invoice_commission (id, partner_id, referral_partner_id, commission_process_run_id, invoice_id, standard_amount, master_amount, exception_amount, referral_amount, commission_id) FROM stdin;
\.
COPY invoice_commission (id, partner_id, referral_partner_id, commission_process_run_id, invoice_id, standard_amount, master_amount, exception_amount, referral_amount, commission_id) FROM '$$PATH$$/3472.dat';

--
-- Data for Name: invoice_delivery_method; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY invoice_delivery_method (id) FROM stdin;
\.
COPY invoice_delivery_method (id) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: invoice_line; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY invoice_line (id, invoice_id, type_id, amount, quantity, price, deleted, item_id, description, source_user_id, is_percentage, optlock, order_id) FROM stdin;
\.
COPY invoice_line (id, invoice_id, type_id, amount, quantity, price, deleted, item_id, description, source_user_id, is_percentage, optlock, order_id) FROM '$$PATH$$/3349.dat';

--
-- Data for Name: invoice_line_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY invoice_line_type (id, description, order_position) FROM stdin;
\.
COPY invoice_line_type (id, description, order_position) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: invoice_meta_field_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY invoice_meta_field_map (invoice_id, meta_field_value_id) FROM stdin;
\.
COPY invoice_meta_field_map (invoice_id, meta_field_value_id) FROM '$$PATH$$/3351.dat';

--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY item (id, internal_number, entity_id, deleted, has_decimals, optlock, gl_code, price_manual, asset_management_enabled, standard_availability, global, standard_partner_percentage, master_partner_percentage, active_since, active_until, reservation_duration) FROM stdin;
\.
COPY item (id, internal_number, entity_id, deleted, has_decimals, optlock, gl_code, price_manual, asset_management_enabled, standard_availability, global, standard_partner_percentage, master_partner_percentage, active_since, active_until, reservation_duration) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: item_account_type_availability; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY item_account_type_availability (item_id, account_type_id) FROM stdin;
\.
COPY item_account_type_availability (item_id, account_type_id) FROM '$$PATH$$/3437.dat';

--
-- Data for Name: item_dependency; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY item_dependency (id, dtype, item_id, min, max, dependent_item_id, dependent_item_type_id) FROM stdin;
\.
COPY item_dependency (id, dtype, item_id, min, max, dependent_item_id, dependent_item_type_id) FROM '$$PATH$$/3450.dat';

--
-- Data for Name: item_entity_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY item_entity_map (item_id, entity_id) FROM stdin;
\.
COPY item_entity_map (item_id, entity_id) FROM '$$PATH$$/3447.dat';

--
-- Data for Name: item_meta_field_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY item_meta_field_map (item_id, meta_field_value_id) FROM stdin;
\.
COPY item_meta_field_map (item_id, meta_field_value_id) FROM '$$PATH$$/3353.dat';

--
-- Data for Name: item_price; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY item_price (id, item_id, currency_id, price, optlock) FROM stdin;
\.
COPY item_price (id, item_id, currency_id, price, optlock) FROM '$$PATH$$/3408.dat';

--
-- Data for Name: item_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY item_type (id, entity_id, description, order_line_type_id, optlock, internal, parent_id, allow_asset_management, asset_identifier_label, global, one_per_order, one_per_customer) FROM stdin;
\.
COPY item_type (id, entity_id, description, order_line_type_id, optlock, internal, parent_id, allow_asset_management, asset_identifier_label, global, one_per_order, one_per_customer) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: item_type_entity_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY item_type_entity_map (item_type_id, entity_id) FROM stdin;
\.
COPY item_type_entity_map (item_type_id, entity_id) FROM '$$PATH$$/3448.dat';

--
-- Data for Name: item_type_exclude_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY item_type_exclude_map (item_id, type_id) FROM stdin;
\.
COPY item_type_exclude_map (item_id, type_id) FROM '$$PATH$$/3355.dat';

--
-- Data for Name: item_type_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY item_type_map (item_id, type_id) FROM stdin;
\.
COPY item_type_map (item_id, type_id) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: item_type_meta_field_def_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY item_type_meta_field_def_map (item_type_id, meta_field_id) FROM stdin;
\.
COPY item_type_meta_field_def_map (item_type_id, meta_field_id) FROM '$$PATH$$/3422.dat';

--
-- Data for Name: item_type_meta_field_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY item_type_meta_field_map (item_type_id, meta_field_value_id) FROM stdin;
\.
COPY item_type_meta_field_map (item_type_id, meta_field_value_id) FROM '$$PATH$$/3485.dat';

--
-- Data for Name: jbilling_seqs; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY jbilling_seqs (name, next_id) FROM stdin;
\.
COPY jbilling_seqs (name, next_id) FROM '$$PATH$$/3357.dat';

--
-- Data for Name: jbilling_table; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY jbilling_table (id, name) FROM stdin;
\.
COPY jbilling_table (id, name) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: language; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY language (id, code, description) FROM stdin;
\.
COPY language (id, code, description) FROM '$$PATH$$/3359.dat';

--
-- Data for Name: list_meta_field_values; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY list_meta_field_values (meta_field_value_id, list_value, id) FROM stdin;
\.
COPY list_meta_field_values (meta_field_value_id, list_value, id) FROM '$$PATH$$/3360.dat';

--
-- Name: list_meta_field_values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jbilling
--

SELECT pg_catalog.setval('list_meta_field_values_id_seq', 4, true);


--
-- Data for Name: matching_field; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY matching_field (id, description, required, route_id, matching_field, type, order_sequence, optlock, longest_value, smallest_value, mandatory_fields_query) FROM stdin;
\.
COPY matching_field (id, description, required, route_id, matching_field, type, order_sequence, optlock, longest_value, smallest_value, mandatory_fields_query) FROM '$$PATH$$/3445.dat';

--
-- Data for Name: meta_field_group; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY meta_field_group (id, date_created, date_updated, entity_id, display_order, optlock, entity_type, discriminator, name, account_type_id) FROM stdin;
\.
COPY meta_field_group (id, date_created, date_updated, entity_id, display_order, optlock, entity_type, discriminator, name, account_type_id) FROM '$$PATH$$/3438.dat';

--
-- Data for Name: meta_field_name; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY meta_field_name (id, name, entity_type, data_type, is_disabled, is_mandatory, display_order, default_value_id, optlock, entity_id, error_message, is_primary, validation_rule_id, filename, field_usage) FROM stdin;
\.
COPY meta_field_name (id, name, entity_type, data_type, is_disabled, is_mandatory, display_order, default_value_id, optlock, entity_id, error_message, is_primary, validation_rule_id, filename, field_usage) FROM '$$PATH$$/3361.dat';

--
-- Data for Name: meta_field_value; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY meta_field_value (id, meta_field_name_id, dtype, boolean_value, date_value, decimal_value, integer_value, string_value) FROM stdin;
\.
COPY meta_field_value (id, meta_field_name_id, dtype, boolean_value, date_value, decimal_value, integer_value, string_value) FROM '$$PATH$$/3362.dat';

--
-- Data for Name: metafield_group_meta_field_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY metafield_group_meta_field_map (metafield_group_id, meta_field_value_id) FROM stdin;
\.
COPY metafield_group_meta_field_map (metafield_group_id, meta_field_value_id) FROM '$$PATH$$/3439.dat';

--
-- Data for Name: notification_category; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY notification_category (id) FROM stdin;
\.
COPY notification_category (id) FROM '$$PATH$$/3363.dat';

--
-- Data for Name: notification_medium_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY notification_medium_type (notification_id, medium_type) FROM stdin;
\.
COPY notification_medium_type (notification_id, medium_type) FROM '$$PATH$$/3467.dat';

--
-- Data for Name: notification_message; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY notification_message (id, type_id, entity_id, language_id, use_flag, optlock, attachment_type, include_attachment, attachment_design, notify_admin, notify_partner, notify_parent, notify_all_parents) FROM stdin;
\.
COPY notification_message (id, type_id, entity_id, language_id, use_flag, optlock, attachment_type, include_attachment, attachment_design, notify_admin, notify_partner, notify_parent, notify_all_parents) FROM '$$PATH$$/3364.dat';

--
-- Data for Name: notification_message_arch; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY notification_message_arch (id, type_id, create_datetime, user_id, result_message, optlock) FROM stdin;
\.
COPY notification_message_arch (id, type_id, create_datetime, user_id, result_message, optlock) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: notification_message_arch_line; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY notification_message_arch_line (id, message_archive_id, section, content, optlock) FROM stdin;
\.
COPY notification_message_arch_line (id, message_archive_id, section, content, optlock) FROM '$$PATH$$/3366.dat';

--
-- Data for Name: notification_message_line; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY notification_message_line (id, message_section_id, content, optlock) FROM stdin;
\.
COPY notification_message_line (id, message_section_id, content, optlock) FROM '$$PATH$$/3367.dat';

--
-- Data for Name: notification_message_section; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY notification_message_section (id, message_id, section, optlock) FROM stdin;
\.
COPY notification_message_section (id, message_id, section, optlock) FROM '$$PATH$$/3368.dat';

--
-- Data for Name: notification_message_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY notification_message_type (id, optlock, category_id) FROM stdin;
\.
COPY notification_message_type (id, optlock, category_id) FROM '$$PATH$$/3369.dat';

--
-- Data for Name: order_billing_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_billing_type (id) FROM stdin;
\.
COPY order_billing_type (id) FROM '$$PATH$$/3370.dat';

--
-- Data for Name: order_change; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_change (id, parent_order_change_id, parent_order_line_id, order_id, item_id, quantity, price, description, use_item, user_id, create_datetime, start_date, application_date, status_id, user_assigned_status_id, order_line_id, optlock, error_message, error_codes, applied_manually, removal, next_billable_date, end_date, order_change_type_id, order_status_id, is_percentage) FROM stdin;
\.
COPY order_change (id, parent_order_change_id, parent_order_line_id, order_id, item_id, quantity, price, description, use_item, user_id, create_datetime, start_date, application_date, status_id, user_assigned_status_id, order_line_id, optlock, error_message, error_codes, applied_manually, removal, next_billable_date, end_date, order_change_type_id, order_status_id, is_percentage) FROM '$$PATH$$/3453.dat';

--
-- Data for Name: order_change_asset_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_change_asset_map (order_change_id, asset_id) FROM stdin;
\.
COPY order_change_asset_map (order_change_id, asset_id) FROM '$$PATH$$/3454.dat';

--
-- Data for Name: order_change_meta_field_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_change_meta_field_map (order_change_id, meta_field_value_id) FROM stdin;
\.
COPY order_change_meta_field_map (order_change_id, meta_field_value_id) FROM '$$PATH$$/3455.dat';

--
-- Data for Name: order_change_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_change_type (id, name, entity_id, default_type, allow_order_status_change, optlock) FROM stdin;
\.
COPY order_change_type (id, name, entity_id, default_type, allow_order_status_change, optlock) FROM '$$PATH$$/3479.dat';

--
-- Data for Name: order_change_type_item_type_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_change_type_item_type_map (order_change_type_id, item_type_id) FROM stdin;
\.
COPY order_change_type_item_type_map (order_change_type_id, item_type_id) FROM '$$PATH$$/3480.dat';

--
-- Data for Name: order_change_type_meta_field_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_change_type_meta_field_map (order_change_type_id, meta_field_id) FROM stdin;
\.
COPY order_change_type_meta_field_map (order_change_type_id, meta_field_id) FROM '$$PATH$$/3481.dat';

--
-- Data for Name: order_line; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_line (id, order_id, item_id, type_id, amount, quantity, price, item_price, create_datetime, deleted, description, optlock, use_item, parent_line_id, start_date, end_date, sip_uri, is_percentage) FROM stdin;
\.
COPY order_line (id, order_id, item_id, type_id, amount, quantity, price, item_price, create_datetime, deleted, description, optlock, use_item, parent_line_id, start_date, end_date, sip_uri, is_percentage) FROM '$$PATH$$/3371.dat';

--
-- Data for Name: order_line_meta_field_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_line_meta_field_map (order_line_id, meta_field_value_id) FROM stdin;
\.
COPY order_line_meta_field_map (order_line_id, meta_field_value_id) FROM '$$PATH$$/3456.dat';

--
-- Data for Name: order_line_meta_fields_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_line_meta_fields_map (item_id, meta_field_id) FROM stdin;
\.
COPY order_line_meta_fields_map (item_id, meta_field_id) FROM '$$PATH$$/3442.dat';

--
-- Data for Name: order_line_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_line_type (id, editable) FROM stdin;
\.
COPY order_line_type (id, editable) FROM '$$PATH$$/3372.dat';

--
-- Data for Name: order_meta_field_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_meta_field_map (order_id, meta_field_value_id) FROM stdin;
\.
COPY order_meta_field_map (order_id, meta_field_value_id) FROM '$$PATH$$/3373.dat';

--
-- Data for Name: order_period; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_period (id, entity_id, value, unit_id, optlock) FROM stdin;
\.
COPY order_period (id, entity_id, value, unit_id, optlock) FROM '$$PATH$$/3374.dat';

--
-- Data for Name: order_process; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_process (id, order_id, invoice_id, billing_process_id, periods_included, period_start, period_end, is_review, origin, optlock) FROM stdin;
\.
COPY order_process (id, order_id, invoice_id, billing_process_id, periods_included, period_start, period_end, is_review, origin, optlock) FROM '$$PATH$$/3375.dat';

--
-- Data for Name: order_status; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY order_status (id, order_status_flag, entity_id) FROM stdin;
\.
COPY order_status (id, order_status_flag, entity_id) FROM '$$PATH$$/3443.dat';

--
-- Data for Name: paper_invoice_batch; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY paper_invoice_batch (id, total_invoices, delivery_date, is_self_managed, optlock) FROM stdin;
\.
COPY paper_invoice_batch (id, total_invoices, delivery_date, is_self_managed, optlock) FROM '$$PATH$$/3376.dat';

--
-- Data for Name: partner; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY partner (id, user_id, total_payments, total_refunds, total_payouts, due_payout, optlock, type, parent_id, commission_type) FROM stdin;
\.
COPY partner (id, user_id, total_payments, total_refunds, total_payouts, due_payout, optlock, type, parent_id, commission_type) FROM '$$PATH$$/3377.dat';

--
-- Data for Name: partner_commission; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY partner_commission (id, amount, type, partner_id, commission_process_run_id, currency_id) FROM stdin;
\.
COPY partner_commission (id, amount, type, partner_id, commission_process_run_id, currency_id) FROM '$$PATH$$/3470.dat';

--
-- Data for Name: partner_commission_exception; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY partner_commission_exception (id, partner_id, start_date, end_date, percentage, item_id) FROM stdin;
\.
COPY partner_commission_exception (id, partner_id, start_date, end_date, percentage, item_id) FROM '$$PATH$$/3468.dat';

--
-- Data for Name: partner_commission_proc_config; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY partner_commission_proc_config (id, entity_id, next_run_date, period_unit_id, period_value) FROM stdin;
\.
COPY partner_commission_proc_config (id, entity_id, next_run_date, period_unit_id, period_value) FROM '$$PATH$$/3474.dat';

--
-- Data for Name: partner_commission_process_run; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY partner_commission_process_run (id, run_date, period_start, period_end, entity_id) FROM stdin;
\.
COPY partner_commission_process_run (id, run_date, period_start, period_end, entity_id) FROM '$$PATH$$/3471.dat';

--
-- Data for Name: partner_meta_field_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY partner_meta_field_map (partner_id, meta_field_value_id) FROM stdin;
\.
COPY partner_meta_field_map (partner_id, meta_field_value_id) FROM '$$PATH$$/3378.dat';

--
-- Data for Name: partner_payout; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY partner_payout (id, starting_date, ending_date, payments_amount, refunds_amount, balance_left, payment_id, partner_id, optlock) FROM stdin;
\.
COPY partner_payout (id, starting_date, ending_date, payments_amount, refunds_amount, balance_left, payment_id, partner_id, optlock) FROM '$$PATH$$/3379.dat';

--
-- Data for Name: partner_referral_commission; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY partner_referral_commission (id, referral_id, referrer_id, start_date, end_date, percentage) FROM stdin;
\.
COPY partner_referral_commission (id, referral_id, referrer_id, start_date, end_date, percentage) FROM '$$PATH$$/3469.dat';

--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment (id, user_id, attempt, result_id, amount, create_datetime, update_datetime, payment_date, method_id, credit_card_id, deleted, is_refund, is_preauth, payment_id, currency_id, payout_id, balance, optlock, payment_period, payment_notes) FROM stdin;
\.
COPY payment (id, user_id, attempt, result_id, amount, create_datetime, update_datetime, payment_date, method_id, credit_card_id, deleted, is_refund, is_preauth, payment_id, currency_id, payout_id, balance, optlock, payment_period, payment_notes) FROM '$$PATH$$/3380.dat';

--
-- Data for Name: payment_authorization; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_authorization (id, payment_id, processor, code1, code2, code3, approval_code, avs, transaction_id, md5, card_code, create_datetime, response_message, optlock) FROM stdin;
\.
COPY payment_authorization (id, payment_id, processor, code1, code2, code3, approval_code, avs, transaction_id, md5, card_code, create_datetime, response_message, optlock) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: payment_commission; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_commission (id, invoice_id, payment_amount) FROM stdin;
\.
COPY payment_commission (id, invoice_id, payment_amount) FROM '$$PATH$$/3473.dat';

--
-- Data for Name: payment_information; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_information (id, user_id, payment_method_id, processing_order, deleted, optlock) FROM stdin;
\.
COPY payment_information (id, user_id, payment_method_id, processing_order, deleted, optlock) FROM '$$PATH$$/3463.dat';

--
-- Data for Name: payment_information_meta_fields_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_information_meta_fields_map (payment_information_id, meta_field_value_id) FROM stdin;
\.
COPY payment_information_meta_fields_map (payment_information_id, meta_field_value_id) FROM '$$PATH$$/3464.dat';

--
-- Data for Name: payment_instrument_info; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_instrument_info (id, result_id, method_id, instrument_id, payment_id) FROM stdin;
\.
COPY payment_instrument_info (id, result_id, method_id, instrument_id, payment_id) FROM '$$PATH$$/3466.dat';

--
-- Data for Name: payment_invoice; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_invoice (id, payment_id, invoice_id, amount, create_datetime, optlock) FROM stdin;
\.
COPY payment_invoice (id, payment_id, invoice_id, amount, create_datetime, optlock) FROM '$$PATH$$/3382.dat';

--
-- Data for Name: payment_meta_field_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_meta_field_map (payment_id, meta_field_value_id) FROM stdin;
\.
COPY payment_meta_field_map (payment_id, meta_field_value_id) FROM '$$PATH$$/3383.dat';

--
-- Data for Name: payment_method; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_method (id) FROM stdin;
\.
COPY payment_method (id) FROM '$$PATH$$/3384.dat';

--
-- Data for Name: payment_method_account_type_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_method_account_type_map (payment_method_id, account_type_id) FROM stdin;
\.
COPY payment_method_account_type_map (payment_method_id, account_type_id) FROM '$$PATH$$/3465.dat';

--
-- Data for Name: payment_method_meta_fields_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_method_meta_fields_map (payment_method_id, meta_field_id) FROM stdin;
\.
COPY payment_method_meta_fields_map (payment_method_id, meta_field_id) FROM '$$PATH$$/3462.dat';

--
-- Data for Name: payment_method_template; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_method_template (id, template_name, optlock) FROM stdin;
\.
COPY payment_method_template (id, template_name, optlock) FROM '$$PATH$$/3459.dat';

--
-- Data for Name: payment_method_template_meta_fields_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_method_template_meta_fields_map (method_template_id, meta_field_id) FROM stdin;
\.
COPY payment_method_template_meta_fields_map (method_template_id, meta_field_id) FROM '$$PATH$$/3460.dat';

--
-- Data for Name: payment_method_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_method_type (id, method_name, is_recurring, entity_id, template_id, optlock, all_account_type) FROM stdin;
\.
COPY payment_method_type (id, method_name, is_recurring, entity_id, template_id, optlock, all_account_type) FROM '$$PATH$$/3461.dat';

--
-- Data for Name: payment_result; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY payment_result (id) FROM stdin;
\.
COPY payment_result (id) FROM '$$PATH$$/3385.dat';

--
-- Data for Name: period_unit; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY period_unit (id) FROM stdin;
\.
COPY period_unit (id) FROM '$$PATH$$/3386.dat';

--
-- Data for Name: pluggable_task; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY pluggable_task (id, entity_id, type_id, processing_order, optlock, notes) FROM stdin;
\.
COPY pluggable_task (id, entity_id, type_id, processing_order, optlock, notes) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: pluggable_task_parameter; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY pluggable_task_parameter (id, task_id, name, int_value, str_value, float_value, optlock) FROM stdin;
\.
COPY pluggable_task_parameter (id, task_id, name, int_value, str_value, float_value, optlock) FROM '$$PATH$$/3388.dat';

--
-- Data for Name: pluggable_task_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY pluggable_task_type (id, category_id, class_name, min_parameters) FROM stdin;
\.
COPY pluggable_task_type (id, category_id, class_name, min_parameters) FROM '$$PATH$$/3389.dat';

--
-- Data for Name: pluggable_task_type_category; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY pluggable_task_type_category (id, interface_name) FROM stdin;
\.
COPY pluggable_task_type_category (id, interface_name) FROM '$$PATH$$/3390.dat';

--
-- Data for Name: preference; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY preference (id, type_id, table_id, foreign_id, value) FROM stdin;
\.
COPY preference (id, type_id, table_id, foreign_id, value) FROM '$$PATH$$/3391.dat';

--
-- Data for Name: preference_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY preference_type (id, def_value, validation_rule_id) FROM stdin;
\.
COPY preference_type (id, def_value, validation_rule_id) FROM '$$PATH$$/3392.dat';

--
-- Data for Name: process_run; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY process_run (id, process_id, run_date, started, finished, payment_finished, invoices_generated, optlock, status_id) FROM stdin;
\.
COPY process_run (id, process_id, run_date, started, finished, payment_finished, invoices_generated, optlock, status_id) FROM '$$PATH$$/3393.dat';

--
-- Data for Name: process_run_total; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY process_run_total (id, process_run_id, currency_id, total_invoiced, total_paid, total_not_paid, optlock) FROM stdin;
\.
COPY process_run_total (id, process_run_id, currency_id, total_invoiced, total_paid, total_not_paid, optlock) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: process_run_total_pm; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY process_run_total_pm (id, process_run_total_id, payment_method_id, total, optlock) FROM stdin;
\.
COPY process_run_total_pm (id, process_run_total_id, payment_method_id, total, optlock) FROM '$$PATH$$/3395.dat';

--
-- Data for Name: process_run_user; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY process_run_user (id, process_run_id, user_id, status, created, optlock) FROM stdin;
\.
COPY process_run_user (id, process_run_id, user_id, status, created, optlock) FROM '$$PATH$$/3396.dat';

--
-- Data for Name: promotion; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY promotion (id, item_id, code, notes, once, since, until) FROM stdin;
\.
COPY promotion (id, item_id, code, notes, once, since, until) FROM '$$PATH$$/3397.dat';

--
-- Data for Name: promotion_user_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY promotion_user_map (user_id, promotion_id) FROM stdin;
\.
COPY promotion_user_map (user_id, promotion_id) FROM '$$PATH$$/3398.dat';

--
-- Data for Name: purchase_order; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY purchase_order (id, user_id, period_id, billing_type_id, active_since, active_until, cycle_start, create_datetime, next_billable_day, created_by, status_id, currency_id, deleted, notify, last_notified, notification_step, due_date_unit_id, due_date_value, df_fm, anticipate_periods, own_invoice, notes, notes_in_invoice, optlock, primary_order_id, prorate_flag, parent_order_id, cancellation_fee_type, cancellation_fee, cancellation_fee_percentage, cancellation_maximum_fee, cancellation_minimum_period, reseller_order, free_usage_quantity, deleted_date) FROM stdin;
\.
COPY purchase_order (id, user_id, period_id, billing_type_id, active_since, active_until, cycle_start, create_datetime, next_billable_day, created_by, status_id, currency_id, deleted, notify, last_notified, notification_step, due_date_unit_id, due_date_value, df_fm, anticipate_periods, own_invoice, notes, notes_in_invoice, optlock, primary_order_id, prorate_flag, parent_order_id, cancellation_fee_type, cancellation_fee, cancellation_fee_percentage, cancellation_maximum_fee, cancellation_minimum_period, reseller_order, free_usage_quantity, deleted_date) FROM '$$PATH$$/3399.dat';

--
-- Data for Name: rating_unit; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY rating_unit (id, name, entity_id, price_unit_name, increment_unit_name, increment_unit_quantity, can_be_deleted, optlock) FROM stdin;
\.
COPY rating_unit (id, name, entity_id, price_unit_name, increment_unit_name, increment_unit_quantity, can_be_deleted, optlock) FROM '$$PATH$$/3478.dat';

--
-- Data for Name: recent_item; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY recent_item (id, type, object_id, user_id, version) FROM stdin;
\.
COPY recent_item (id, type, object_id, user_id, version) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY report (id, type_id, name, file_name, optlock) FROM stdin;
\.
COPY report (id, type_id, name, file_name, optlock) FROM '$$PATH$$/3401.dat';

--
-- Data for Name: report_parameter; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY report_parameter (id, report_id, dtype, name) FROM stdin;
\.
COPY report_parameter (id, report_id, dtype, name) FROM '$$PATH$$/3402.dat';

--
-- Data for Name: report_type; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY report_type (id, name, optlock) FROM stdin;
\.
COPY report_type (id, name, optlock) FROM '$$PATH$$/3403.dat';

--
-- Data for Name: reseller_entityid_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY reseller_entityid_map (entity_id, user_id) FROM stdin;
\.
COPY reseller_entityid_map (entity_id, user_id) FROM '$$PATH$$/3446.dat';

--
-- Data for Name: reserved_amounts; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY reserved_amounts (id, session_id, ts_created, currency_id, reserved_amount, item_id, data, quantity) FROM stdin;
\.
COPY reserved_amounts (id, session_id, ts_created, currency_id, reserved_amount, item_id, data, quantity) FROM '$$PATH$$/3476.dat';

--
-- Data for Name: reset_password_code; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY reset_password_code (base_user_id, date_created, token, new_password) FROM stdin;
\.
COPY reset_password_code (base_user_id, date_created, token, new_password) FROM '$$PATH$$/3419.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY role (id, entity_id, role_type_id) FROM stdin;
\.
COPY role (id, entity_id, role_type_id) FROM '$$PATH$$/3404.dat';

--
-- Data for Name: route; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY route (id, name, table_name, entity_id, optlock, root_table, output_field_name, default_route, route_table) FROM stdin;
\.
COPY route (id, name, table_name, entity_id, optlock, root_table, output_field_name, default_route, route_table) FROM '$$PATH$$/3444.dat';

--
-- Data for Name: shortcut; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY shortcut (id, user_id, controller, action, name, object_id, version) FROM stdin;
\.
COPY shortcut (id, user_id, controller, action, name, object_id, version) FROM '$$PATH$$/3405.dat';

--
-- Data for Name: sure_tax_txn_log; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY sure_tax_txn_log (id, txn_id, txn_type, txn_data, txn_date, resp_trans_id, request_type) FROM stdin;
\.
COPY sure_tax_txn_log (id, txn_id, txn_type, txn_data, txn_date, resp_trans_id, request_type) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: tab; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY tab (id, message_code, controller_name, access_url, required_role, version, default_order) FROM stdin;
\.
COPY tab (id, message_code, controller_name, access_url, required_role, version, default_order) FROM '$$PATH$$/3416.dat';

--
-- Data for Name: tab_configuration; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY tab_configuration (id, user_id, version) FROM stdin;
\.
COPY tab_configuration (id, user_id, version) FROM '$$PATH$$/3417.dat';

--
-- Data for Name: tab_configuration_tab; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY tab_configuration_tab (id, tab_id, tab_configuration_id, display_order, visible, version) FROM stdin;
\.
COPY tab_configuration_tab (id, tab_id, tab_configuration_id, display_order, visible, version) FROM '$$PATH$$/3418.dat';

--
-- Data for Name: user_code; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY user_code (id, user_id, identifier, external_ref, type, type_desc, valid_from, valid_to) FROM stdin;
\.
COPY user_code (id, user_id, identifier, external_ref, type, type_desc, valid_from, valid_to) FROM '$$PATH$$/3457.dat';

--
-- Data for Name: user_code_link; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY user_code_link (id, user_code_id, object_type, object_id) FROM stdin;
\.
COPY user_code_link (id, user_code_id, object_type, object_id) FROM '$$PATH$$/3458.dat';

--
-- Data for Name: user_credit_card_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY user_credit_card_map (user_id, credit_card_id, id) FROM stdin;
\.
COPY user_credit_card_map (user_id, credit_card_id, id) FROM '$$PATH$$/3406.dat';

--
-- Name: user_credit_card_map_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jbilling
--

SELECT pg_catalog.setval('user_credit_card_map_id_seq', 1005, true);


--
-- Data for Name: user_password_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY user_password_map (id, base_user_id, date_created, new_password) FROM stdin;
\.
COPY user_password_map (id, base_user_id, date_created, new_password) FROM '$$PATH$$/3488.dat';

--
-- Data for Name: user_role_map; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY user_role_map (user_id, role_id) FROM stdin;
\.
COPY user_role_map (user_id, role_id) FROM '$$PATH$$/3407.dat';

--
-- Data for Name: user_status; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY user_status (id, can_login) FROM stdin;
\.
COPY user_status (id, can_login) FROM '$$PATH$$/3420.dat';

--
-- Data for Name: validation_rule; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY validation_rule (id, rule_type, enabled, optlock) FROM stdin;
\.
COPY validation_rule (id, rule_type, enabled, optlock) FROM '$$PATH$$/3440.dat';

--
-- Data for Name: validation_rule_attributes; Type: TABLE DATA; Schema: public; Owner: jbilling
--

COPY validation_rule_attributes (validation_rule_id, attribute_name, attribute_value) FROM stdin;
\.
COPY validation_rule_attributes (validation_rule_id, attribute_name, attribute_value) FROM '$$PATH$$/3441.dat';

--
-- Name: account_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY account_type
    ADD CONSTRAINT account_type_pkey PRIMARY KEY (id);


--
-- Name: ageing_entity_step_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY ageing_entity_step
    ADD CONSTRAINT ageing_entity_step_pkey PRIMARY KEY (id);


--
-- Name: asset_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY asset_assignment
    ADD CONSTRAINT asset_assignment_pkey PRIMARY KEY (id);


--
-- Name: asset_entity_map_uc_1; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY asset_entity_map
    ADD CONSTRAINT asset_entity_map_uc_1 UNIQUE (asset_id, entity_id);


--
-- Name: asset_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY asset
    ADD CONSTRAINT asset_pkey PRIMARY KEY (id);


--
-- Name: asset_reservation_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY asset_reservation
    ADD CONSTRAINT asset_reservation_pkey PRIMARY KEY (id);


--
-- Name: asset_status_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY asset_status
    ADD CONSTRAINT asset_status_pkey PRIMARY KEY (id);


--
-- Name: asset_transition_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY asset_transition
    ADD CONSTRAINT asset_transition_pkey PRIMARY KEY (id);


--
-- Name: base_user_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY base_user
    ADD CONSTRAINT base_user_pkey PRIMARY KEY (id);


--
-- Name: batch_job_execution_context_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY batch_job_execution_context
    ADD CONSTRAINT batch_job_execution_context_pkey PRIMARY KEY (job_execution_id);


--
-- Name: batch_job_execution_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY batch_job_execution
    ADD CONSTRAINT batch_job_execution_pkey PRIMARY KEY (job_execution_id);


--
-- Name: batch_job_instance_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY batch_job_instance
    ADD CONSTRAINT batch_job_instance_pkey PRIMARY KEY (job_instance_id);


--
-- Name: batch_step_execution_context_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY batch_step_execution_context
    ADD CONSTRAINT batch_step_execution_context_pkey PRIMARY KEY (step_execution_id);


--
-- Name: batch_step_execution_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY batch_step_execution
    ADD CONSTRAINT batch_step_execution_pkey PRIMARY KEY (step_execution_id);


--
-- Name: billing_process_config_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY billing_process_configuration
    ADD CONSTRAINT billing_process_config_pkey PRIMARY KEY (id);


--
-- Name: billing_process_failed_user_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY billing_process_failed_user
    ADD CONSTRAINT billing_process_failed_user_pkey PRIMARY KEY (id);


--
-- Name: billing_process_info_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY batch_process_info
    ADD CONSTRAINT billing_process_info_pkey PRIMARY KEY (id);


--
-- Name: billing_process_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY billing_process
    ADD CONSTRAINT billing_process_pkey PRIMARY KEY (id);


--
-- Name: blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY blacklist
    ADD CONSTRAINT blacklist_pkey PRIMARY KEY (id);


--
-- Name: breadcrumb_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY breadcrumb
    ADD CONSTRAINT breadcrumb_pkey PRIMARY KEY (id);


--
-- Name: cdrentries_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY cdrentries
    ADD CONSTRAINT cdrentries_pkey PRIMARY KEY (id);


--
-- Name: charge_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY charge_sessions
    ADD CONSTRAINT charge_sessions_pkey PRIMARY KEY (id);


--
-- Name: contact_map_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY contact_map
    ADD CONSTRAINT contact_map_pkey PRIMARY KEY (id);


--
-- Name: contact_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY contact
    ADD CONSTRAINT contact_pkey PRIMARY KEY (id);


--
-- Name: country_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY country
    ADD CONSTRAINT country_pkey PRIMARY KEY (id);


--
-- Name: currency_entity_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY currency_entity_map
    ADD CONSTRAINT currency_entity_map_compositekey PRIMARY KEY (currency_id, entity_id);


--
-- Name: currency_exchange_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY currency_exchange
    ADD CONSTRAINT currency_exchange_pkey PRIMARY KEY (id);


--
-- Name: currency_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY currency
    ADD CONSTRAINT currency_pkey PRIMARY KEY (id);


--
-- Name: customer_account_info_type_timeline_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY customer_account_info_type_timeline
    ADD CONSTRAINT customer_account_info_type_timeline_pkey PRIMARY KEY (id);


--
-- Name: customer_account_info_type_timeline_uk; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY customer_account_info_type_timeline
    ADD CONSTRAINT customer_account_info_type_timeline_uk UNIQUE (customer_id, meta_field_value_id, account_info_type_id);


--
-- Name: customer_meta_field_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY customer_meta_field_map
    ADD CONSTRAINT customer_meta_field_map_compositekey PRIMARY KEY (customer_id, meta_field_value_id);


--
-- Name: customer_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: discount_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY discount_attribute
    ADD CONSTRAINT discount_attribute_pkey PRIMARY KEY (discount_id, attribute_name);


--
-- Name: discount_line_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY discount_line
    ADD CONSTRAINT discount_line_pkey PRIMARY KEY (id);


--
-- Name: discount_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY discount
    ADD CONSTRAINT discount_pkey PRIMARY KEY (id);


--
-- Name: entity_delivery_method_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY entity_delivery_method_map
    ADD CONSTRAINT entity_delivery_method_map_compositekey PRIMARY KEY (method_id, entity_id);


--
-- Name: entity_payment_method_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY entity_payment_method_map
    ADD CONSTRAINT entity_payment_method_map_compositekey PRIMARY KEY (entity_id, payment_method_id);


--
-- Name: entity_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY entity
    ADD CONSTRAINT entity_pkey PRIMARY KEY (id);


--
-- Name: entity_report_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY entity_report_map
    ADD CONSTRAINT entity_report_map_compositekey PRIMARY KEY (report_id, entity_id);


--
-- Name: entity_step_days; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY ageing_entity_step
    ADD CONSTRAINT entity_step_days UNIQUE (entity_id, days);


--
-- Name: enumeration_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY enumeration
    ADD CONSTRAINT enumeration_pkey PRIMARY KEY (id);


--
-- Name: enumeration_values_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY enumeration_values
    ADD CONSTRAINT enumeration_values_pkey PRIMARY KEY (id);


--
-- Name: event_log_message_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY event_log_message
    ADD CONSTRAINT event_log_message_pkey PRIMARY KEY (id);


--
-- Name: event_log_module_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY event_log_module
    ADD CONSTRAINT event_log_module_pkey PRIMARY KEY (id);


--
-- Name: event_log_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY event_log
    ADD CONSTRAINT event_log_pkey PRIMARY KEY (id);


--
-- Name: filter_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY filter
    ADD CONSTRAINT filter_pkey PRIMARY KEY (id);


--
-- Name: filter_set_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY filter_set
    ADD CONSTRAINT filter_set_pkey PRIMARY KEY (id);


--
-- Name: generic_status_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY generic_status
    ADD CONSTRAINT generic_status_pkey PRIMARY KEY (id);


--
-- Name: generic_status_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY generic_status_type
    ADD CONSTRAINT generic_status_type_pkey PRIMARY KEY (id);


--
-- Name: international_description_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY international_description
    ADD CONSTRAINT international_description_pkey PRIMARY KEY (table_id, foreign_id, psudo_column, language_id);


--
-- Name: invoice_delivery_method_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY invoice_delivery_method
    ADD CONSTRAINT invoice_delivery_method_pkey PRIMARY KEY (id);


--
-- Name: invoice_line_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY invoice_line
    ADD CONSTRAINT invoice_line_pkey PRIMARY KEY (id);


--
-- Name: invoice_line_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY invoice_line_type
    ADD CONSTRAINT invoice_line_type_pkey PRIMARY KEY (id);


--
-- Name: invoice_meta_field_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY invoice_meta_field_map
    ADD CONSTRAINT invoice_meta_field_map_compositekey PRIMARY KEY (invoice_id, meta_field_value_id);


--
-- Name: invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (id);


--
-- Name: item_dependency_pk; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY item_dependency
    ADD CONSTRAINT item_dependency_pk PRIMARY KEY (id);


--
-- Name: item_entity_map_uc_1; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY item_entity_map
    ADD CONSTRAINT item_entity_map_uc_1 UNIQUE (entity_id, item_id);


--
-- Name: item_meta_field_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY item_meta_field_map
    ADD CONSTRAINT item_meta_field_map_compositekey PRIMARY KEY (item_id, meta_field_value_id);


--
-- Name: item_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY item
    ADD CONSTRAINT item_pkey PRIMARY KEY (id);


--
-- Name: item_price_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY item_price
    ADD CONSTRAINT item_price_pkey PRIMARY KEY (id);


--
-- Name: item_type_exclude_map_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY item_type_exclude_map
    ADD CONSTRAINT item_type_exclude_map_pkey PRIMARY KEY (item_id, type_id);


--
-- Name: item_type_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY item_type_map
    ADD CONSTRAINT item_type_map_compositekey PRIMARY KEY (item_id, type_id);


--
-- Name: item_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY item_type
    ADD CONSTRAINT item_type_pkey PRIMARY KEY (id);


--
-- Name: jbilling_seqs_pk; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY jbilling_seqs
    ADD CONSTRAINT jbilling_seqs_pk PRIMARY KEY (name);


--
-- Name: jbilling_table_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY jbilling_table
    ADD CONSTRAINT jbilling_table_pkey PRIMARY KEY (id);


--
-- Name: language_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY language
    ADD CONSTRAINT language_pkey PRIMARY KEY (id);


--
-- Name: matching_field_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY matching_field
    ADD CONSTRAINT matching_field_pkey PRIMARY KEY (id);


--
-- Name: meta_field_name_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY meta_field_name
    ADD CONSTRAINT meta_field_name_pkey PRIMARY KEY (id);


--
-- Name: meta_field_value_id_key; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY meta_field_value
    ADD CONSTRAINT meta_field_value_id_key UNIQUE (id);


--
-- Name: metafield_group_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY meta_field_group
    ADD CONSTRAINT metafield_group_pkey PRIMARY KEY (id);


--
-- Name: notification_category_pk; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY notification_category
    ADD CONSTRAINT notification_category_pk PRIMARY KEY (id);


--
-- Name: notifictn_msg_arch_line_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY notification_message_arch_line
    ADD CONSTRAINT notifictn_msg_arch_line_pkey PRIMARY KEY (id);


--
-- Name: notifictn_msg_arch_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY notification_message_arch
    ADD CONSTRAINT notifictn_msg_arch_pkey PRIMARY KEY (id);


--
-- Name: notifictn_msg_line_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY notification_message_line
    ADD CONSTRAINT notifictn_msg_line_pkey PRIMARY KEY (id);


--
-- Name: notifictn_msg_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY notification_message
    ADD CONSTRAINT notifictn_msg_pkey PRIMARY KEY (id);


--
-- Name: notifictn_msg_section_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY notification_message_section
    ADD CONSTRAINT notifictn_msg_section_pkey PRIMARY KEY (id);


--
-- Name: notifictn_msg_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY notification_message_type
    ADD CONSTRAINT notifictn_msg_type_pkey PRIMARY KEY (id);


--
-- Name: order_billing_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY order_billing_type
    ADD CONSTRAINT order_billing_type_pkey PRIMARY KEY (id);


--
-- Name: order_change_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY order_change
    ADD CONSTRAINT order_change_pkey PRIMARY KEY (id);


--
-- Name: order_change_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY order_change_type
    ADD CONSTRAINT order_change_type_pkey PRIMARY KEY (id);


--
-- Name: order_line_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY order_line
    ADD CONSTRAINT order_line_pkey PRIMARY KEY (id);


--
-- Name: order_line_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY order_line_type
    ADD CONSTRAINT order_line_type_pkey PRIMARY KEY (id);


--
-- Name: order_meta_field_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY order_meta_field_map
    ADD CONSTRAINT order_meta_field_map_compositekey PRIMARY KEY (order_id, meta_field_value_id);


--
-- Name: order_period_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY order_period
    ADD CONSTRAINT order_period_pkey PRIMARY KEY (id);


--
-- Name: order_process_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY order_process
    ADD CONSTRAINT order_process_pkey PRIMARY KEY (id);


--
-- Name: order_status_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY order_status
    ADD CONSTRAINT order_status_pkey PRIMARY KEY (id);


--
-- Name: paper_invoice_batch_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY paper_invoice_batch
    ADD CONSTRAINT paper_invoice_batch_pkey PRIMARY KEY (id);


--
-- Name: partner_meta_field_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY partner_meta_field_map
    ADD CONSTRAINT partner_meta_field_map_compositekey PRIMARY KEY (partner_id, meta_field_value_id);


--
-- Name: partner_payout_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY partner_payout
    ADD CONSTRAINT partner_payout_pkey PRIMARY KEY (id);


--
-- Name: partner_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY partner
    ADD CONSTRAINT partner_pkey PRIMARY KEY (id);


--
-- Name: payment_authorization_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY payment_authorization
    ADD CONSTRAINT payment_authorization_pkey PRIMARY KEY (id);


--
-- Name: payment_information_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY payment_information
    ADD CONSTRAINT payment_information_pkey PRIMARY KEY (id);


--
-- Name: payment_instrument_info_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY payment_instrument_info
    ADD CONSTRAINT payment_instrument_info_pkey PRIMARY KEY (id);


--
-- Name: payment_invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY payment_invoice
    ADD CONSTRAINT payment_invoice_pkey PRIMARY KEY (id);


--
-- Name: payment_meta_field_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY payment_meta_field_map
    ADD CONSTRAINT payment_meta_field_map_compositekey PRIMARY KEY (payment_id, meta_field_value_id);


--
-- Name: payment_method_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY payment_method
    ADD CONSTRAINT payment_method_pkey PRIMARY KEY (id);


--
-- Name: payment_method_template_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY payment_method_template
    ADD CONSTRAINT payment_method_template_pkey PRIMARY KEY (id);


--
-- Name: payment_method_template_template_name_key; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY payment_method_template
    ADD CONSTRAINT payment_method_template_template_name_key UNIQUE (template_name);


--
-- Name: payment_method_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY payment_method_type
    ADD CONSTRAINT payment_method_type_pkey PRIMARY KEY (id);


--
-- Name: payment_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (id);


--
-- Name: payment_result_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY payment_result
    ADD CONSTRAINT payment_result_pkey PRIMARY KEY (id);


--
-- Name: period_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY period_unit
    ADD CONSTRAINT period_unit_pkey PRIMARY KEY (id);


--
-- Name: pk_customer_notes; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY customer_notes
    ADD CONSTRAINT pk_customer_notes PRIMARY KEY (id);


--
-- Name: pk_data_table_query; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY data_table_query
    ADD CONSTRAINT pk_data_table_query PRIMARY KEY (id);


--
-- Name: pk_data_table_query_entry; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY data_table_query_entry
    ADD CONSTRAINT pk_data_table_query_entry PRIMARY KEY (id);


--
-- Name: pk_databasechangeloglock; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY databasechangeloglock
    ADD CONSTRAINT pk_databasechangeloglock PRIMARY KEY (id);


--
-- Name: pk_notification_medium_type; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY notification_medium_type
    ADD CONSTRAINT pk_notification_medium_type PRIMARY KEY (notification_id, medium_type);


--
-- Name: pk_rating_unit; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY rating_unit
    ADD CONSTRAINT pk_rating_unit PRIMARY KEY (id);


--
-- Name: pk_reset_password_code; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY reset_password_code
    ADD CONSTRAINT pk_reset_password_code PRIMARY KEY (token);


--
-- Name: pluggable_task_parameter_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY pluggable_task_parameter
    ADD CONSTRAINT pluggable_task_parameter_pkey PRIMARY KEY (id);


--
-- Name: pluggable_task_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY pluggable_task
    ADD CONSTRAINT pluggable_task_pkey PRIMARY KEY (id);


--
-- Name: pluggable_task_type_cat_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY pluggable_task_type_category
    ADD CONSTRAINT pluggable_task_type_cat_pkey PRIMARY KEY (id);


--
-- Name: pluggable_task_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY pluggable_task_type
    ADD CONSTRAINT pluggable_task_type_pkey PRIMARY KEY (id);


--
-- Name: preference_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY preference
    ADD CONSTRAINT preference_pkey PRIMARY KEY (id);


--
-- Name: preference_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY preference_type
    ADD CONSTRAINT preference_type_pkey PRIMARY KEY (id);


--
-- Name: process_run_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY process_run
    ADD CONSTRAINT process_run_pkey PRIMARY KEY (id);


--
-- Name: process_run_total_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY process_run_total
    ADD CONSTRAINT process_run_total_pkey PRIMARY KEY (id);


--
-- Name: process_run_total_pm_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY process_run_total_pm
    ADD CONSTRAINT process_run_total_pm_pkey PRIMARY KEY (id);


--
-- Name: process_run_user_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY process_run_user
    ADD CONSTRAINT process_run_user_pkey PRIMARY KEY (id);


--
-- Name: promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY promotion
    ADD CONSTRAINT promotion_pkey PRIMARY KEY (id);


--
-- Name: promotion_user_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY promotion_user_map
    ADD CONSTRAINT promotion_user_map_compositekey PRIMARY KEY (user_id, promotion_id);


--
-- Name: purchase_order_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY purchase_order
    ADD CONSTRAINT purchase_order_pkey PRIMARY KEY (id);


--
-- Name: recent_item_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY recent_item
    ADD CONSTRAINT recent_item_pkey PRIMARY KEY (id);


--
-- Name: report_parameter_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY report_parameter
    ADD CONSTRAINT report_parameter_pkey PRIMARY KEY (id);


--
-- Name: report_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY report
    ADD CONSTRAINT report_pkey PRIMARY KEY (id);


--
-- Name: report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY report_type
    ADD CONSTRAINT report_type_pkey PRIMARY KEY (id);


--
-- Name: reserved_amounts_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY reserved_amounts
    ADD CONSTRAINT reserved_amounts_pkey PRIMARY KEY (id);


--
-- Name: reset_password_code_base_user_id_key; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY reset_password_code
    ADD CONSTRAINT reset_password_code_base_user_id_key UNIQUE (base_user_id);


--
-- Name: role_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: route_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY route
    ADD CONSTRAINT route_pkey PRIMARY KEY (id);


--
-- Name: shortcut_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY shortcut
    ADD CONSTRAINT shortcut_pkey PRIMARY KEY (id);


--
-- Name: sure_tax_txn_log_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY sure_tax_txn_log
    ADD CONSTRAINT sure_tax_txn_log_pkey PRIMARY KEY (id);


--
-- Name: tab_configuration_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY tab_configuration
    ADD CONSTRAINT tab_configuration_pkey PRIMARY KEY (id);


--
-- Name: tab_configuration_tab_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY tab_configuration_tab
    ADD CONSTRAINT tab_configuration_tab_pkey PRIMARY KEY (id);


--
-- Name: tab_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY tab
    ADD CONSTRAINT tab_pkey PRIMARY KEY (id);


--
-- Name: user_code_link_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY user_code_link
    ADD CONSTRAINT user_code_link_pkey PRIMARY KEY (id);


--
-- Name: user_code_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY user_code
    ADD CONSTRAINT user_code_pkey PRIMARY KEY (id);


--
-- Name: user_password_map_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY user_password_map
    ADD CONSTRAINT user_password_map_pkey PRIMARY KEY (id);


--
-- Name: user_role_map_compositekey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY user_role_map
    ADD CONSTRAINT user_role_map_compositekey PRIMARY KEY (user_id, role_id);


--
-- Name: user_status_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY user_status
    ADD CONSTRAINT user_status_pkey PRIMARY KEY (id);


--
-- Name: validation_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: jbilling; Tablespace: 
--

ALTER TABLE ONLY validation_rule
    ADD CONSTRAINT validation_rule_pkey PRIMARY KEY (id);


--
-- Name: asset_reservation_end_date_index; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX asset_reservation_end_date_index ON asset_reservation USING btree (end_date);


--
-- Name: bp_pm_index_total; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX bp_pm_index_total ON process_run_total_pm USING btree (process_run_total_id);


--
-- Name: contact_i_del; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX contact_i_del ON contact USING btree (deleted);


--
-- Name: contact_map_i_2; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX contact_map_i_2 ON contact_map USING btree (table_id, foreign_id);


--
-- Name: create_datetime; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX create_datetime ON payment_authorization USING btree (create_datetime);


--
-- Name: currency_entity_map_i_2; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX currency_entity_map_i_2 ON currency_entity_map USING btree (currency_id, entity_id);


--
-- Name: international_description_i_2; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX international_description_i_2 ON international_description USING btree (table_id, foreign_id, language_id);


--
-- Name: ix_base_user_un; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_base_user_un ON base_user USING btree (entity_id, user_name);


--
-- Name: ix_blacklist_entity_type; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_blacklist_entity_type ON blacklist USING btree (entity_id, type);


--
-- Name: ix_blacklist_user_type; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_blacklist_user_type ON blacklist USING btree (user_id, type);


--
-- Name: ix_contact_address; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_contact_address ON contact USING btree (street_addres1, city, postal_code, street_addres2, state_province, country_code);


--
-- Name: ix_contact_fname; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_contact_fname ON contact USING btree (first_name);


--
-- Name: ix_contact_fname_lname; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_contact_fname_lname ON contact USING btree (first_name, last_name);


--
-- Name: ix_contact_lname; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_contact_lname ON contact USING btree (last_name);


--
-- Name: ix_contact_orgname; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_contact_orgname ON contact USING btree (organization_name);


--
-- Name: ix_contact_phone; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_contact_phone ON contact USING btree (phone_phone_number, phone_area_code, phone_country_code);


--
-- Name: ix_el_main; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_el_main ON event_log USING btree (module_id, message_id, create_datetime);


--
-- Name: ix_invoice_date; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_invoice_date ON invoice USING btree (create_datetime);


--
-- Name: ix_invoice_due_date; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_invoice_due_date ON invoice USING btree (user_id, due_date);


--
-- Name: ix_invoice_number; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_invoice_number ON invoice USING btree (user_id, public_number);


--
-- Name: ix_invoice_ts; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_invoice_ts ON invoice USING btree (create_timestamp, user_id);


--
-- Name: ix_invoice_user_id; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_invoice_user_id ON invoice USING btree (user_id, deleted);


--
-- Name: ix_item_ent; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_item_ent ON item USING btree (entity_id, internal_number);


--
-- Name: ix_order_process_in; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_order_process_in ON order_process USING btree (invoice_id);


--
-- Name: ix_parent_customer_id; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_parent_customer_id ON customer USING btree (parent_id);


--
-- Name: ix_promotion_code; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_promotion_code ON promotion USING btree (code);


--
-- Name: ix_purchase_order_date; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_purchase_order_date ON purchase_order USING btree (user_id, create_datetime);


--
-- Name: ix_uq_order_process_or_bp; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_uq_order_process_or_bp ON order_process USING btree (order_id, billing_process_id);


--
-- Name: ix_uq_order_process_or_in; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_uq_order_process_or_in ON order_process USING btree (order_id, invoice_id);


--
-- Name: ix_uq_payment_inv_map_pa_in; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX ix_uq_payment_inv_map_pa_in ON payment_invoice USING btree (payment_id, invoice_id);


--
-- Name: order_change_idx_order_line; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX order_change_idx_order_line ON order_change USING btree (order_line_id);


--
-- Name: payment_i_2; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX payment_i_2 ON payment USING btree (user_id, create_datetime);


--
-- Name: payment_i_3; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX payment_i_3 ON payment USING btree (user_id, balance);


--
-- Name: promotion_user_map_i_2; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX promotion_user_map_i_2 ON promotion_user_map USING btree (user_id, promotion_id);


--
-- Name: purchase_order_i_notif; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX purchase_order_i_notif ON purchase_order USING btree (active_until, notification_step);


--
-- Name: purchase_order_i_user; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX purchase_order_i_user ON purchase_order USING btree (user_id, deleted);


--
-- Name: transaction_id; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX transaction_id ON payment_authorization USING btree (transaction_id);


--
-- Name: user_credit_card_map_i_2; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX user_credit_card_map_i_2 ON user_credit_card_map USING btree (user_id, credit_card_id);


--
-- Name: user_role_map_i_2; Type: INDEX; Schema: public; Owner: jbilling; Tablespace: 
--

CREATE INDEX user_role_map_i_2 ON user_role_map USING btree (user_id, role_id);


--
-- Name: account_type_currency_id_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY account_type
    ADD CONSTRAINT "account_type_currency_id_FK" FOREIGN KEY (currency_id) REFERENCES currency(id);


--
-- Name: account_type_entity_id_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY account_type
    ADD CONSTRAINT "account_type_entity_id_FK" FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: account_type_language_id_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY account_type
    ADD CONSTRAINT "account_type_language_id_FK" FOREIGN KEY (language_id) REFERENCES language(id);


--
-- Name: account_type_main_subscription_period_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY account_type
    ADD CONSTRAINT "account_type_main_subscription_period_FK" FOREIGN KEY (main_subscript_order_period_id) REFERENCES order_period(id);


--
-- Name: ageing_entity_step_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY ageing_entity_step
    ADD CONSTRAINT ageing_entity_step_fk_2 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: asset_assignment_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_assignment
    ADD CONSTRAINT asset_assignment_fk_1 FOREIGN KEY (asset_id) REFERENCES asset(id);


--
-- Name: asset_assignment_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_assignment
    ADD CONSTRAINT asset_assignment_fk_2 FOREIGN KEY (order_line_id) REFERENCES order_line(id);


--
-- Name: asset_entity_map_fk1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_entity_map
    ADD CONSTRAINT asset_entity_map_fk1 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: asset_entity_map_fk2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_entity_map
    ADD CONSTRAINT asset_entity_map_fk2 FOREIGN KEY (asset_id) REFERENCES asset(id);


--
-- Name: asset_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset
    ADD CONSTRAINT asset_fk_1 FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: asset_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset
    ADD CONSTRAINT asset_fk_2 FOREIGN KEY (order_line_id) REFERENCES order_line(id);


--
-- Name: asset_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset
    ADD CONSTRAINT asset_fk_3 FOREIGN KEY (status_id) REFERENCES asset_status(id);


--
-- Name: asset_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset
    ADD CONSTRAINT asset_fk_4 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: asset_meta_field_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_meta_field_map
    ADD CONSTRAINT asset_meta_field_map_fk_1 FOREIGN KEY (asset_id) REFERENCES asset(id);


--
-- Name: asset_meta_field_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_meta_field_map
    ADD CONSTRAINT asset_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: asset_reservation_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_reservation
    ADD CONSTRAINT asset_reservation_fk_1 FOREIGN KEY (creator_user_id) REFERENCES base_user(id);


--
-- Name: asset_reservation_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_reservation
    ADD CONSTRAINT asset_reservation_fk_2 FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: asset_reservation_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_reservation
    ADD CONSTRAINT asset_reservation_fk_3 FOREIGN KEY (asset_id) REFERENCES asset(id);


--
-- Name: asset_status_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_status
    ADD CONSTRAINT asset_status_fk_1 FOREIGN KEY (item_type_id) REFERENCES item_type(id);


--
-- Name: asset_transition_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_transition
    ADD CONSTRAINT asset_transition_fk_1 FOREIGN KEY (assigned_to_id) REFERENCES base_user(id);


--
-- Name: asset_transition_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_transition
    ADD CONSTRAINT asset_transition_fk_2 FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: asset_transition_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_transition
    ADD CONSTRAINT asset_transition_fk_3 FOREIGN KEY (asset_id) REFERENCES asset(id);


--
-- Name: asset_transition_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_transition
    ADD CONSTRAINT asset_transition_fk_4 FOREIGN KEY (new_status_id) REFERENCES asset_status(id);


--
-- Name: asset_transition_fk_5; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY asset_transition
    ADD CONSTRAINT asset_transition_fk_5 FOREIGN KEY (previous_status_id) REFERENCES asset_status(id);


--
-- Name: base_user_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY base_user
    ADD CONSTRAINT base_user_fk_3 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: base_user_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY base_user
    ADD CONSTRAINT base_user_fk_4 FOREIGN KEY (language_id) REFERENCES language(id);


--
-- Name: base_user_fk_5; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY base_user
    ADD CONSTRAINT base_user_fk_5 FOREIGN KEY (currency_id) REFERENCES currency(id);


--
-- Name: base_user_fk_6; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY base_user
    ADD CONSTRAINT base_user_fk_6 FOREIGN KEY (status_id) REFERENCES user_status(id);


--
-- Name: billing_proc_configtn_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY billing_process_configuration
    ADD CONSTRAINT billing_proc_configtn_fk_1 FOREIGN KEY (period_unit_id) REFERENCES period_unit(id);


--
-- Name: billing_proc_configtn_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY billing_process_configuration
    ADD CONSTRAINT billing_proc_configtn_fk_2 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: billing_process_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY billing_process
    ADD CONSTRAINT billing_process_fk_1 FOREIGN KEY (period_unit_id) REFERENCES period_unit(id);


--
-- Name: billing_process_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY billing_process
    ADD CONSTRAINT billing_process_fk_2 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: billing_process_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY billing_process
    ADD CONSTRAINT billing_process_fk_3 FOREIGN KEY (paper_invoice_batch_id) REFERENCES paper_invoice_batch(id);


--
-- Name: blacklist_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY blacklist
    ADD CONSTRAINT blacklist_fk_1 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: blacklist_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY blacklist
    ADD CONSTRAINT blacklist_fk_2 FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: blacklist_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY blacklist
    ADD CONSTRAINT blacklist_fk_4 FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: category_id_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY notification_message_type
    ADD CONSTRAINT category_id_fk_1 FOREIGN KEY (category_id) REFERENCES notification_category(id);


--
-- Name: contact_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY contact_map
    ADD CONSTRAINT contact_map_fk_1 FOREIGN KEY (table_id) REFERENCES jbilling_table(id);


--
-- Name: contact_map_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY contact_map
    ADD CONSTRAINT contact_map_fk_3 FOREIGN KEY (contact_id) REFERENCES contact(id);


--
-- Name: currency_entity_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY currency_entity_map
    ADD CONSTRAINT currency_entity_map_fk_1 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: currency_entity_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY currency_entity_map
    ADD CONSTRAINT currency_entity_map_fk_2 FOREIGN KEY (currency_id) REFERENCES currency(id);


--
-- Name: currency_exchange_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY currency_exchange
    ADD CONSTRAINT currency_exchange_fk_1 FOREIGN KEY (currency_id) REFERENCES currency(id);


--
-- Name: customer_account_info_type_timeline_account_info_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer_account_info_type_timeline
    ADD CONSTRAINT customer_account_info_type_timeline_account_info_type_id_fk FOREIGN KEY (account_info_type_id) REFERENCES meta_field_group(id);


--
-- Name: customer_account_info_type_timeline_customer_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer_account_info_type_timeline
    ADD CONSTRAINT customer_account_info_type_timeline_customer_id_fk FOREIGN KEY (customer_id) REFERENCES customer(id);


--
-- Name: customer_account_info_type_timeline_meta_field_value_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer_account_info_type_timeline
    ADD CONSTRAINT customer_account_info_type_timeline_meta_field_value_id_fk FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: customer_account_type_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT customer_account_type_fk FOREIGN KEY (account_type_id) REFERENCES account_type(id);


--
-- Name: customer_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT customer_fk_1 FOREIGN KEY (invoice_delivery_method_id) REFERENCES invoice_delivery_method(id);


--
-- Name: customer_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT customer_fk_2 FOREIGN KEY (partner_id) REFERENCES partner(id);


--
-- Name: customer_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT customer_fk_3 FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: customer_main_subscription_period_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT "customer_main_subscription_period_FK" FOREIGN KEY (main_subscript_order_period_id) REFERENCES order_period(id);


--
-- Name: customer_meta_field_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer_meta_field_map
    ADD CONSTRAINT customer_meta_field_map_fk_1 FOREIGN KEY (customer_id) REFERENCES customer(id);


--
-- Name: customer_meta_field_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer_meta_field_map
    ADD CONSTRAINT customer_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: customer_notes_customer_id_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer_notes
    ADD CONSTRAINT "customer_notes_customer_id_FK" FOREIGN KEY (customer_id) REFERENCES customer(id);


--
-- Name: customer_notes_entity_id_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer_notes
    ADD CONSTRAINT "customer_notes_entity_id_FK" FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: customer_notes_user_id_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY customer_notes
    ADD CONSTRAINT "customer_notes_user_id_FK" FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: data_table_query_entry_next_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY data_table_query_entry
    ADD CONSTRAINT "data_table_query_entry_next_FK" FOREIGN KEY (next_entry_id) REFERENCES data_table_query_entry(id);


--
-- Name: data_table_query_next_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY data_table_query
    ADD CONSTRAINT "data_table_query_next_FK" FOREIGN KEY (root_entry_id) REFERENCES data_table_query_entry(id);


--
-- Name: discount_attr_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY discount_attribute
    ADD CONSTRAINT discount_attr_id_fk FOREIGN KEY (discount_id) REFERENCES discount(id);


--
-- Name: discount_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY discount
    ADD CONSTRAINT discount_entity_id_fk FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: discount_line_discount_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY discount_line
    ADD CONSTRAINT discount_line_discount_id_fk FOREIGN KEY (discount_id) REFERENCES discount(id);


--
-- Name: discount_line_item_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY discount_line
    ADD CONSTRAINT discount_line_item_id_fk FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: discount_line_order_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY discount_line
    ADD CONSTRAINT discount_line_order_id_fk FOREIGN KEY (order_id) REFERENCES purchase_order(id);


--
-- Name: discount_line_order_line_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY discount_line
    ADD CONSTRAINT discount_line_order_line_id_fk FOREIGN KEY (discount_order_line_id) REFERENCES order_line(id);


--
-- Name: entity_delivry_methd_map_fk1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY entity_delivery_method_map
    ADD CONSTRAINT entity_delivry_methd_map_fk1 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: entity_delivry_methd_map_fk2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY entity_delivery_method_map
    ADD CONSTRAINT entity_delivry_methd_map_fk2 FOREIGN KEY (method_id) REFERENCES invoice_delivery_method(id);


--
-- Name: entity_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY entity
    ADD CONSTRAINT entity_fk_1 FOREIGN KEY (currency_id) REFERENCES currency(id);


--
-- Name: entity_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY entity
    ADD CONSTRAINT entity_fk_2 FOREIGN KEY (language_id) REFERENCES language(id);


--
-- Name: entity_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY entity
    ADD CONSTRAINT entity_fk_3 FOREIGN KEY (parent_id) REFERENCES entity(id);


--
-- Name: entity_payment_method_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY entity_payment_method_map
    ADD CONSTRAINT entity_payment_method_map_fk_1 FOREIGN KEY (payment_method_id) REFERENCES payment_method(id);


--
-- Name: entity_payment_method_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY entity_payment_method_map
    ADD CONSTRAINT entity_payment_method_map_fk_2 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: enumeration_values_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY enumeration_values
    ADD CONSTRAINT enumeration_values_fk_1 FOREIGN KEY (enumeration_id) REFERENCES enumeration(id);


--
-- Name: event_log_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY event_log
    ADD CONSTRAINT event_log_fk_1 FOREIGN KEY (module_id) REFERENCES event_log_module(id);


--
-- Name: event_log_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY event_log
    ADD CONSTRAINT event_log_fk_2 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: event_log_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY event_log
    ADD CONSTRAINT event_log_fk_3 FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: event_log_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY event_log
    ADD CONSTRAINT event_log_fk_4 FOREIGN KEY (table_id) REFERENCES jbilling_table(id);


--
-- Name: event_log_fk_5; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY event_log
    ADD CONSTRAINT event_log_fk_5 FOREIGN KEY (message_id) REFERENCES event_log_message(id);


--
-- Name: event_log_fk_6; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY event_log
    ADD CONSTRAINT event_log_fk_6 FOREIGN KEY (affected_user_id) REFERENCES base_user(id);


--
-- Name: fk_reservations_session; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY reserved_amounts
    ADD CONSTRAINT fk_reservations_session FOREIGN KEY (session_id) REFERENCES charge_sessions(id);


--
-- Name: fk_sessions_user; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY charge_sessions
    ADD CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: generic_status_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY generic_status
    ADD CONSTRAINT generic_status_entity_id_fk FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: generic_status_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY generic_status
    ADD CONSTRAINT generic_status_fk_1 FOREIGN KEY (dtype) REFERENCES generic_status_type(id);


--
-- Name: international_description_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY international_description
    ADD CONSTRAINT international_description_fk_1 FOREIGN KEY (language_id) REFERENCES language(id);


--
-- Name: invoice_delivery_method_id_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY account_type
    ADD CONSTRAINT "invoice_delivery_method_id_FK" FOREIGN KEY (invoice_delivery_method_id) REFERENCES invoice_delivery_method(id);


--
-- Name: invoice_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT invoice_fk_1 FOREIGN KEY (billing_process_id) REFERENCES billing_process(id);


--
-- Name: invoice_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT invoice_fk_2 FOREIGN KEY (paper_invoice_batch_id) REFERENCES paper_invoice_batch(id);


--
-- Name: invoice_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT invoice_fk_3 FOREIGN KEY (currency_id) REFERENCES currency(id);


--
-- Name: invoice_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT invoice_fk_4 FOREIGN KEY (delegated_invoice_id) REFERENCES invoice(id);


--
-- Name: invoice_line_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY invoice_line
    ADD CONSTRAINT invoice_line_fk_1 FOREIGN KEY (invoice_id) REFERENCES invoice(id);


--
-- Name: invoice_line_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY invoice_line
    ADD CONSTRAINT invoice_line_fk_2 FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: invoice_line_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY invoice_line
    ADD CONSTRAINT invoice_line_fk_3 FOREIGN KEY (type_id) REFERENCES invoice_line_type(id);


--
-- Name: invoice_line_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY invoice_line
    ADD CONSTRAINT invoice_line_fk_4 FOREIGN KEY (order_id) REFERENCES purchase_order(id);


--
-- Name: invoice_meta_field_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY invoice_meta_field_map
    ADD CONSTRAINT invoice_meta_field_map_fk_1 FOREIGN KEY (invoice_id) REFERENCES invoice(id);


--
-- Name: invoice_meta_field_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY invoice_meta_field_map
    ADD CONSTRAINT invoice_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: item_dependency_fk1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_dependency
    ADD CONSTRAINT item_dependency_fk1 FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: item_dependency_fk2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_dependency
    ADD CONSTRAINT item_dependency_fk2 FOREIGN KEY (dependent_item_id) REFERENCES item(id);


--
-- Name: item_dependency_fk3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_dependency
    ADD CONSTRAINT item_dependency_fk3 FOREIGN KEY (dependent_item_type_id) REFERENCES item_type(id);


--
-- Name: item_entity_map_fk1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_entity_map
    ADD CONSTRAINT item_entity_map_fk1 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: item_entity_map_fk2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_entity_map
    ADD CONSTRAINT item_entity_map_fk2 FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: item_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item
    ADD CONSTRAINT item_fk_1 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: item_meta_field_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_meta_field_map
    ADD CONSTRAINT item_meta_field_map_fk_1 FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: item_meta_field_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_meta_field_map
    ADD CONSTRAINT item_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: item_price_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_price
    ADD CONSTRAINT item_price_fk_1 FOREIGN KEY (currency_id) REFERENCES currency(id);


--
-- Name: item_price_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_price
    ADD CONSTRAINT item_price_fk_2 FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: item_type_entity_map_fk1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_type_entity_map
    ADD CONSTRAINT item_type_entity_map_fk1 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: item_type_entity_map_fk2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_type_entity_map
    ADD CONSTRAINT item_type_entity_map_fk2 FOREIGN KEY (item_type_id) REFERENCES item_type(id);


--
-- Name: item_type_exclude_item_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_type_exclude_map
    ADD CONSTRAINT item_type_exclude_item_id_fk FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: item_type_exclude_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_type_exclude_map
    ADD CONSTRAINT item_type_exclude_type_id_fk FOREIGN KEY (type_id) REFERENCES item_type(id);


--
-- Name: item_type_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_type
    ADD CONSTRAINT item_type_fk_1 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: item_type_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_type_map
    ADD CONSTRAINT item_type_map_fk_1 FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: item_type_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_type_map
    ADD CONSTRAINT item_type_map_fk_2 FOREIGN KEY (type_id) REFERENCES item_type(id);


--
-- Name: item_type_meta_field_def_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_type_meta_field_def_map
    ADD CONSTRAINT item_type_meta_field_def_map_fk_1 FOREIGN KEY (item_type_id) REFERENCES item_type(id);


--
-- Name: item_type_meta_field_def_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_type_meta_field_def_map
    ADD CONSTRAINT item_type_meta_field_def_map_fk_2 FOREIGN KEY (meta_field_id) REFERENCES meta_field_name(id);


--
-- Name: item_type_meta_field_type_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_type_meta_field_map
    ADD CONSTRAINT item_type_meta_field_type_fk FOREIGN KEY (item_type_id) REFERENCES item_type(id);


--
-- Name: item_type_meta_field_value_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_type_meta_field_map
    ADD CONSTRAINT item_type_meta_field_value_fk FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: matching_field_route_id_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY matching_field
    ADD CONSTRAINT "matching_field_route_id_FK" FOREIGN KEY (route_id) REFERENCES route(id);


--
-- Name: meta_field_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY meta_field_name
    ADD CONSTRAINT meta_field_entity_id_fk FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: meta_field_group_account_type_FK2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY meta_field_group
    ADD CONSTRAINT "meta_field_group_account_type_FK2" FOREIGN KEY (account_type_id) REFERENCES account_type(id);


--
-- Name: meta_field_group_entity_FK1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY meta_field_group
    ADD CONSTRAINT "meta_field_group_entity_FK1" FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: meta_field_name_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY meta_field_name
    ADD CONSTRAINT meta_field_name_fk_1 FOREIGN KEY (default_value_id) REFERENCES meta_field_value(id);


--
-- Name: meta_field_value_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY meta_field_value
    ADD CONSTRAINT meta_field_value_fk_1 FOREIGN KEY (meta_field_name_id) REFERENCES meta_field_name(id);


--
-- Name: notif_mess_arch_line_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY notification_message_arch_line
    ADD CONSTRAINT notif_mess_arch_line_fk_1 FOREIGN KEY (message_archive_id) REFERENCES notification_message_arch(id);


--
-- Name: notification_message_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY notification_message
    ADD CONSTRAINT notification_message_fk_1 FOREIGN KEY (language_id) REFERENCES language(id);


--
-- Name: notification_message_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY notification_message
    ADD CONSTRAINT notification_message_fk_2 FOREIGN KEY (type_id) REFERENCES notification_message_type(id);


--
-- Name: notification_message_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY notification_message
    ADD CONSTRAINT notification_message_fk_3 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: notification_message_line_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY notification_message_line
    ADD CONSTRAINT notification_message_line_fk_1 FOREIGN KEY (message_section_id) REFERENCES notification_message_section(id);


--
-- Name: notification_msg_section_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY notification_message_section
    ADD CONSTRAINT notification_msg_section_fk_1 FOREIGN KEY (message_id) REFERENCES notification_message(id);


--
-- Name: ol_meta_field_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_line_meta_field_map
    ADD CONSTRAINT ol_meta_field_map_fk_1 FOREIGN KEY (order_line_id) REFERENCES order_line(id);


--
-- Name: ol_meta_field_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_line_meta_field_map
    ADD CONSTRAINT ol_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: ol_meta_fields_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_line_meta_fields_map
    ADD CONSTRAINT ol_meta_fields_map_fk_1 FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: ol_meta_fields_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_line_meta_fields_map
    ADD CONSTRAINT ol_meta_fields_map_fk_2 FOREIGN KEY (meta_field_id) REFERENCES meta_field_name(id);


--
-- Name: order_change_asset_map_asset_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change_asset_map
    ADD CONSTRAINT order_change_asset_map_asset_id_fk FOREIGN KEY (asset_id) REFERENCES asset(id);


--
-- Name: order_change_asset_map_change_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change_asset_map
    ADD CONSTRAINT order_change_asset_map_change_id_fk FOREIGN KEY (order_change_id) REFERENCES order_change(id);


--
-- Name: order_change_item_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change
    ADD CONSTRAINT order_change_item_id_fk FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: order_change_meta_field_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change_meta_field_map
    ADD CONSTRAINT order_change_meta_field_map_fk_1 FOREIGN KEY (order_change_id) REFERENCES order_change(id);


--
-- Name: order_change_meta_field_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change_meta_field_map
    ADD CONSTRAINT order_change_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: order_change_order_change_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change
    ADD CONSTRAINT order_change_order_change_type_id_fk FOREIGN KEY (order_change_type_id) REFERENCES order_change_type(id);


--
-- Name: order_change_order_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change
    ADD CONSTRAINT order_change_order_id_fk FOREIGN KEY (order_id) REFERENCES purchase_order(id);


--
-- Name: order_change_order_line_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change
    ADD CONSTRAINT order_change_order_line_id_fk FOREIGN KEY (order_line_id) REFERENCES order_line(id);


--
-- Name: order_change_order_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change
    ADD CONSTRAINT order_change_order_status_id_fk FOREIGN KEY (order_status_id) REFERENCES order_status(id);


--
-- Name: order_change_parent_order_change_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change
    ADD CONSTRAINT order_change_parent_order_change_fk FOREIGN KEY (parent_order_change_id) REFERENCES order_change(id);


--
-- Name: order_change_parent_order_line_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change
    ADD CONSTRAINT order_change_parent_order_line_id_fk FOREIGN KEY (parent_order_line_id) REFERENCES order_line(id);


--
-- Name: order_change_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change
    ADD CONSTRAINT order_change_status_id_fk FOREIGN KEY (status_id) REFERENCES generic_status(id);


--
-- Name: order_change_type_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change_type
    ADD CONSTRAINT order_change_type_entity_id_fk FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: order_change_type_item_type_map_change_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change_type_item_type_map
    ADD CONSTRAINT order_change_type_item_type_map_change_type_id_fk FOREIGN KEY (order_change_type_id) REFERENCES order_change_type(id);


--
-- Name: order_change_type_item_type_map_item_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change_type_item_type_map
    ADD CONSTRAINT order_change_type_item_type_map_item_type_id_fk FOREIGN KEY (item_type_id) REFERENCES item_type(id);


--
-- Name: order_change_type_meta_field_map_change_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change_type_meta_field_map
    ADD CONSTRAINT order_change_type_meta_field_map_change_type_id_fk FOREIGN KEY (order_change_type_id) REFERENCES order_change_type(id);


--
-- Name: order_change_type_meta_field_map_meta_field_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change_type_meta_field_map
    ADD CONSTRAINT order_change_type_meta_field_map_meta_field_id_fk FOREIGN KEY (meta_field_id) REFERENCES meta_field_name(id);


--
-- Name: order_change_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change
    ADD CONSTRAINT order_change_user_id_fk FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: order_change_user_status_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_change
    ADD CONSTRAINT order_change_user_status_id_fk FOREIGN KEY (user_assigned_status_id) REFERENCES generic_status(id);


--
-- Name: order_line_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_line
    ADD CONSTRAINT order_line_fk_1 FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: order_line_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_line
    ADD CONSTRAINT order_line_fk_2 FOREIGN KEY (order_id) REFERENCES purchase_order(id);


--
-- Name: order_line_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_line
    ADD CONSTRAINT order_line_fk_3 FOREIGN KEY (type_id) REFERENCES order_line_type(id);


--
-- Name: order_line_parent_line_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_line
    ADD CONSTRAINT order_line_parent_line_id_fk FOREIGN KEY (parent_line_id) REFERENCES order_line(id);


--
-- Name: order_meta_field_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_meta_field_map
    ADD CONSTRAINT order_meta_field_map_fk_1 FOREIGN KEY (order_id) REFERENCES purchase_order(id);


--
-- Name: order_meta_field_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_meta_field_map
    ADD CONSTRAINT order_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: order_period_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_period
    ADD CONSTRAINT order_period_fk_1 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: order_period_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_period
    ADD CONSTRAINT order_period_fk_2 FOREIGN KEY (unit_id) REFERENCES period_unit(id);


--
-- Name: order_primary_order_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY purchase_order
    ADD CONSTRAINT order_primary_order_fk_1 FOREIGN KEY (primary_order_id) REFERENCES purchase_order(id);


--
-- Name: order_process_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY order_process
    ADD CONSTRAINT order_process_fk_1 FOREIGN KEY (order_id) REFERENCES purchase_order(id);


--
-- Name: parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY item_type
    ADD CONSTRAINT parent_id_fk FOREIGN KEY (parent_id) REFERENCES item_type(id);


--
-- Name: partner_commission_currency_id_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY partner_commission
    ADD CONSTRAINT "partner_commission_currency_id_FK" FOREIGN KEY (currency_id) REFERENCES currency(id);


--
-- Name: partner_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY partner
    ADD CONSTRAINT partner_fk_4 FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: partner_meta_field_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY partner_meta_field_map
    ADD CONSTRAINT partner_meta_field_map_fk_1 FOREIGN KEY (partner_id) REFERENCES partner(id);


--
-- Name: partner_meta_field_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY partner_meta_field_map
    ADD CONSTRAINT partner_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: partner_payout_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY partner_payout
    ADD CONSTRAINT partner_payout_fk_1 FOREIGN KEY (partner_id) REFERENCES partner(id);


--
-- Name: payment_authorization_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_authorization
    ADD CONSTRAINT payment_authorization_fk_1 FOREIGN KEY (payment_id) REFERENCES payment(id);


--
-- Name: payment_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment
    ADD CONSTRAINT payment_fk_2 FOREIGN KEY (currency_id) REFERENCES currency(id);


--
-- Name: payment_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment
    ADD CONSTRAINT payment_fk_3 FOREIGN KEY (payment_id) REFERENCES payment(id);


--
-- Name: payment_fk_5; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment
    ADD CONSTRAINT payment_fk_5 FOREIGN KEY (result_id) REFERENCES payment_result(id);


--
-- Name: payment_fk_6; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment
    ADD CONSTRAINT payment_fk_6 FOREIGN KEY (method_id) REFERENCES payment_method(id);


--
-- Name: payment_fk_7; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment
    ADD CONSTRAINT payment_fk_7 FOREIGN KEY (credit_card_id) REFERENCES payment_information(id);


--
-- Name: payment_information_FK1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_information
    ADD CONSTRAINT "payment_information_FK1" FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: payment_information_FK2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_information
    ADD CONSTRAINT "payment_information_FK2" FOREIGN KEY (payment_method_id) REFERENCES payment_method_type(id);


--
-- Name: payment_information_meta_fields_map_FK1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_information_meta_fields_map
    ADD CONSTRAINT "payment_information_meta_fields_map_FK1" FOREIGN KEY (payment_information_id) REFERENCES payment_information(id);


--
-- Name: payment_information_meta_fields_map_FK2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_information_meta_fields_map
    ADD CONSTRAINT "payment_information_meta_fields_map_FK2" FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: payment_instrument_info_FK1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_instrument_info
    ADD CONSTRAINT "payment_instrument_info_FK1" FOREIGN KEY (result_id) REFERENCES payment_result(id);


--
-- Name: payment_instrument_info_FK2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_instrument_info
    ADD CONSTRAINT "payment_instrument_info_FK2" FOREIGN KEY (method_id) REFERENCES payment_method(id);


--
-- Name: payment_instrument_info_FK3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_instrument_info
    ADD CONSTRAINT "payment_instrument_info_FK3" FOREIGN KEY (instrument_id) REFERENCES payment_information(id);


--
-- Name: payment_instrument_info_FK4; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_instrument_info
    ADD CONSTRAINT "payment_instrument_info_FK4" FOREIGN KEY (payment_id) REFERENCES payment(id);


--
-- Name: payment_invoice_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_invoice
    ADD CONSTRAINT payment_invoice_fk_1 FOREIGN KEY (invoice_id) REFERENCES invoice(id);


--
-- Name: payment_invoice_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_invoice
    ADD CONSTRAINT payment_invoice_fk_2 FOREIGN KEY (payment_id) REFERENCES payment(id);


--
-- Name: payment_meta_field_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_meta_field_map
    ADD CONSTRAINT payment_meta_field_map_fk_1 FOREIGN KEY (payment_id) REFERENCES payment(id);


--
-- Name: payment_meta_field_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_meta_field_map
    ADD CONSTRAINT payment_meta_field_map_fk_2 FOREIGN KEY (meta_field_value_id) REFERENCES meta_field_value(id);


--
-- Name: payment_method_account_type_map_FK1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_method_account_type_map
    ADD CONSTRAINT "payment_method_account_type_map_FK1" FOREIGN KEY (payment_method_id) REFERENCES payment_method_type(id);


--
-- Name: payment_method_account_type_map_FK2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_method_account_type_map
    ADD CONSTRAINT "payment_method_account_type_map_FK2" FOREIGN KEY (account_type_id) REFERENCES account_type(id);


--
-- Name: payment_method_meta_fields_map_FK1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_method_meta_fields_map
    ADD CONSTRAINT "payment_method_meta_fields_map_FK1" FOREIGN KEY (payment_method_id) REFERENCES payment_method_type(id);


--
-- Name: payment_method_meta_fields_map_FK2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_method_meta_fields_map
    ADD CONSTRAINT "payment_method_meta_fields_map_FK2" FOREIGN KEY (meta_field_id) REFERENCES meta_field_name(id);


--
-- Name: payment_method_template_meta_fields_map_FK1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_method_template_meta_fields_map
    ADD CONSTRAINT "payment_method_template_meta_fields_map_FK1" FOREIGN KEY (method_template_id) REFERENCES payment_method_template(id);


--
-- Name: payment_method_template_meta_fields_map_FK2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_method_template_meta_fields_map
    ADD CONSTRAINT "payment_method_template_meta_fields_map_FK2" FOREIGN KEY (meta_field_id) REFERENCES meta_field_name(id);


--
-- Name: payment_method_type_FK1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_method_type
    ADD CONSTRAINT "payment_method_type_FK1" FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: payment_method_type_FK2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY payment_method_type
    ADD CONSTRAINT "payment_method_type_FK2" FOREIGN KEY (template_id) REFERENCES payment_method_template(id);


--
-- Name: pluggable_task_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY pluggable_task
    ADD CONSTRAINT pluggable_task_fk_2 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: pluggable_task_parameter_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY pluggable_task_parameter
    ADD CONSTRAINT pluggable_task_parameter_fk_1 FOREIGN KEY (task_id) REFERENCES pluggable_task(id);


--
-- Name: pluggable_task_type_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY pluggable_task_type
    ADD CONSTRAINT pluggable_task_type_fk_1 FOREIGN KEY (category_id) REFERENCES pluggable_task_type_category(id);


--
-- Name: preference_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY preference
    ADD CONSTRAINT preference_fk_1 FOREIGN KEY (type_id) REFERENCES preference_type(id);


--
-- Name: preference_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY preference
    ADD CONSTRAINT preference_fk_2 FOREIGN KEY (table_id) REFERENCES jbilling_table(id);


--
-- Name: preference_type_vr_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY preference_type
    ADD CONSTRAINT preference_type_vr_fk_1 FOREIGN KEY (validation_rule_id) REFERENCES validation_rule(id);


--
-- Name: process_run_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY process_run
    ADD CONSTRAINT process_run_fk_1 FOREIGN KEY (process_id) REFERENCES billing_process(id);


--
-- Name: process_run_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY process_run
    ADD CONSTRAINT process_run_fk_2 FOREIGN KEY (status_id) REFERENCES generic_status(id);


--
-- Name: process_run_total_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY process_run_total
    ADD CONSTRAINT process_run_total_fk_1 FOREIGN KEY (currency_id) REFERENCES currency(id);


--
-- Name: process_run_total_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY process_run_total
    ADD CONSTRAINT process_run_total_fk_2 FOREIGN KEY (process_run_id) REFERENCES process_run(id);


--
-- Name: process_run_total_pm_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY process_run_total_pm
    ADD CONSTRAINT process_run_total_pm_fk_1 FOREIGN KEY (payment_method_id) REFERENCES payment_method(id);


--
-- Name: process_run_user_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY process_run_user
    ADD CONSTRAINT process_run_user_fk_1 FOREIGN KEY (process_run_id) REFERENCES process_run(id);


--
-- Name: process_run_user_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY process_run_user
    ADD CONSTRAINT process_run_user_fk_2 FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: promotion_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY promotion
    ADD CONSTRAINT promotion_fk_1 FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: promotion_user_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY promotion_user_map
    ADD CONSTRAINT promotion_user_map_fk_1 FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: promotion_user_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY promotion_user_map
    ADD CONSTRAINT promotion_user_map_fk_2 FOREIGN KEY (promotion_id) REFERENCES promotion(id);


--
-- Name: purchase_order_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY purchase_order
    ADD CONSTRAINT purchase_order_fk_1 FOREIGN KEY (currency_id) REFERENCES currency(id);


--
-- Name: purchase_order_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY purchase_order
    ADD CONSTRAINT purchase_order_fk_2 FOREIGN KEY (billing_type_id) REFERENCES order_billing_type(id);


--
-- Name: purchase_order_fk_3; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY purchase_order
    ADD CONSTRAINT purchase_order_fk_3 FOREIGN KEY (period_id) REFERENCES order_period(id);


--
-- Name: purchase_order_fk_4; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY purchase_order
    ADD CONSTRAINT purchase_order_fk_4 FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: purchase_order_fk_5; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY purchase_order
    ADD CONSTRAINT purchase_order_fk_5 FOREIGN KEY (created_by) REFERENCES base_user(id);


--
-- Name: purchase_order_parent__order_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY purchase_order
    ADD CONSTRAINT purchase_order_parent__order_id_fk FOREIGN KEY (parent_order_id) REFERENCES purchase_order(id);


--
-- Name: purchase_order_statusId_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY purchase_order
    ADD CONSTRAINT "purchase_order_statusId_fk" FOREIGN KEY (status_id) REFERENCES order_status(id);


--
-- Name: rating_unit_entity_id_FK; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY rating_unit
    ADD CONSTRAINT "rating_unit_entity_id_FK" FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: report_map_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY entity_report_map
    ADD CONSTRAINT report_map_entity_id_fk FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: report_map_report_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY entity_report_map
    ADD CONSTRAINT report_map_report_id_fk FOREIGN KEY (report_id) REFERENCES report(id);


--
-- Name: reseller_entityid_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY reseller_entityid_map
    ADD CONSTRAINT reseller_entityid_map_fk_1 FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: reseller_entityid_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY reseller_entityid_map
    ADD CONSTRAINT reseller_entityid_map_fk_2 FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: role_entity_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY role
    ADD CONSTRAINT role_entity_id_fk FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: tab_configuration_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY tab_configuration
    ADD CONSTRAINT tab_configuration_fk_1 FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: tab_configuration_tab_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY tab_configuration_tab
    ADD CONSTRAINT tab_configuration_tab_fk_1 FOREIGN KEY (tab_id) REFERENCES tab(id);


--
-- Name: tab_configuration_tab_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY tab_configuration_tab
    ADD CONSTRAINT tab_configuration_tab_fk_2 FOREIGN KEY (tab_configuration_id) REFERENCES tab_configuration(id);


--
-- Name: user_role_map_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY user_role_map
    ADD CONSTRAINT user_role_map_fk_1 FOREIGN KEY (role_id) REFERENCES role(id);


--
-- Name: user_role_map_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY user_role_map
    ADD CONSTRAINT user_role_map_fk_2 FOREIGN KEY (user_id) REFERENCES base_user(id);


--
-- Name: validation_rule_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY meta_field_name
    ADD CONSTRAINT validation_rule_fk_1 FOREIGN KEY (validation_rule_id) REFERENCES validation_rule(id);


--
-- Name: validation_rule_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: jbilling
--

ALTER TABLE ONLY validation_rule_attributes
    ADD CONSTRAINT validation_rule_fk_2 FOREIGN KEY (validation_rule_id) REFERENCES validation_rule(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

